# METACOD-Omer — КАБИНЕТ (полная рабочая версия · Expo + Firebase · TypeScript)

Клиент — **Expo React Native (TS)**; сервер — **Firebase Cloud Functions (TS)** с **вызовом модели
(Claude)**; движки/алгоритмы и базы — в `shared/`. Стили — отдельными файлами.

## Документы
- `ARCHITECTURE.md` — манифест кабинета (пайплайн, фазы, мембраны, эталон-стандарт).
- `SYSTEM_MAP.md` — генеральная карта системы (аудит + согласование со старым кабинетом).

## Структура
```
metacod-omer-app/
├── shared/
│   ├── types.ts · index.ts
│   ├── knowledge/SKILL.md            # операционные правила (контекст модели)
│   ├── engines/{guard,solGel,membraneEngine,phaseEngine,drugSelect,differential,report,pipeline}.ts
│   └── data/                         # metacod_base_415 · drugbase(404) · phase_transitions · dx_organs · canon · DDI
├── server/                           # Firebase Functions (TS)
│   └── src/{index,analyze,llmAnalyze,prompt,retrieve}.ts   # analyzePatient + вызов модели + RAG
├── client/                           # Expo (TS)
│   └── src/
│       ├── state/analysis.tsx        # единое состояние разбора
│       ├── screens/{Menu,Intake,Report,Differential,PhaseTreatment,Membrane,Chrono,Reference,L1}.tsx
│       ├── components/{PhaseJourney,HypothesisTable}.tsx
│       ├── styles/*.styles.ts        # СТИЛИ ОТДЕЛЬНЫМИ ФАЙЛАМИ + theme.ts
│       └── api/firebase.ts
```

## Как работает
Приём (жалобы+анализы+3D) → `analyzePatient` → RAG (карты болезней + препараты из баз) →
системный промпт из SKILL/эталона → **модель Claude** → двухслойный JSON {internalL1, conventional}
→ страж на conventional → Firestore → экраны. conventional — всем врачам; internalL1 — только
проф. Литваку (custom claim `litvak=true`).

## Запуск
### Сервер
```
cd server && npm i
firebase login && firebase use <project>
npm run set:key                 # ввести ANTHROPIC_API_KEY (секрет)
# при необходимости: ANTHROPIC_MODEL (уточнить доступную модель)
npm run deploy
```
Выдать проф. Литваку роль: setCustomUserClaims(uid, { litvak: true }).
### Клиент
```
cd client && npm i
# подставить конфиг Firebase в src/api/firebase.ts
npm start
```

## Экраны-модули
Приём · Заключение (EBM, эталон-стандарт) · Дифдиагноз · Фазовое лечение (L1) · Мембрана (L1) ·
Хронотерапия · Справочник (Метаболический пациент) · Внутренний L1 (только Литваку).

## Правило двух слоёв
Наружу — только EBM (страж grep стоп-слов = 0). Внутренний L1 (энергии/мембраны/фазы/золь-гель) —
генерируется всегда, отдаётся только проф. Литваку.

validated:false · поддержка решения, не замена врача · Dr. Mark Litvak, MD.
