const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const p = await b.newPage();
  await p.goto('file:///tmp/kab/app_new/ПАСПОРТ_METACOD_29092026.html', { waitUntil: 'networkidle' });
  await p.pdf({ path: '/tmp/kab/app_new/ПАСПОРТ_METACOD_29092026.pdf', format: 'A4', printBackground: true,
    margin: { top:'0', bottom:'0', left:'0', right:'0' } });
  await b.close(); console.log('   PDF: ПАСПОРТ_METACOD_29092026.pdf');
})();
