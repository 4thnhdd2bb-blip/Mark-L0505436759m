#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
# ОДНА КОМАНДА В КОНЦЕ СЕССИИ: bash пересобрать_паспорт.sh
#
# 1) прогоняет регресс и запоминает число проверок
# 2) собирает паспорт ИЗ КАНОНА (gen_passport.js) — ничего не набирая руками
# 3) рендерит PDF
#
# ⛔ Паспорт не хранит ничего своего. Если он что-то показывает — это
# прочитано из канона или посчитано движком в момент сборки.
#
# ⚠ Имена переменных ЛАТИНСКИЕ намеренно: bash не принимает кириллицу
#   в именах, а первая версия этого файла на этом и сломалась.
# ═══════════════════════════════════════════════════════════════════
set -u
DIR="$(cd "$(dirname "$0")/.." && pwd)"
PKG="$DIR"
# ⚠ Генератор пишет туда, куда скажет METACOD_OUT. Без этого он клал HTML
#   рядом с собой (tools/), а рендер искал его в корне — на этом и сломалось.
export METACOD_OUT="$DIR"

echo "-- 1/3 регресс --"
if timeout 280 bash "$PKG/shared/engines/__tests__/run.sh" > "$DIR/.last_run.txt" 2>&1; then
  OK=$(grep -c "  OK  " "$DIR/.last_run.txt")
  SKIP=$(grep -c "ПРОПУЩЕНО" "$DIR/.last_run.txt" || true)
  echo "$OK OK · 0 FAIL · пропущено намеренно: $SKIP" > "$DIR/.last_run_count.txt"
  echo "   $OK OK · 0 FAIL"
else
  FAILS=$(grep -c "^  FAIL" "$DIR/.last_run.txt" || echo "?")
  echo "⛔ РЕГРЕСС НЕ ПРОШЁЛ: FAIL=$FAILS — см. .last_run.txt" > "$DIR/.last_run_count.txt"
  echo "   ⛔ регресс не прошёл — паспорт соберём, но с честной пометкой"
fi

echo "-- 2/3 паспорт из канона --"
node "$DIR/tools/gen_passport.js" || exit 1

echo "-- 3/3 PDF --"
D=$(date +%d%m%Y)
cat > "$DIR/.render_passport.js" <<JS
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const p = await b.newPage();
  await p.goto('file://$DIR/ПАСПОРТ_METACOD_$D.html', { waitUntil: 'networkidle' });
  await p.pdf({ path: '$DIR/ПАСПОРТ_METACOD_$D.pdf', format: 'A4', printBackground: true,
    margin: { top:'0', bottom:'0', left:'0', right:'0' } });
  await b.close(); console.log('   PDF: ПАСПОРТ_METACOD_$D.pdf');
})();
JS
node "$DIR/.render_passport.js"
echo "-- готово --"
