#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
# ПРОВЕРКА ПЕРЕД ЗАПУСКОМ: всё ли задано, и не задано ли заглушками.
#
#   НЕНАСТРОЕННЫЙ КАБИНЕТ ОБЯЗАН СКАЗАТЬ ОБ ЭТОМ ДО ПЕРВОГО БОЛЬНОГО,
#   А НЕ В МОМЕНТ ВЫЗОВА.
#
# ⛔ Запускать ПЕРЕД первым стартом и перед каждым развёртыванием:
#     bash tools/проверить_ключи.sh
#
# Скрипт ничего не меняет и ничего никуда не отправляет. Он только смотрит.
#
# ⚠ ИМЕНА ПЕРЕМЕННЫХ ЛАТИНСКИЕ НАМЕРЕННО. Bash не принимает кириллицу в именах
# переменных. Я наступил на это второй раз за неделю — тот же урок записан
# в шапке shared/engines/__tests__/run.sh. Записываю и здесь.
# ═══════════════════════════════════════════════════════════════════
set -u
DIR="$(cd "$(dirname "$0")/.." && pwd)"
TROUBLE=0
ok()   { echo "  ✓ $1"; }
плохо() { echo "  ⛔ $1"; TROUBLE=1; }
вним() { echo "  ⚠ $1"; }

echo "── КЛИЕНТ (Expo) ──"
CLIENT_ENV="$DIR/client/.env"
if [ ! -f "$CLIENT_ENV" ]; then
  плохо "нет файла client/.env — скопируйте client/.env.example и заполните"
else
  for K in EXPO_PUBLIC_FIREBASE_API_KEY EXPO_PUBLIC_FIREBASE_APP_ID; do
    V=$(grep -E "^$K=" "$CLIENT_ENV" | head -1 | cut -d= -f2- | tr -d '[:space:]')
    if [ -z "$V" ]; then плохо "$K не задан"
    elif echo "$V" | grep -qiE "замените|YOUR_|\.\.\."; then плохо "$K оставлен заглушкой: $V"
    else ok "$K задан"; fi
  done
  # ⚠ Ключ клиента НЕ секрет, но и в общий репозиторий его класть незачем.
  if [ -f "$DIR/.gitignore" ] && grep -q "^client/.env$\|^\.env$\|\*\*/.env" "$DIR/.gitignore"; then
    ok ".env исключён из репозитория"
  else
    вним ".env не указан в .gitignore — ключ клиента не секрет, но порядок важен"
  fi
fi

echo "── СЕРВЕР (Firebase Functions) ──"
if [ ! -f "$DIR/server/.env" ]; then
  вним "нет server/.env — версия текста согласия возьмётся по умолчанию (v1)"
else
  W=$(grep -E "^CONSENT_TEXT_VERSION=" "$DIR/server/.env" | head -1 | cut -d= -f2- | tr -d '[:space:]')
  [ -n "$W" ] && ok "версия текста согласия: $W" || вним "CONSENT_TEXT_VERSION пуст — будет v1"
fi

if command -v firebase >/dev/null 2>&1; then
  if firebase functions:secrets:access ANTHROPIC_API_KEY >/dev/null 2>&1; then
    ok "секрет ANTHROPIC_API_KEY доступен"
  else
    плохо "секрет ANTHROPIC_API_KEY не задан: firebase functions:secrets:set ANTHROPIC_API_KEY"
    echo "     (без него разбор пойдёт ЗАПАСНЫМ путём, а он честно говорит «разбор не выполнен»)"
  fi
else
  вним "firebase CLI не найден — секрет проверить не могу: npm i -g firebase-tools"
fi

echo "── ПРАВИЛА И РОЛИ ──"
[ -f "$DIR/server/firestore.rules" ] && ok "правила доступа на месте" \
  || плохо "нет server/firestore.rules — база останется открытой"
[ -f "$DIR/tools/назначить_роль.js" ] && ok "скрипт назначения ролей на месте" \
  || плохо "нет tools/назначить_роль.js"
echo "  ⚠ ПОМНИТЕ: пока роль не выставлена, врачей в кабинете НЕТ — все пациенты."
echo "     node tools/назначить_роль.js врач@почта doctor"

echo "── ПРОВЕРКИ КАБИНЕТА ──"
if [ -f "$DIR/shared/engines/__tests__/run.sh" ]; then
  ok "регресс на месте: bash shared/engines/__tests__/run.sh"
else
  плохо "нет регресса — без него развёртывать нельзя"
fi

echo
if [ "$TROUBLE" = "0" ]; then
  echo "✓ ГОТОВО К ЗАПУСКУ. Ничего не пропущено."
  exit 0
fi
echo "⛔ НЕ ГОТОВО. Исправьте отмеченное выше и запустите проверку снова."
exit 1
