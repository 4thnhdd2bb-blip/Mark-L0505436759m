#!/usr/bin/env node
// ═══════════════════════════════════════════════════════════════════
// НАЗНАЧИТЬ РОЛЬ ВРАЧА. Без этого шага ВРАЧЕЙ В КАБИНЕТЕ НЕТ.
//
//   РОЛЬ ЖИВЁТ В ТОКЕНЕ, А НЕ В БАЗЕ И НЕ В ПРИЛОЖЕНИИ.
//
// ⛔⛔ ЗАЧЕМ ЭТОТ СКРИПТ. Кабинет различает три роли: подписывающий врач
// (claim litvak), врач (claim doctor) и пациент (без claim). По умолчанию
// вошедший — ПАЦИЕНТ: неизвестность трактуется в пользу осторожности.
//
// Это значит, что сразу после развёртывания НИ ОДИН человек не является
// врачом, и разбора не получит никто. Роль выставляется этим скриптом —
// один раз на каждого врача.
//
// ⭐ Почему не кнопкой в приложении: роль, которую можно выбрать в клиенте,
// подделывается одной правкой. Custom claims подписываются Firebase и
// приходят в токене, который сервер проверяет сам.
//
// ЗАПУСК:
//   cd server && npm install
//   GOOGLE_APPLICATION_CREDENTIALS=/путь/к/service-account.json \
//     node ../tools/назначить_роль.js врач@почта.example doctor
//   GOOGLE_APPLICATION_CREDENTIALS=… node ../tools/назначить_роль.js litvak@… litvak
//
// Служебный ключ: консоль Firebase → Project settings → Service accounts →
// Generate new private key. ⛔ ЭТО НАСТОЯЩИЙ СЕКРЕТ: он даёт полный доступ
// к проекту. Не класть в репозиторий, не пересылать в мессенджере.
// ═══════════════════════════════════════════════════════════════════
'use strict';

const admin = require('firebase-admin');

const почта = process.argv[2];
const роль = process.argv[3];

if (!почта || !роль) {
  console.error('⛔ Как запускать: node назначить_роль.js <почта> <doctor|litvak|пациент>');
  process.exit(2);
}
if (['doctor', 'litvak', 'пациент'].indexOf(роль) < 0) {
  console.error('⛔ Роль может быть только: doctor · litvak · пациент');
  console.error('   doctor  — врач: получает разбор, подписывает, видит карты');
  console.error('   litvak  — подписывающий врач: то же плюс внутренний слой L1');
  console.error('   пациент — снимает обе роли');
  process.exit(2);
}
if (!process.env.GOOGLE_APPLICATION_CREDENTIALS) {
  console.error('⛔ Не задан GOOGLE_APPLICATION_CREDENTIALS — путь к служебному ключу.');
  console.error('   Консоль Firebase → Project settings → Service accounts → Generate new private key.');
  process.exit(2);
}

admin.initializeApp({ credential: admin.credential.applicationDefault() });

(async () => {
  try {
    const u = await admin.auth().getUserByEmail(почта);
    // ⛔ Claims ЗАМЕЩАЮТСЯ целиком, а не дописываются: роль, снятая наполовину,
    // хуже невыставленной. «пациент» снимает обе роли явно.
    const claims = роль === 'litvak' ? { litvak: true, doctor: true }
      : роль === 'doctor' ? { doctor: true }
      : {};
    await admin.auth().setCustomUserClaims(u.uid, claims);
    console.log('✓ Роль выставлена: ' + почта + ' → ' + JSON.stringify(claims));
    console.log('⚠ Человек должен ВЫЙТИ И ВОЙТИ ЗАНОВО: роль приходит в новом токене.');
    console.log('  До этого приложение будет показывать ему пациентский контур.');
    process.exit(0);
  } catch (e) {
    console.error('⛔ Не получилось: ' + (e && e.message ? e.message : String(e)));
    console.error('  Если «user not found» — человек ещё ни разу не входил в приложение.');
    process.exit(1);
  }
})();
