# METACOD-Omer · v4J — §2L (порог M-D, флаг→тест, гигиена вывода) + три эталона приёмки

Дата: 2026-09-13. Слой L1. Обратная совместимость: §2J, §2J.1, §2K не изменены.

## Что добавлено

- `shared/data/diagnosis_algorithm_canon.json` (v1.3): `порог_md` (M-D1/M-D2/M-D3 с явными
  критериями и поведением при нехватке данных), `флаг_тест` (карта из 10 флагов → обязательные
  тесты).
- `shared/engines/consistency.ts` (НОВЫЙ):
  - `mdSubtype()` — подтип M-D по порогу; нет данных → **консервативно M-D2** + `assumed:true` +
    запрос PA50/альбумина/динамики веса. Жёсткий запрет катаболиков включается ПО ПОРОГУ, а не по
    факту осушающих в схеме (дефект случая Итамара).
  - `checkFlagTest()` — каждый красный флаг обязан иметь подтверждающий тест в шагах 3–4;
    возвращает пробелы (ловит дефект Efi: флаг кровотечения без FIT).
  - `dedupeSteps()` / `canonicalKey()` / `droppedWithoutBasis()` — слияние дублей (ЭКГ×3,
    ЭхоКГ×4) и отбрасывание шаблонов без основания («после пластики/протеза» у пациента без
    операции).
- `shared/data/golden/` (НОВОЕ): `golden_wagner.json`, `golden_m77.json`, `golden_preston.json`
  + `SCHEMA.md`. Три эталона под новые слои, схема выведена из отчёта приёмки.
- Тест: +16 проверок. Итого **59/59**.

## Ещё один найденный баг того же рода
В `canonicalKey` стояли `\bэкг\b` и `\bk\b` — `\b` в JavaScript не работает с кириллицей, из-за
чего дедупликация молча не склеивала «ЭКГ» и «ЭКГ (брадикардия…)». Исправлено. Это второй случай
той же ошибки за день — **проверьте у себя все кириллические шаблоны на `\w` и `\b`**.

## Проверка
    tsc ... --resolveJsonModule --rootDir shared --outDir _buildA \
        shared/engines/diagnosisAlgorithm.ts shared/engines/phaseTransition.ts \
        shared/engines/consistency.ts shared/engines/solGel.ts
    cp shared/data/*.json _buildA/data/ && node shared/engines/__tests__/diagnosisAlgorithm.test.js  # 59/59
Типизация shared: `tsc --noEmit` exit 0. validated:false.
