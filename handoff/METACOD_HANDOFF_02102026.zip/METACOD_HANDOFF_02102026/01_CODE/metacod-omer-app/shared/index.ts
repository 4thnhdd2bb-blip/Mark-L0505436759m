// METACOD-Omer · shared/index.ts — единая точка импорта движков
export * from './types';
export * from './engines/guard';
export * from './engines/solGel';
export * from './engines/membraneEngine';
export * from './engines/phaseEngine';
export * from './engines/phaseMatrix';
export * from './engines/drugSelect';
export * from './engines/differential';
export * from './engines/report';
export * from './engines/diagnosisAlgorithm';
export * from './engines/phaseTransition';
export * from './engines/consistency';
export * from './engines/membraneLibrary';
export * from './engines/compartments';
export * from './engines/membraneGate';
export * from './engines/subjugation';
export * from './engines/energyFilter';
export * from './engines/clinch';
export * from './engines/geneLayer';
export * from './engines/geneSuspicion';
export * from './engines/chargeLayer';
export * from './engines/reviciLayer';
export * from './engines/garkavi';
export * from './engines/tom4';
export * from './engines/surveyCrosswalk';
export * from './engines/energyGrid';
export * from './engines/phaseUsin';
export * from './engines/quantityQuality';
export * from './engines/gateSixEnergies';
export * from './engines/gateSubstanceAxis';
export * from './engines/membraneOpenClose';
export * from './engines/geroEvidence';
export * from './engines/chronoLayer';
export * from './engines/protocol';
export * from './engines/pipeline';
export * from './engines/coreContract';
export * from './engines/redFlags';
export * from './engines/supplements';
export * from './engines/outputGate';
export * from './engines/prescribeGate';
export * from './engines/planGuards';
export * from './engines/gelSolDrugs';
export * from './engines/gelSolClasses';
export * from './engines/gelSolEffects';
export * from './engines/gelSolRoles';
export * from './engines/gelSolRoot';
export * from './engines/gelSolYinYang';
// §4T — расширение базы до индекса 658 (Р-ГЕЛЬЗОЛЬ-25, подписано 22.09.2026).
// ⛔ drugbase.json не изменён: расширение — слой поверх подписанного.
export * from './engines/baseExtend';
export * from './engines/baseTable';
export * from './engines/cabinetApi';

// §4К — окно чтения ответа (слово врача 25.09.2026 «Запиши это в канон»).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО: каждая строка таблицы несёт `подписано: false`.
export * from './engines/readWindow';

// §4Л — когда выбран другой ход (слово врача 25.09.2026 «Запиши это в канон»).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО: каждая строка таблицы несёт .
export * from './engines/otherChoice';

// §4М — прежде чем назначить (слово врача 25.09.2026 «Запиши это в канон»).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО.
export * from './engines/priorEvidence';

// §4Н — принцип миеломы (слово врача 26.09.2026 «Запиши это в канон»).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО.
export * from './engines/myelomaPrinciple';

// §4О — принцип острой почки (слово врача 26.09.2026 «Запиши это в канон»).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО.
export * from './engines/acuteKidney';

// ⚠ ПРАВИЛО ИМЁН В СЛОЯХ (введено 18.09.2026, после третьего столкновения подряд).
// Бочка реэкспортирует всё звёздочкой, поэтому ДВА слоя с функцией summary() или
// openQuestions() ломают сборку — а тесты этого не видят, они импортируют модули напрямую.
// Так уже падали energyGrid.byEnergy против drugSelect.byEnergy, а сегодня —
// quantityQuality против gateSixEnergies сразу по двум именам.
// Поэтому КАЖДЫЙ слой даёт своим общим функциям СВОЙ ПРЕФИКС: qqSummary, gateSummary,
// qqOpenQuestions, gateOpenQuestions. Общих имён вроде summary/openQuestions/byEnergy
// в слоях быть не должно.
//
// ⚠ НЕ РЕЭКСПОРТИРУЮТСЯ НАМЕРЕННО (проверено tsc 18.09.2026):
//   phaseTransitionEngine — его ARC и Phase сталкиваются с phaseEngine и types;
//   releaseLayer — его releaseGate сталкивается с protocol.releaseGate.
// Оба живые и покрыты тестами, но подключаются ПРЯМЫМ импортом по пути,
// а не через бочку shared/index.ts. Звёздочный реэкспорт здесь сломал бы сборку.

// §4П — точка созревания (слово врача 27.09.2026 «пиши в канон, всё правильно»).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО.
export * from './engines/maturationCheckpoint';

// §4Т — маски до вектора (перенос правила SKILL.md в канон, 28.09.2026).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО: Р-МАСКА-1 открыт.
export * from './engines/masks';

// §4У — предохранительный контур: проверка готового разбора (28.09.2026).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО.
export * from './engines/safetyGate';

// §4Ф — слой обогащения: семнадцать движков знания на пути разбора (28.09.2026).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО.
export * from './engines/enrich';

// ОЧЕРЕДЬ НА ПОДПИСЬ: чем снимается validated:false (28.09.2026).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО: Р-ПОДПИСЬ-1 открыт.
export * from './engines/signQueue';

// §4V — почечный синдром: шаг НОЛЬ (28.09.2026, потерянный слой восстановлен).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО.
export * from './engines/renalSyndrome';

// §4W — блок отёка: узел решения (28.09.2026, потерянный слой восстановлен).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО.
export * from './engines/edemaBlock';

// СВЯЗКА ЖАЛОБ С АНАЛИЗАМИ: тело не врёт, жалоба первична (28.09.2026).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО.
export * from './engines/complaintGates';

// ПОСЛЕДОВАТЕЛЬНОСТЬ РАЗБОРА: восемь шагов порядка врача (28.09.2026).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО.
export * from './engines/sequence';

// СОГЛАСИЕ ПАЦИЕНТА: когда разбор вести нельзя (28.09.2026).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО: Р-СОГЛАСИЕ-1 открыт.
export * from './engines/consent';

// ПРИЁМ АНКЕТЫ В РАЗБОР: текст анкеты становится жалобами и анализами (28.09.2026).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО.
export * from './engines/surveyIntake';

// ПАЦИЕНТСКИЙ КОНТУР: другой документ, а не укороченный разбор (28.09.2026).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО.
export * from './engines/patientContour';

// ЗАГРУЗКА СНИМКА: фотография документа становится данными (28.09.2026).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО.
export * from './engines/imageIntake';

// СЛОЙ ДЕЙСТВИЙ: что человек может сделать сегодня (28.09.2026, Р-ПАЦИЕНТ-2).
// ⛔ ЗАПИСАНО, НЕ ПОДПИСАНО.
export * from './engines/lifestyleActions';

// ТОЖДЕСТВО ЛИЧНОСТИ: Р-ФИШЕР-4 переписан подписью врача 29.09.2026.
// СВЯЗНОСТЬ КЛИНИЧЕСКОЙ КАРТИНЫ НЕ ЕСТЬ ДОКАЗАТЕЛЬСТВО ТОЖДЕСТВА ЛИЧНОСТИ.
// ⛔ ЗАПИСАНО ПО ПОДПИСИ, САМА ФОРМУЛИРОВКА — ПОСТРОЙКА ДВИЖКА, см. Р-ФИШЕР-10/11/12.
export * from './engines/identityGate';

// ПЕРВИЧНЫЙ ФИЛЬТР ЖАЛОБЫ (ТРИАЖ), 29.09.2026. Слова больного → вход подписанных
// красных флагов. До этого дня такого пути НЕ СУЩЕСТВОВАЛО: «боль в груди» давала план.
// ⛔ СЛОВАРЬ ПОСТРОЕН ДВИЖКОМ И НЕ ПОДПИСАН — Р-ТРИАЖ-1.
export * from './engines/triage';

// ЦЕНА ГОМЕОСТАЗА, §4Я. ПОДПИСЬ ВРАЧА 29.09.2026.
// НОРМА, УДЕРЖАННАЯ БОЛЬШИМ УСИЛИЕМ РЕГУЛЯТОРА, — ЭТО ПРЕДБОЛЕЗНЬ.
// ⭐ Одиночное значение говорит, ЧТО сломано; пара говорит, ГДЕ сломано.
export * from './engines/homeostasisCost';

// РЕЕСТР КАНОНА: у каждого ключа исполнитель либо названная причина (28.09.2026).
export * from './engines/canonRegistry';

// ⚠ НЕ РЕЭКСПОРТИРУЮТСЯ НАМЕРЕННО (проверено tsc 28.09.2026):
//   autoimmuneClone — его СКЕЛЕТ_ВЫКЛЮЧЕНИЯ сталкивается с maturationCheckpoint;
//   phaseEnergy — его ХодФазы сталкивается с acuteKidney.
// Оба столкновения — не случайность имён, а содержание. §4Р и §4П намеренно держат
// ОДИН И ТОТ ЖЕ скелет семьи выключения, потому что аутоиммунная болезнь и растущий
// клон — одна семья. А «ход фазы» у острой почки и у дуги — разные вещи под одним
// словом, и это ровно то различение, ради которого заведён §4С.
// Оба движка живые и покрыты проверками (70 и 51), подключаются ПРЯМЫМ импортом по пути.
export * from './engines/dxDifferential';
export * from './engines/nextStep';
// TS2308 (01.10.2026): «Кандидат» есть и в imageIntake (кандидат снимка), и в nextStep
// (кандидат шага). Без явного разрешения tsc падал, и `npx tsc && firebase deploy`
// не доходил до выкладки. Имя «Кандидат» остаётся за снимком (он был первым),
// кандидат шага выходит под своим именем. Потребителей по общему имени нет.
export type { Кандидат } from './engines/imageIntake';
export type { Кандидат as КандидатШага } from './engines/nextStep';
export * from './engines/ddiGuard';
export * from './engines/doseRange';
export * from './engines/drugName';
// ⭐⭐ БИБЛИОТЕКА КОМОРБИДНОСТИ: 1200 сочетаний, разобранных врачом. Прецедент,
// а не назначение; исполняется через §4Ф (обогащение) — бочка только перечисляет.
export * from './engines/comorbidity';
// ⭐⭐ §4Z ПРИНЦИП НЕЙРОДЕГЕНЕРАЦИИ: ключ жил с 25.09.2026 без движка и числился
// долгом в собственном реестре. Движок заведён 01.10.2026 по слову «Заводи правильно».
export * from './engines/neuroDegeneration';
