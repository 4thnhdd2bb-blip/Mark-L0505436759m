// METACOD-Omer · shared/engines/releaseLayer.ts
// §Е Мастер-Стандарта v4 — СЛОЙ ПОДАЧИ: язык · бренд · атрибуция по рынку.
// Наружный (конвенциональный) слой. Работает ПОВЕРХ стража guard.ts (внутренние термины).
// Обратная совместимость: язык по умолчанию 'ru' → поведение прежнего рендера не меняется.
//
//  Е1 LANGUAGE GUARD — EN/HE не содержат кириллицы; служебные строки через LABELS.
//  Е2 АТРИБУЦИЯ — без личного имени врача; RU/HE — «Тель-Авив, Израиль», EN — без локации.
//  Е3 БРЕНД/ДИСКЛЕЙМЕР по рынку — RU/HE сохраняют бренд+validated:false; EN — без бренда/бейджа/токена.

export type Lang = 'ru' | 'en' | 'he';

/** Локализация служебных строк рендера (никаких хардкод-строк одного языка в шаблоне). */
export interface Labels {
  title: string;
  s1: string;
  s2: string;
  cannotMiss: string;
  s3: string;
  step1: string;
  step2: string;
  step3: string;
  step4: string;
  s4: string;
  s5: string;
  /** соединители строки гипотезы */
  hypExplains: string;
  hypConfirm: string;
  /** футер по рынку (может быть пустым — тогда строка футера не выводится) */
  footer: string;
}

export const LABELS: Record<Lang, Labels> = {
  // RU — байт-в-байт как в прежнем report.ts (нулевое изменение поведения)
  ru: {
    title: '# Клиническое заключение (EBM)\n',
    s1: '## 1. Клиническая логика\n',
    s2: '## 2. Рабочие гипотезы (ранжированы)',
    cannotMiss: '\n**Параллельно не пропустить:** ',
    s3: '## 3. Полное обследование (по шагам)',
    step1: '**Шаг 1 — анамнез/осмотр:** ',
    step2: '**Шаг 2 — лаборатория:** ',
    step3: '**Шаг 3 — визуализация:** ',
    step4: '**Шаг 4 — специалисты:** ',
    s4: '## 4. Красные флаги\n',
    s5: '## 5. Итог\n',
    hypExplains: ' — объясняет: ',
    hypConfirm: '. Подтвердить: ',
    footer: '\n_validated:false · поддержка решения, не замена врача · METACOD-Omer_',
  },
  // EN (американский рынок) — §Е3: без бренда METACOD, без бейджа, без токена validated:false, без локации.
  en: {
    title: '# Clinical conclusion (EBM)\n',
    s1: '## 1. Clinical reasoning\n',
    s2: '## 2. Working hypotheses (ranked)',
    cannotMiss: '\n**In parallel, do not miss:** ',
    s3: '## 3. Full work-up (stepwise)',
    step1: '**Step 1 — history/exam:** ',
    step2: '**Step 2 — laboratory:** ',
    step3: '**Step 3 — imaging:** ',
    step4: '**Step 4 — specialists:** ',
    s4: '## 4. Red flags\n',
    s5: '## 5. Summary\n',
    hypExplains: ' — explains: ',
    hypConfirm: '. Confirm: ',
    footer: '', // §Е3: EN — строка бренда/дисклеймера не выводится (смысл — словами в теле)
  },
  // HE (RTL) — §Е2/Е3: бренд + validated:false сохранены, локация «תל אביב, ישראל».
  he: {
    title: '# מסקנה קלינית (EBM)\n',
    s1: '## 1. היגיון קליני\n',
    s2: '## 2. השערות עבודה (מדורגות)',
    cannotMiss: '\n**במקביל, לא לפספס:** ',
    s3: '## 3. בירור מלא (שלב אחר שלב)',
    step1: '**שלב 1 — אנמנזה/בדיקה:** ',
    step2: '**שלב 2 — מעבדה:** ',
    step3: '**שלב 3 — הדמיה:** ',
    step4: '**שלב 4 — מומחים:** ',
    s4: '## 4. דגלים אדומים\n',
    s5: '## 5. סיכום\n',
    hypExplains: ' — מסביר: ',
    hypConfirm: '. לאשר: ',
    footer: '\n_validated:false · תמיכה בהחלטה, לא תחליף לרופא · תל אביב, ישראל_',
  },
};

/** Кириллица (для LANGUAGE GUARD в EN/HE). */
const CYRILLIC = /[А-Яа-яЁё]/g;

/** §Е3(d): убрать бренд METACOD из тела EN (нейтральные формулировки). */
const EN_BODY_REPLACE: Array<[RegExp, string]> = [
  [/METACOD questionnaire/g, 'clinical questionnaire'],
  [/METACOD[-\s]?Omer/g, 'clinical report'],
  [/METACOD edema module/g, 'edema-protocol module'],
  [/\bvalidated:false\b/g, ''],
  [/\bMETACOD\b/g, ''],
];

export function scrubEnBody(text: string): string {
  let out = text;
  for (const [re, sub] of EN_BODY_REPLACE) out = out.replace(re, sub);
  // подчистить возможные двойные пробелы/разделители после вырезаний
  return out.replace(/ {2,}/g, ' ').replace(/·\s*·/g, '·').replace(/·\s*_/g, '_');
}

export interface ReleaseCheck {
  ok: boolean;
  problems: string[];
}

/**
 * Гейт выпуска §Е (поверх стража внутренних терминов).
 * EN/HE: кириллица = 0. EN: остатков METACOD/validated:false нет.
 * НЕ мутирует текст — только проверяет (для сервера/тестов/аудита).
 */
export function releaseGate(text: string, lang: Lang): ReleaseCheck {
  const problems: string[] = [];
  if (lang === 'en' || lang === 'he') {
    const cyr = text.match(CYRILLIC);
    if (cyr && cyr.length) problems.push(`${lang}: кириллица ${cyr.length} (Е1) — не выпускать`);
  }
  if (lang === 'en') {
    if (/\bMETACOD\b/.test(text)) problems.push('EN: остаток «METACOD» (Е3)');
    if (/\bvalidated:false\b/.test(text)) problems.push('EN: остаток «validated:false» (Е3)');
  }
  return { ok: problems.length === 0, problems };
}

/** Применить рыночную подачу к готовому markdown (вызывается рендером). */
export function applyMarket(md: string, lang: Lang): string {
  return lang === 'en' ? scrubEnBody(md) : md;
}
