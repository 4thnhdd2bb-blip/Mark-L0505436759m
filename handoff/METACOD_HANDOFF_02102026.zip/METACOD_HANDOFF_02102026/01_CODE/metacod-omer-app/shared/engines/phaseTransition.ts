// METACOD-Omer · shared/engines/phaseTransition.ts
// §2K — СЛОЙ ФАЗОВОГО ПЕРЕХОДА (атлас переходов v2).
//
// Отвечает на три вопроса, которых не было в §2J:
//   1) РЕЖИМ: процесс ТЕЧЁТ или ЗАВИС (это первый вопрос, раньше типа люка);
//   2) ТИП ЛЮКА: что физически держит пациента в фазе (8 типов) и какой ПЕРВЫЙ ход;
//   3) СТРАХОВКА: чем закрыт перекат в противоположный полюс + какие can't-miss гейты
//      блокируют выполнение вектора.
//
// Плюс замена препарата по классу АТХ (недоступность), в пару к §2J.1 (замена при запрете).
//
// Слой ВНУТРЕННИЙ (L1). validated:false. Классы — векторы, не дозы; дозы, красные флаги,
// онкология — за подписывающим врачом.

import type { PatientInput, Membrane, Energy } from '../types';
import canon from '../data/diagnosis_algorithm_canon.json';

const LOCKS = ((canon as any)['типы_люка'] ?? []) as Array<Record<string, string>>;
const GUARDS = (((canon as any)['страховка_от_переката'] ?? {})['карта'] ?? []) as Array<Record<string, string>>;
const GATES = ((canon as any)['гейты_cant_miss'] ?? []) as Array<Record<string, string>>;
const CLUSTERS = ((canon as any)['кластеры_замены_атх'] ?? []) as Array<Record<string, string>>;
const AUTO_CLUSTERS = (((canon as any)['кластеры_замены_авто'] ?? {})['список'] ?? []) as Array<Record<string, string>>;
const CAUSE = ((canon as any)['закон_причина_защита'] ?? {}) as Record<string, any>;

export type PhaseMode = 'течёт' | 'завис' | 'неизвестно';

export interface LockAssessment {
  id: string;            // L1..L8
  name: string;
  firstMove: string;     // ЧТО СНИМАЕМ (первый ход — всегда снятие, не добавление)
  guard: string;         // страховка от переката
  heldBy: string[];      // что именно держит люк в этих данных
  confidence: 'высокая' | 'средняя' | 'низкая';
}

export interface GateHit { trigger: string; gate: string; rule: string; }
export interface GuardNote { vector: string; overshoot: string; guard: string; }
export interface ClassSubstitution {
  drug: string; cls: string; quenches: string; alternatives: string;
  source: 'курированный' | 'авто'; atc?: string; note?: string;
}

export interface TransitionAssessment {
  mode: PhaseMode;
  modeWhy: string;
  lock?: LockAssessment;
  gates: GateHit[];        // can't-miss: гатируют вектор, выполняются ПЕРВЫМИ
  guards: GuardNote[];     // страховка от переката для выбранного направления
  causeProtection?: string; // закон причина⇄защита, если распознан
  needsMoreData: string[];
}

// ── вспомогательные распознаватели ──────────────────────────────────
const DRYING = /SGLT-?2|глифлозин|форсига|джардинс|дапаглифлозин|эмпаглифлозин|петлев|фуросемид|торасемид|энтресто|сакубитрил|DPP-?4|глиптин|ситаглиптин/i;
const CATABOLIC = /GLP-?1|семаглутид|лираглутид|дулаглутид|тирзепатид|ozempic|оземпик|метформин|берберин/i;
const ANTICOAG = /апиксабан|ривароксабан|эдоксабан|дабигатран|варфарин|эноксапарин|клексан/i;
const BETA = /бисопролол|метопролол|карведилол|небиволол|пропранолол/i;
const THYROID = /левотироксин|эутирокс|L-?T4|лиотиронин/i;

const num = (v: unknown): number | undefined => {
  if (typeof v === 'number') return v;
  if (typeof v === 'string') { const m = v.replace(',', '.').match(/-?\d+(\.\d+)?/); if (m) return parseFloat(m[0]); }
  return undefined;
};
const lab = (p: PatientInput, re: RegExp): number | undefined => {
  for (const k of Object.keys(p.labs ?? {})) if (re.test(k)) { const n = num((p.labs as any)[k]); if (n !== undefined) return n; }
  return undefined;
};

// ── 1. РЕЖИМ: течёт или завис ───────────────────────────────────────
/**
 * Режим определяется ДИНАМИКОЙ, а не статическим снимком. Если данных о динамике нет —
 * честно 'неизвестно' + запрос данных (а не догадка «завис»).
 */
export function phaseMode(p: PatientInput, opts?: { improving?: boolean; chronicMonths?: number }): { mode: PhaseMode; why: string; need: string[] } {
  const text = ((p.complaints ?? []).join(' · ') + ' ' + (p.goal ?? '')).toLowerCase();
  if (opts?.improving === true) return { mode: 'течёт', why: 'маркёры/симптомы улучшаются во времени — вмешательство минимальное, охранять ворота', need: [] };
  if (opts?.improving === false) return { mode: 'завис', why: 'динамики нет — искать двигатель и разблокировать', need: [] };
  if (/улучш|разреш|на фоне лечения уход|спад|выздоравл|реконвалесц/.test(text))
    return { mode: 'течёт', why: 'в жалобах есть признак разрешения процесса', need: [] };
  if (/месяц|годами|хронич|не проходит|без динамики|давно/.test(text) || (opts?.chronicMonths ?? 0) >= 3)
    return { mode: 'завис', why: 'хронизация без динамики', need: [] };
  return { mode: 'неизвестно', why: 'нет данных о динамике — режим не определён, по умолчанию действовать консервативно', need: ['динамика маркёров (2 точки во времени)', 'динамика веса', 'длительность симптома'] };
}

// ── 2. ТИП ЛЮКА ─────────────────────────────────────────────────────
function lockRow(id: string): Record<string, string> | undefined { return LOCKS.find((l) => l['id'] === id); }

function asLock(id: string, heldBy: string[], confidence: LockAssessment['confidence']): LockAssessment | undefined {
  const r = lockRow(id);
  if (!r) return undefined;
  return { id, name: r['название'], firstMove: r['манёвр'], guard: r['страховка'], heldBy, confidence };
}

/**
 * Тип люка по уже имеющимся данным. Порядок проверок = порядок приоритета безопасности:
 * can't-miss (L8) → кровь-гипервязкость (L4) → причина⇄защита (L6) → фиброз+вето (L5)
 * → истощение drug-driven (L1) → десинхроноз (L2) → избыток (L3) → откат (L7).
 */
/**
 * ⚠ ОТРИЦАНИЕ. Найдено на разборе 23ж/СД1: жалоба «лихорадки при эпизодах, как правило, НЕТ»
 * срабатывала на /лихорад/ и поднимала люк L8 с ложным основанием. Признак нельзя искать
 * по всему тексту: его надо искать в КЛАУЗЕ и проверять, что клауза не отрицательная.
 * Это тот же класс дефекта, что кириллические \w и \b — молчаливый, без ошибки.
 */
// ⚠⚠ И ЗДЕСЬ ТОЖЕ: первая версия была /\b(не|нет|без)\b/ — и молча не срабатывала,
// потому что в JS \b ASCII-only и к кириллице неприменим (третий случай в проекте).
// Границы задаём явно через класс кириллицы, без \b.
const NEG = /(^|[^а-яёa-z])(не|нет|без|отриц|отсутств|исключ|никогда)([^а-яёa-z]|$)/i;
export function hasSign(text: string, re: RegExp): boolean {
  // дробим ТОЛЬКО по границам жалоб: запятая внутри «лихорадки при эпизодах, как правило, нет»
  // отрезала бы отрицание от признака — ровно этот дефект и был найден.
  for (const clause of (text || '').split(/[·;\n]|\s—\s/)) {
    if (re.test(clause) && !NEG.test(clause)) return true;
  }
  return false;
}
/** Явно отрицаемый признак — это САМОСТОЯТЕЛЬНЫЙ факт (напр. «без лихорадки» = гейт нейтропении). */
export function isDenied(text: string, re: RegExp): boolean {
  for (const clause of (text || '').split(/[·;\n]|\s—\s/)) {
    if (re.test(clause) && NEG.test(clause)) return true;
  }
  return false;
}

export function detectLock(p: PatientInput, ctx: { membrane: Membrane; energies: Energy[]; phase?: string; mode?: PhaseMode }): LockAssessment | undefined {
  const drugs = p.currentDrugs ?? [];
  const text = (p.complaints ?? []).join(' · ').toLowerCase();
  const isMD = /^M-D/.test(ctx.membrane);
  const hct = lab(p, /hct|гематокрит/i);
  const hb = lab(p, /\bhb\b|гемоглобин/i);
  const hrrr = lab(p, /hr\s*\/\s*rr|hr_rr|вегетативн/i);

  // L8 — напряжение векторов: M-D + онко-подозрение (признак берётся ТОЛЬКО неотрицаемый)
  if (isMD && hasSign(text, /потер[а-яё]*\s*вес|похудан|ночн[а-яё]*\s*потлив|лихорад|лимфом|онко|b-симптом/))
    return asLock('L8', ['потеря веса читается двумя векторами: мальабсорбция/истощение ⇄ опухоль'], 'средняя');

  // L6 — причина⇄защита, форма «удалённый орган»: вмешательство на очаге не удержало процесс.
  // Неудача органного вмешательства — доказательство неверной мишени, а не показание повторить.
  if (/тонзиллэктоми|удален|удалён|резекц|абляц|операц|иссечен/.test(text) &&
      /рецидив|верну|повтор|сохран|част[а-яё]* эффект|неэффект/.test(text))
    return asLock('L6', [
      'вмешательство на органе-очаге не удержало процесс — убрана ЗАЩИТА (место, где видно), а не ПРИЧИНА',
      'повторное органное вмешательство противопоказано логикой закона: мишень выбрана неверно',
    ], 'высокая');

  // L4 — кровь-гипервязкость
  if ((hct !== undefined && hct >= 50) || (hb !== undefined && hb >= 17) || /эритроцитоз|гипервязк|полицитем/.test(text))
    return asLock('L4', ['эритроцитоз/гипервязкость: кровь в гель-сдвиге'], 'высокая');

  // L6 — причина⇄защита (отёк/вес при Холоде-гипотиреозе)
  if (/гипотиреоз|микседем|ттг|щитовид/.test(text) && /отёк|отек|вес|прибав|зябк|мёрзн|мерзн/.test(text))
    return asLock('L6', ['отёк/вес вторичны к Холод-двигателю (гипотиреоз) — это защита, не мишень'], 'средняя');

  // L5 — фиброз-консолидация + вето безопасности
  if (ctx.membrane === 'M-S' || /фиброз|склероз|рубец|консолидац/.test(text)) {
    const veto = drugs.filter((d) => ANTICOAG.test(d));
    return asLock('L5', veto.length ? ['фиброз/рубец; вето безопасности: ' + veto.join(', ')] : ['фиброз/рубец (M-S)'], 'средняя');
  }

  // L1 — истощение drug-driven
  if (isMD) {
    const dry = drugs.filter((d) => DRYING.test(d));
    const cat = drugs.filter((d) => CATABOLIC.test(d));
    if (dry.length || cat.length)
      return asLock('L1', ['осушающие/катаболики в схеме: ' + [...dry, ...cat].join(', ')], 'высокая');
    return asLock('L1', ['истощение без ятрогенного осушения — искать дефицит субстрата и активный драйвер'], 'низкая');
  }

  // L2 — десинхроноз
  if ((hrrr !== undefined && hrrr > 5) || /десинхрон|симпатик|тревож|бессонниц|сердцебиен/.test(text))
    return asLock('L2', ['автономный перегруз при формально верной терапии'], 'низкая');

  // L3 — избыток метаболический
  if (/^M-A/.test(ctx.membrane))
    return asLock('L3', ['накопление M-A: постоянный энергопоток (переедание/ИР/апноэ) держит в фазе'], 'средняя');

  // L7 — риск отката (движется вперёд)
  if (ctx.mode === 'течёт')
    return asLock('L7', ['процесс разрешается — задача охранять ворота, не толкать'], 'средняя');

  return undefined;
}

// ── 3. СТРАХОВКА ОТ ПЕРЕКАТА ────────────────────────────────────────
export function overshootGuards(direction: string): GuardNote[] {
  const d = (direction || '').toLowerCase();
  const want: RegExp =
    /катаболик/.test(d) ? /катаболик|гасить/i :
    /анаболик/.test(d) ? /анаболик|наполнить/i :
    /антифиброз/.test(d) ? /антифиброз/i :
    /арест|резорбц/.test(d) ? /антифиброз/i : /./;
  return GUARDS.filter((g) => want.test(g['вектор'] ?? ''))
    .map((g) => ({ vector: g['вектор'], overshoot: g['перекат'], guard: g['страховка'] }));
}

// ── 4. CAN'T-MISS ГЕЙТЫ (гатируют вектор) ───────────────────────────
export function cantMissGates(p: PatientInput): GateHit[] {
  // ⚠ текущая схема входит в текст гейтов: ятрогенные гейты (НПВС при ХБП, статин-миопатия)
  // иначе не видны — найдено на разборе 74ж.
  const text = ((p.complaints ?? []).join(' · ') + ' · ' + (p.currentDrugs ?? []).join(' · ')).toLowerCase();
  const hits: GateHit[] = [];
  const add = (i: number) => { const g = GATES[i]; if (g) hits.push({ trigger: g['триггер'], gate: g['гейт'], rule: g['правило'] }); };
  const hb = lab(p, /\bhb\b|гемоглобин/i);
  const hct = lab(p, /hct|гематокрит/i);
  const ferr = lab(p, /ферритин/i);
  const age = p.age ?? 0;

  if (hasSign(text, /потер[а-яё]*\s*вес|похудан/) && hasSign(text, /ночн[а-яё]*\s*потлив|лихорад/)) add(0);
  if (((hct !== undefined && hct >= 50) || (hb !== undefined && hb >= 17)) && /груд|одышк|боль в груди/.test(text)) add(1);
  if (ferr !== undefined && ferr > 300 && hb !== undefined && hb >= 16) add(2);
  if (ferr !== undefined && ferr < 100 && age >= 50) add(3);
  if (hasSign(text, /потер[а-яё]*\s*вес|похудан/) && /крон|вzк|вэк|хронич|ревмат|диабет/.test(text)) add(4);

  // ── гейты слизистой (добавлены разбором 23ж/СД1) ──
  const mucosa = /слизист|глотк|ротоглотк|стоматит|афт|налёт|налет|экссудат|язык|щёк|щек|фарингит|тонзилл|горл/.test(text);
  const recurrent = /рецидив|повтор|эпизод|хронич/.test(text);
  const noFever = isDenied(text, /лихорад|температур/);   // «без лихорадки» — самостоятельный факт
  const candida = /кандидоз|грибк|молочниц/.test(text);
  const autoimmuneEndo = /сд ?1|диабет 1|сахарн[а-яё]* диабет 1|тиреоидит|аутоиммунн/.test(text);
  const lesionNoHisto = /бородав|папиллом|образован|разрастан/.test(text) && !/биопси|гистолог/.test(text);

  if (mucosa && recurrent && noFever) add(5);          // ОАК с формулой в эпизод
  if (autoimmuneEndo && (candida || (mucosa && recurrent))) add(6); // АПС-1/APECED
  if (candida && recurrent && age >= 16) add(7);       // ВИЧ / Ig / наследственная восприимчивость
  if (lesionNoHisto) add(8);                           // биопсия обязательна

  // ── ось ИППП ротоглотки (версия д-ра Литвака) ──
  // ⚠ Эти гейты были в каноне v1.9, но триггеров в движке не было: канон знал, движок молчал.
  const sexuallyActive = /сексуальн[а-яё]* активн|половая жизнь|орально-генитальн|оральн[а-яё]* секс|партнёр|партнер|ИППП|незащищённ/i.test(text);
  const adolescentOrAdult = age >= 14;
  const painlessPlaque = /безболезненн[а-яё]*\s*(бляшк|налёт|налет|очаг|язв)|не болезненн/i.test(text);
  const scc = /плоскоклеточн[а-яё]*\s*рак|карцином|скв[а-яё]*/i.test(text);

  if (mucosa && recurrent && (sexuallyActive || adolescentOrAdult)) add(10); // NAAT глотки + сифилис + ВИЧ
  if (painlessPlaque || (/щёк|щек|язык/.test(text) && recurrent && noFever && sexuallyActive)) add(11); // вторичный сифилис
  if (scc && age < 45) add(9);                          // анемия Фанкони

  // ── ось гипометаболизма и ятрогении у пожилых (разбор 74ж) ──
  const ckd = /болезн[а-яё]*\s*почек|почечн[а-яё]*\s*недостаточн|хбп|скф|нефропат/i.test(text);
  const painkillers = /обезболива|анальгет|нпвс|ибупрофен|диклофенак|напроксен|оптальгин|дипирон/i.test(text);
  const statin = /статин|аторваст|розуваст|симваст/i.test(text);
  const muscleSx = /мышечн[а-яё]*\s*(бол|судорог|слабост)|судорог|миалги|слабость в ног|трудно (встать|ходить)|затруднени[а-яё]*\s*ходьб/i.test(text);
  const thyroidDx = /щитовидн|тиреоид|гипотиреоз|хашимото|аит/i.test(text);
  const noThyroidRx = !/левотироксин|эутирокс|l-?t4|тироксин/i.test(text);
  const autoimmune = /аутоиммун|хашимото|волчан|ревмат/i.test(text);
  const hypoPicture = /мёрзн|мерзн|зябкост|холодн[а-яё]*\s*(кист|стоп|конечност)|медлительност|замедленн|сонливост|запор|сухост[а-яё]*\s*кож/i.test(text);

  if (ckd && painkillers) add(12);                      // НПВС при ХБП
  if (statin && muscleSx && (thyroidDx || hypoPicture)) add(13); // статин-миопатия при гипотиреозе
  if (autoimmune && thyroidDx) add(14);                 // надпочечник до левотироксина
  if (thyroidDx && noThyroidRx && hypoPicture) add(15); // диагноз без препарата

  // ── ось метаболического курса (протокол висцерального жира, канон v2.9) ──
  // ⚠ Оба гейта закрывают разрывы, найденные на разборе протокола, а не на пациенте:
  // канон знал запрет, но триггера не было — ровно тот же класс дефекта, что с гейтами ИППП.
  const sglt2 = /sglt-?2|глифлозин|эмпаглифлозин|дапаглифлозин|канаглифлозин|форсига|джардинс/i.test(text);
  const catabolicCourse = /семаглутид|тирзепатид|лираглутид|дулаглутид|glp-?1|метформин|берберин|глифлозин|sglt-?2/i.test(text);
  const energyDeficit = /дефицит[а-яё]*\s*энерги|дефицит калор|низкоуглеводн|кето-?диет|интервальн[а-яё]*\s*голодан|окно питания|etre|голодан|пост(?![а-яё])/i.test(text);
  const weightCourse = /снижени[а-яё]*\s*вес|похуден|ожирен|метаболическ[а-яё]*\s*синдр|висцеральн/i.test(text);
  const musclePlan = /мышечн[а-яё]*\s*масс|фазов[а-яё]*\s*угол|биоимпеданс|сила кисти|динамометр/i.test(text);

  if (sglt2 && energyDeficit) add(16);                       // эугликемический кетоацидоз
  if (catabolicCourse && weightCourse && !musclePlan) add(17); // мембрана не статична: нет плана перепроверки
  return hits;
}

// ── 5. ЗАМЕНА ПО КЛАССУ АТХ (недоступность препарата) ───────────────
/** Пара к §2J.1: там замена при ЗАПРЕТЕ, здесь — при НЕДОСТУПНОСТИ. Цель сохраняется в обоих. */
export function substituteByClass(drug: string): ClassSubstitution | undefined {
  const d = (drug || '').toLowerCase().trim();
  if (!d) return undefined;
  const res = substituteByClassRaw(d, drug);
  return res ? scrubWithdrawn(res) : res;
}

/** Реестр отозванных: такой препарат не предлагается НИКОГДА — ни как назначение, ни как замена. */
const WITHDRAWN = ((canon as any)['отозванные_препараты'] ?? {}) as Record<string, any>;
const WITHDRAWN_LIST = ((WITHDRAWN['список'] ?? []) as Array<Record<string, string>>);
export function withdrawnNote(name: string): string | undefined {
  const n = (name || '').toLowerCase();
  const hit = WITHDRAWN_LIST.find((w) => n.includes((w['препарат'] ?? '').toLowerCase()));
  return hit ? `⛔ ${hit['препарат']} ОТОЗВАН (${hit['причина']}, ${hit['год']}) — замена: ${hit['замена']}` : undefined;
}
function scrubWithdrawn(r: ClassSubstitution): ClassSubstitution {
  const kept = r.alternatives.split('⇄').map((s) => s.trim()).filter(Boolean)
    .filter((n) => !WITHDRAWN_LIST.some((w) => n.toLowerCase().includes((w['препарат'] ?? '').toLowerCase())));
  const self = withdrawnNote(r.drug);
  const note = [self, r.note].filter(Boolean).join(' · ');
  return { ...r, alternatives: kept.join(' ⇄ '), note: note || undefined };
}

function substituteByClassRaw(d: string, drug: string): ClassSubstitution | undefined {
  const stem = d.split(/[\s,(]/)[0];
  const hit = (list: string) => {
    const names = list.toLowerCase().split(/⇄|·|,|\(|\)/).map((x) => x.trim()).filter(Boolean);
    return names.some((n) => {
      const nStem = n.split(/[\s/]/)[0];
      return nStem.length > 3 && (stem.includes(nStem) || nStem.includes(stem));
    });
  };
  // (1) курированный справочник — клинически выверенные классы с заметками и запретами
  for (const c of CLUSTERS) {
    if (hit(c['препараты'] ?? ''))
      return { drug, cls: c['класс'], quenches: c['гасит'], alternatives: c['препараты'],
               source: 'курированный', note: c['заметка'] };
  }
  // (2) авто-охват по (энергия × АТХ-4) из базы 658 — для редких классов
  for (const c of AUTO_CLUSTERS) {
    if (hit(c['препараты'] ?? ''))
      return { drug, cls: c['класс'], quenches: c['гасит'], alternatives: c['препараты'],
               source: 'авто', atc: c['атх'] };
  }
  return undefined;
}

export const CLASS_CLUSTERS = CLUSTERS.map((c) => ({ cls: c['класс'], quenches: c['гасит'], alternatives: c['препараты'], note: c['заметка'] }));
export const AUTO_CLASS_CLUSTERS = AUTO_CLUSTERS.map((c) => ({ atc: c['атх'], cls: c['класс'], quenches: c['гасит'], alternatives: c['препараты'] }));
export const SUBSTITUTION_RULE: string = (canon as any)['правило_замены'] ?? '';
export const LOCK_TYPES = LOCKS;
export const CONTEXT_RULE = ((canon as any)['правило_контекста'] ?? {}) as Record<string, any>;

// ── 6. СБОРКА СЛОЯ ──────────────────────────────────────────────────
export function assessTransition(
  p: PatientInput,
  ctx: { membrane: Membrane; energies: Energy[]; phase?: string; direction: string; improving?: boolean },
): TransitionAssessment {
  const m = phaseMode(p, { improving: ctx.improving });
  const lock = detectLock(p, { membrane: ctx.membrane, energies: ctx.energies, phase: ctx.phase, mode: m.mode });
  const gates = cantMissGates(p);
  const guards = overshootGuards(ctx.direction);

  let causeProtection: string | undefined;
  if (lock?.id === 'L6') {
    const ex = ((CAUSE['примеры'] ?? []) as Array<Record<string, string>>)[0];
    causeProtection = CAUSE['правило'] + (ex ? ` Например: ${ex['защита']} ← ${ex['причина']}; ошибка — ${ex['ошибка']}; верно — ${ex['верно']}.` : '');
  }

  return {
    mode: m.mode,
    modeWhy: m.why,
    lock,
    gates,
    guards,
    causeProtection,
    needsMoreData: m.need,
  };
}
