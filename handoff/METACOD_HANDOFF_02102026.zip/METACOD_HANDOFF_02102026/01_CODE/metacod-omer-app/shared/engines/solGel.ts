// METACOD-Omer · shared/engines/solGel.ts
// Золь = катаболизм/дисперсия/острая жидкость (M-D).
// Гель = анаболизм/консолидация/фиброз/ИР (M-A/M-S).
// Вектор лечения = куда сдвигаем.

import type { Membrane, SolGel } from '../types';

export function solGelOfMembrane(m: Membrane): SolGel {
  if (m === 'M-0') return 'баланс';
  if (m.startsWith('M-A') || m === 'M-S') return 'гель';
  return 'золь'; // M-D*
}

/** Куда двигать лечение: противоположный полюс (принцип полярного противодействия Ревичи). */
export function treatmentVector(m: Membrane): { from: SolGel; to: SolGel; note: string } {
  const cur = solGelOfMembrane(m);
  if (cur === 'золь') return { from: 'золь', to: 'гель', note: 'M-D → анаболический сдвиг: запечатать бислой, стоп-ПОЛ, субстрат' };
  if (cur === 'гель') return { from: 'гель', to: 'золь', note: 'M-A → контролируемый катаболический сдвиг: дренаж, не перекормить' };
  return { from: 'баланс', to: 'баланс', note: 'M-0 → удержание, минимальная схема' };
}
