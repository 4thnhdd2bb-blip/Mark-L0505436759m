// Тест §Е (releaseLayer + report.renderMarkdown). Запуск: node после компиляции в _buildE.
const { renderMarkdown } = require('./_buildE/engines/report.js');
const { releaseGate, scrubEnBody } = require('./_buildE/engines/releaseLayer.js');

let ok = 0, total = 0;
function check(name, cond) { total++; console.log((cond ? '  OK  ' : ' FAIL ') + name); if (cond) ok++; }

const conv = {
  logic: 'Один корень: перегрузка объёмом на фоне ХБП объясняет отёки, одышку и утомляемость.',
  hypotheses: [
    { rank: 1, root: 'Сердечная недостаточность', explains: 'отёки, одышку', confirm: ['NT-proBNP', 'ЭхоКГ'] },
    { rank: 2, root: 'ХБП', explains: 'задержку жидкости', confirm: ['СКФ', 'альбумин'] },
  ],
  cannotMiss: ['тромбоз глубоких вен', 'острый коронарный синдром'],
  workup: {
    step1_history: ['динамика веса', 'приём НПВП'],
    step2_labs: ['NT-proBNP', 'креатинин/СКФ', 'альбумин'],
    step3_imaging: ['ЭхоКГ', 'УЗ вен ног'],
    step4_referrals: ['кардиолог', 'нефролог'],
  },
  redFlags: ['боль в груди', 'выраженная одышка в покое'],
  summary: 'Главный драйвер — перегрузка объёмом; первый шаг — NT-proBNP + ЭхоКГ.',
  guardClean: true,
};

// GOLDEN: RU по умолчанию = прежний вывод байт-в-байт
const EXPECTED_RU = [
  '# Клиническое заключение (EBM)\n',
  '## 1. Клиническая логика\n' + conv.logic + '\n',
  '## 2. Рабочие гипотезы (ранжированы)',
  '**1. Сердечная недостаточность** — объясняет: отёки, одышку. Подтвердить: NT-proBNP, ЭхоКГ.',
  '**2. ХБП** — объясняет: задержку жидкости. Подтвердить: СКФ, альбумин.',
  '\n**Параллельно не пропустить:** тромбоз глубоких вен; острый коронарный синдром\n',
  '## 3. Полное обследование (по шагам)',
  '**Шаг 1 — анамнез/осмотр:** динамика веса; приём НПВП',
  '**Шаг 2 — лаборатория:** NT-proBNP; креатинин/СКФ; альбумин',
  '**Шаг 3 — визуализация:** ЭхоКГ; УЗ вен ног',
  '**Шаг 4 — специалисты:** кардиолог; нефролог\n',
  '## 4. Красные флаги\n' + '• боль в груди\n• выраженная одышка в покое' + '\n',
  '## 5. Итог\n' + conv.summary,
  '\n_validated:false · поддержка решения, не замена врача · METACOD-Omer_',
].join('\n');

const ru = renderMarkdown(conv);            // default 'ru'
const ruExplicit = renderMarkdown(conv, 'ru');
check('RU по умолчанию = golden (байт-в-байт, обратная совместимость)', ru === EXPECTED_RU);
check('RU явный = RU по умолчанию', ru === ruExplicit);
check('RU содержит validated:false + METACOD-Omer', ru.includes('validated:false') && ru.includes('METACOD-Omer'));

// Тело приходит от модели уже на языке рынка; рендер локализует заголовки/футер и чистит бренд.
const enConv = {
  logic: 'One root: volume overload on top of CKD explains the edema, dyspnea and fatigue.',
  hypotheses: [
    { rank: 1, root: 'Heart failure', explains: 'edema, dyspnea', confirm: ['NT-proBNP', 'echocardiography'] },
    { rank: 2, root: 'CKD', explains: 'fluid retention', confirm: ['eGFR', 'albumin'] },
  ],
  cannotMiss: ['deep vein thrombosis', 'acute coronary syndrome'],
  workup: {
    step1_history: ['weight trend', 'NSAID use'],
    step2_labs: ['NT-proBNP', 'creatinine/eGFR', 'albumin'],
    step3_imaging: ['echocardiography', 'leg vein ultrasound'],
    step4_referrals: ['cardiologist', 'nephrologist'],
  },
  redFlags: ['chest pain', 'severe dyspnea at rest'],
  summary: 'Main driver — volume overload; first step — NT-proBNP + echocardiography.',
  guardClean: true,
};
const heConv = {
  logic: 'שורש אחד: עומס נפח על רקע מחלת כליות כרונית מסביר בצקות, קוצר נשימה ועייפות.',
  hypotheses: [
    { rank: 1, root: 'אי ספיקת לב', explains: 'בצקות, קוצר נשימה', confirm: ['NT-proBNP', 'אקו לב'] },
    { rank: 2, root: 'מחלת כליות כרונית', explains: 'אגירת נוזלים', confirm: ['eGFR', 'אלבומין'] },
  ],
  cannotMiss: ['פקקת ורידים עמוקים', 'תסמונת כלילית חדה'],
  workup: {
    step1_history: ['מגמת משקל', 'שימוש בנוגדי דלקת'],
    step2_labs: ['NT-proBNP', 'קריאטינין/eGFR', 'אלבומין'],
    step3_imaging: ['אקו לב', 'אולטרסאונד ורידי רגליים'],
    step4_referrals: ['קרדיולוג', 'נפרולוג'],
  },
  redFlags: ['כאב בחזה', 'קוצר נשימה חמור במנוחה'],
  summary: 'המניע העיקרי — עומס נפח; הצעד הראשון — NT-proBNP + אקו לב.',
  guardClean: true,
};

// EN — §Е: без бренда/бейджа/токена, 0 кириллицы, английские заголовки
const en = renderMarkdown(enConv, 'en');
check('EN 0 кириллицы (Е1)', !/[А-Яа-яЁё]/.test(en));
check('EN без METACOD (Е3)', !/METACOD/.test(en));
check('EN без validated:false (Е3)', !/validated:false/.test(en));
check('EN английский заголовок', en.includes('# Clinical conclusion (EBM)'));
check('EN гейт выпуска ok', releaseGate(en, 'en').ok);

// HE — §Е: бренд+validated:false сохранены, локация תל אביב, RTL-заголовки, 0 кириллицы
const he = renderMarkdown(heConv, 'he');
check('HE 0 кириллицы (Е1)', !/[А-Яа-яЁё]/.test(he));
check('HE содержит validated:false', he.includes('validated:false'));
check('HE содержит תל אביב, ישראל', he.includes('תל אביב, ישראל'));
check('HE иврит-заголовок', he.includes('מסקנה קלינית'));
check('HE гейт выпуска ok', releaseGate(he, 'he').ok);

// releaseGate негативные (гейт ловит кириллицу в EN-теле — Е1 работает)
check('EN c русским телом блокируется гейтом', !releaseGate(renderMarkdown(conv, 'en'), 'en').ok);
check('EN c кириллицей блокируется', !releaseGate('English with кириллица', 'en').ok);
check('scrubEnBody убирает бренд', scrubEnBody('Source: METACOD questionnaire') === 'Source: clinical questionnaire');

console.log(`\n§Е release-layer: ${ok}/${total}`);
if (ok !== total) process.exit(1);
