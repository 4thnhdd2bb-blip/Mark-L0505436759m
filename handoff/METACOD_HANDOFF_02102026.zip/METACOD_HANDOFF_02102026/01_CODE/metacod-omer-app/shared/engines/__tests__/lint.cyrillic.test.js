// ЛИНТ: кириллический \w и \b — молчаливый дефект проекта, пойманный ПЯТЬ раз.
//
//   1) guard.ts          — /гель\b/, /\bЦарь\b/ не ловили слова;
//   2) compartments.ts   — семь правил вида /сахарн\w* диабет/ не срабатывали НИ РАЗУ;
//   3) phaseTransition.ts— NEG = /\b(не|нет|без)\b/ молча пропускала отрицание;
//   4) compartments.ts   — /плотн\w*\s*отёк/ (микседема) — центральная находка разбора 74ж;
//   5) membraneGate.ts   — /пот\b/ и /гной\b/ в файле, где строкой выше написано «не делать так».
//
// В JavaScript \w = [A-Za-z0-9_] и \b строится на нём же — ASCII-only ДАЖЕ с флагом /u.
// Рядом с кириллицей они не ошибаются, а МОЛЧА не срабатывают: тест проходит, правило мертво.
// Правильно: [а-яё]* вместо \w*, и явные границы (^|[^а-яё]) / (?![а-яё]) вместо \b.
//
// Этот тест — единственная защита от шестого случая. Он читает ИСХОДНИКИ, не сборку.

const fs = require('fs');
const path = require('path');

let ok = 0, total = 0;
function check(name, cond) { total++; console.log((cond ? '  OK  ' : ' FAIL ') + name); if (cond) ok++; }

const ENGINES = path.join(__dirname, '..');
const CYR = /[а-яёА-ЯЁ]/;

/** Грубый, но достаточный выделитель регексп-литералов из строки кода. */
function regexLiterals(line) {
  const out = [];
  // /.../ с флагами; не трогаем комментарии-описания и деление — отсекаем по наличию флагов
  const re = /\/(?![/*])((?:\\.|\[(?:\\.|[^\]])*\]|[^/\\\n])+)\/([gimsuy]*)/g;
  let m;
  while ((m = re.exec(line))) out.push({ body: m[1], flags: m[2], index: m.index });
  return out;
}

/**
 * Ищет \b и \w, ПРИМЫКАЮЩИЕ к кириллице. Латинская аббревиатура внутри кириллического
 * перечисления (/гематокрит|\bhct\b/) — законна: там \b стоит между латиницей и работает.
 * Ломается ровно тот, у которого соседний атом кириллический: "\bрак\b", "сахарн\w" со звёздочкой,
 * "мет[сc]\b" (класс с кириллической «с»).
 */
function brokenBoundaries(body) {
  const bad = [];
  const isCyr = (ch) => ch !== undefined && CYR.test(ch);
  // класс символов, заканчивающийся на позиции i: вернуть его содержимое
  const classEndingAt = (i) => {
    if (body[i] !== ']') return null;
    for (let j = i - 1; j >= 0; j--) {
      if (body[j] === '[' && body[j - 1] !== '\\') return body.slice(j + 1, i);
    }
    return null;
  };
  const classStartingAt = (i) => {
    if (body[i] !== '[') return null;
    for (let j = i + 1; j < body.length; j++) {
      if (body[j] === ']' && body[j - 1] !== '\\') return body.slice(i + 1, j);
    }
    return null;
  };
  for (let i = 0; i < body.length - 1; i++) {
    if (body[i] !== '\\' || (body[i + 1] !== 'b' && body[i + 1] !== 'w')) continue;
    if (i > 0 && body[i - 1] === '\\') continue;          // это \\b, экранированный слеш
    const kind = '\\' + body[i + 1];
    // сосед слева (пропуская кванторы)
    let l = i - 1;
    while (l >= 0 && '*+?'.includes(body[l])) l--;
    const leftClass = l >= 0 ? classEndingAt(l) : null;
    const leftCyr = isCyr(body[l]) || (leftClass !== null && CYR.test(leftClass));
    // сосед справа (пропуская кванторы после \w)
    let r = i + 2;
    while (r < body.length && '*+?'.includes(body[r])) r++;
    const rightClass = classStartingAt(r);
    const rightCyr = isCyr(body[r]) || (rightClass !== null && CYR.test(rightClass));
    if (leftCyr || rightCyr) bad.push(kind + (leftCyr ? ' после кириллицы' : ' перед кириллицей'));
  }
  return bad;
}

function stripComment(line) {
  const i = line.indexOf('//');
  if (i === -1) return line;
  // не режем, если // внутри регекспа или строки — грубая эвристика: считаем кавычки и слеши
  const before = line.slice(0, i);
  const quotes = (before.match(/'/g) || []).length + (before.match(/"/g) || []).length + (before.match(/`/g) || []).length;
  const slashes = (before.match(/\//g) || []).length;
  if (quotes % 2 === 1 || slashes % 2 === 1) return line;
  return before;
}

const files = fs.readdirSync(ENGINES).filter((f) => f.endsWith('.ts'));
const offenders = [];
let scannedFiles = 0, scannedLiterals = 0;

for (const f of files) {
  scannedFiles++;
  const src = fs.readFileSync(path.join(ENGINES, f), 'utf8').split('\n');
  src.forEach((raw, i) => {
    const line = stripComment(raw);
    for (const lit of regexLiterals(line)) {
      scannedLiterals++;
      const bad = brokenBoundaries(lit.body);
      if (bad.length) offenders.push(`${f}:${i + 1}  ${bad.join(', ')}   в  /${lit.body.slice(0, 64)}/`);
    }
  });
}

check(`просканированы исходники движков (${scannedFiles} файлов, ${scannedLiterals} регекспов)`, scannedFiles >= 10 && scannedLiterals >= 50);
const probe = (code) => regexLiterals(code).some((l) => brokenBoundaries(l.body).length > 0);
check('лайв: ловит /сахарн\\w* диабет/ (случай №2 и №4)', probe('const X = /сахарн\\w* диабет/i;'));
check('лайв: ловит /\\bрак\\b/ (кириллица с обеих сторон)', probe('const X = /онко|\\bрак\\b|опухол/i;'));
check('лайв: ловит /пот\\b/ (случай №5, мой собственный)', probe('const X = /обильный пот\\b/i;'));
check('лайв: ловит /мет[сc]\\b/ — класс с кириллической «с»', probe('const X = /мет[сc]\\b/i;'));
check('лайв: НЕ трогает чистое [а-яё]*', !probe('const X = /сахарн[а-яё]* диабет/i;'));
check('лайв: НЕ трогает латинскую аббревиатуру в кириллическом перечне',
  !probe('const X = /гематокрит|\\bhct\\b|полицитем/i;'));
check('лайв: НЕ трогает явную границу (?![а-яё])', !probe('const X = /пот(?![а-яё])/i;'));

if (offenders.length) {
  console.log('\n  ⚠ КИРИЛЛИЧЕСКИЙ \\w / \\b — ПРАВИЛА МОЛЧА НЕ РАБОТАЮТ:');
  for (const o of offenders) console.log('     ' + o);
}
check('в движках нет ни одного \\w/\\b рядом с кириллицей', offenders.length === 0);

console.log(`\nЛИНТ КИРИЛЛИЦЫ: ${ok}/${total}`);
if (ok !== total) process.exit(1);
