// Тест слоя АЛГОРИТМА ДИАГНОЗА (diagnosisAlgorithm). Запуск: node после компиляции в _buildA.
// Проверяет: порядок первичное→вторичное, подбор строки Общей таблицы, HARD-STOP M-D2,
// истинную мембрану (осушающие), фильтр 658 «гасит:[энергия]», направление из мембраны.
const A = require('./_buildA/engines/diagnosisAlgorithm.js');
const ВЕРСИЯ_КАНОНА = require('./_canonVersion');

let ok = 0, total = 0;
function check(name, cond) { total++; console.log((cond ? '  OK  ' : ' FAIL ') + name); if (cond) ok++; }

// ── базовый вход
const base = { complaints: ['отёки ног', 'одышка', 'утомляемость'], labs: {}, currentDrugs: [] };

// 1) Влажность-обмен + M-A2 → трасса, порядок, строка таблицы, JCZ
const t1 = A.runDiagnosisAlgorithm(base, { dominantEnergies: ['Влажность'], membrane: 'M-A2', phase: 'CA', hangingPoint: 'Холод↔Влажность' });
check('6 стадий (0..5)', t1.steps.length === 6 && t1.steps[0].n === 0 && t1.steps[5].n === 5);
check('порядок: мембрана (шаг 1) ПЕРВИЧНО раньше энергии (шаг 2) ВТОРИЧНО',
  t1.steps[1].key === 'мембрана' && t1.steps[1].layer.includes('ПЕРВИЧНО') &&
  t1.steps[2].key === 'энергия' && t1.steps[2].layer.includes('ВТОРИЧНО'));
check('мантра присутствует', /мембрана раньше лекарства/.test(t1.mantra));
check('подобрана строка Общей таблицы Влажность-обмен', !!t1.treatmentRow && /Влажность-обмен/.test(t1.treatmentRow.energy));
check('JCZ: Государь = метформин', t1.jczLadder.some((j) => j.role === 'Государь' && /метформин/.test(j.item)));
check('направление из M-A2 = контролируемый катаболик', t1.direction === 'контролируемый катаболик');

// 2) HARD-STOP при M-D2 (кахексия) + запрещённый препарат в текущей терапии
const t2 = A.runDiagnosisAlgorithm(
  { complaints: ['слабость', 'потеря веса'], labs: {}, currentDrugs: ['дапаглифлозин', 'метформин'] },
  { dominantEnergies: ['Холод'], membrane: 'M-D2', phase: 'CA', hangingPoint: 'Холод↔Влажность' });
check('HARD-STOP: M-D2 запрет катаболиков сработал', t2.hardStops.some((h) => /M-D2/.test(h) && /ЗАПРЕЩЕН/i.test(h)));
check('HARD-STOP: пойман запрещённый препарат в схеме', t2.hardStops.some((h) => /дапаглифлозин|метформин/.test(h)));
check('направление из M-D2 = анаболик', t2.direction === 'анаболик');

// 3) истинная мембрана: осушающие в схеме → контрольная точка «внимание»
const cpTrue = t2.controlPoints.find((c) => c.id === 'истинная_мембрана');
check('контрольная точка «истинная мембрана» = внимание (осушающие)', cpTrue && cpTrue.status === 'внимание');
const t3 = A.runDiagnosisAlgorithm(base, { dominantEnergies: ['Тепло'], membrane: 'M-0', phase: 'Норматония', hangingPoint: '—' });
const cpClean = t3.controlPoints.find((c) => c.id === 'истинная_мембрана');
check('контрольная точка «истинная мембрана» = ok без осушающих', cpClean && cpClean.status === 'ok');

// 4) три контрольные точки всегда присутствуют
check('три контрольные точки', t1.controlPoints.length === 3);

// 5) фильтр 658 «гасит:[энергия]»
const cold = A.quench658('Холод', 100);
check('quench658(Холод) непустой', cold.length > 0);
check('quench658(Холод): каждый препарат гасит Холод', cold.every((d) => d.q.includes('Холод')));
check('база 658 загружена (>= 600)', A.DRUGBASE_658_COUNT >= 600);

// 6) направление M-S = антифиброз
const tS = A.runDiagnosisAlgorithm(base, { dominantEnergies: ['Сухость'], membrane: 'M-S', phase: 'PCL-B', hangingPoint: 'Сухость↔Тепло' });
check('направление из M-S = антифиброз', tS.direction === 'антифиброз');
check('M-S подобрал строку Сухость-фиброз', !!tS.treatmentRow && /Сухость/.test(tS.treatmentRow.energy));

// 7) конфликт мембрана⇄энергия отмечается при дивергенции (Тепло-воспаление золь vs гель-мембрана)
const tConf = A.runDiagnosisAlgorithm(base, { dominantEnergies: ['Тепло'], membrane: 'M-A2', phase: 'CA', hangingPoint: '—' });
check('конфликт мембрана⇄энергия отмечен при дивергенции', typeof tConf.conflict === 'string' && /побеждает МЕМБРАНА/.test(tConf.conflict));

// 8) РЕГРЕСС правки подбора строки (смешанные кейсы)
// Ж72 саркопеническое ожирение: энергия Влажность + мембрана M-D2 → безопасный анаболический
// вектор (кахексия/саркопения), НЕ «Влажность-вода/диуретик», + HARD-STOP на GLP-1.
const t72 = A.runDiagnosisAlgorithm(
  { complaints: ['ИМТ 33 + подтверждённая саркопения; просит уколы для похудения (GLP-1)'], labs: {}, currentDrugs: [] },
  { dominantEnergies: ['Влажность'], membrane: 'M-D2', phase: 'CA', hangingPoint: '—' });
check('Ж72: M-D2 → анаболическая строка (не диуретик)', !!t72.treatmentRow && /кахекси|саркопен/i.test(t72.treatmentRow.energy) && !/вода|диурет|отёк/i.test(t72.treatmentRow.vector));
check('Ж72: HARD-STOP на катаболики (GLP-1) сработал', t72.hardStops.some((h) => /GLP-1|ЗАПРЕЩЕН/i.test(h)));

// Ж48 гипотиреоз-застой: энергия Холод + мембрана M-D1 → строка «застой→левотироксин»,
// БЕЗ спурьёзного M-D2-стопа.
const t48 = A.runDiagnosisAlgorithm(
  { complaints: ['вес↑, зябкость, запор, волосы лезут; ТТГ 22, Т4 низкий — гипотиреоз'], labs: {}, currentDrugs: [] },
  { dominantEnergies: ['Холод'], membrane: 'M-D1', phase: 'CA', hangingPoint: '—' });
check('Ж48: M-D1 гипотиреоз → строка застой (левотироксин)', !!t48.treatmentRow && /застой/i.test(t48.treatmentRow.energy) && /левотироксин/i.test(t48.treatmentRow.drugs658));
check('Ж48: НЕТ спурьёзного M-D2-стопа при M-D1', !t48.hardStops.some((h) => /M-D2|ЗАПРЕЩЕН/i.test(h)));

// 9) §2J.1 ЗАМЕНЫ ПРИ ЗАПРЕТЕ — запрет не отменяет цель
// Preston-подобный кейс: M-D2 + NAC в схеме → NAC под HARD-STOP, но редокс закрывается заменой БЕЗ NAC.
const tNac = A.runDiagnosisAlgorithm(
  { complaints: ['истощение, потеря веса, окисление MDA↑'], labs: {}, currentDrugs: ['NAC 600 мг ×2', 'омега-3'] },
  { dominantEnergies: ['Холод'], membrane: 'M-D2', phase: 'CA', hangingPoint: 'CA↔Эпикризис' });
const subNac = (tNac.substitutions || []).find((s) => /NAC/i.test(s.banned));
check('§2J.1: NAC при M-D2 даёт замену', !!subNac);
check('§2J.1: замена NAC — без NAC (глутатион/α-липоевая)', !!subNac && /глутатион/i.test(subNac.replacement) && !/\bNAC\b/i.test(subNac.replacement));
check('§2J.1: оговорка «только решением врача» сохранена', !!subNac && /врач/i.test(subNac.caveat || ''));
check('§2J.1: HARD-STOP говорит про замену, а не только про запрет', tNac.hardStops.some((h) => /ЗАМЕНОЙ|§2J.1/i.test(h)));

// Гейт по мембране: тот же NAC при M-A2 замену НЕ вызывает (запрет привязан к глубокому катаболизму)
const tNacA = A.runDiagnosisAlgorithm(
  { complaints: ['метаболический синдром'], labs: {}, currentDrugs: ['NAC 600 мг ×2'] },
  { dominantEnergies: ['Влажность'], membrane: 'M-A2', phase: 'CA', hangingPoint: '—' });
check('§2J.1: при M-A2 замена по NAC не навязывается', !(tNacA.substitutions || []).some((s) => /NAC/i.test(s.banned)));

// Гейт по антикоагулянту: энзимы + апиксабан → замена антифиброза без энзимов
const tEnz = A.runDiagnosisAlgorithm(
  { complaints: ['ХСН, фиброз миокарда'], labs: {}, currentDrugs: ['апиксабан 5 мг ×2', 'серрапептаза'] },
  { dominantEnergies: ['Сухость'], membrane: 'M-S', phase: 'PCL-B', hangingPoint: '—' });
check('§2J.1: энзимы при антикоагулянте → замена', (tEnz.substitutions || []).some((s) => /серрапептаз/i.test(s.banned) && /АМКР|омега-3/i.test(s.replacement)));

// Правило уровней гель-золь и таблица замен доступны наружу (для экрана/разбора)
check('§2J.1: правило уровней в трассе', typeof tNac.levelRule === 'string' && /уровне отдельно/i.test(tNac.levelRule));
check('§2J.1: таблица замен непуста', A.SUBSTITUTION_TABLE.length >= 6);
check('§2J.1: кейсы разрешения противоречий загружены (>=8)', A.CONFLICT_CASES.length >= 8);


// ── §2K — СЛОЙ ФАЗОВОГО ПЕРЕХОДА (атлас v2) ──────────────────────────
const T = require('./_buildA/engines/phaseTransition.js');

// 10) режим: без данных о динамике — честное «неизвестно», а не догадка
const mUnk = T.phaseMode({ complaints: ['слабость'], labs: {}, currentDrugs: [] });
check('§2K: режим без динамики = неизвестно + запрос данных', mUnk.mode === 'неизвестно' && mUnk.need.length > 0);
const mFlow = T.phaseMode({ complaints: ['на фоне лечения уходит, СРБ снизился'], labs: {}, currentDrugs: [] });
check('§2K: признак разрешения → режим «течёт»', mFlow.mode === 'течёт');

// 11) тип люка L1 — истощение drug-driven (Итамар)
const itamar = { complaints: ['постоянно мёрзну, усталость, онемение'], labs: {}, currentDrugs: ['метформин', 'Форсига (SGLT2)', 'ситаглиптин', 'бисопролол'] };
const lItamar = T.detectLock(itamar, { membrane: 'M-D2', energies: ['Холод'] });
check('§2K: Итамар → люк L1 «истощение (drug-driven)»', !!lItamar && lItamar.id === 'L1' && /Форсига|SGLT2/i.test(lItamar.heldBy.join(' ')));
check('§2K: первый ход L1 = снятие, а не добавление', !!lItamar && /снять/i.test(lItamar.firstMove));

// 12) тип люка L4 — кровь-гипервязкость (Amir) + гейт ОКС/ТЭЛА
const amir = { complaints: ['боль в груди, утомляемость'], labs: { Hb: 17.6, Hct: 51.2 }, currentDrugs: [] };
const lAmir = T.detectLock(amir, { membrane: 'M-A2', energies: ['Влажность'] });
check('§2K: Amir → люк L4 «избыток крови»', !!lAmir && lAmir.id === 'L4');
check('§2K: Amir → гейт can\'t-miss на ОКС/ТЭЛА', T.cantMissGates(amir).some((g) => /ОКС|ТЭЛА/i.test(g.gate)));

// 13) тип люка L8 — напряжение векторов, онко гатирует кормление (Пациент-2)
const p2 = { complaints: ['потеря веса, ночная потливость, поносы при болезни Крона'], labs: {}, currentDrugs: ['ГПП-1', 'ИПП'] };
const l2 = T.detectLock(p2, { membrane: 'M-D2', energies: ['Холод'] });
check('§2K: Пациент-2 → люк L8 «напряжение векторов»', !!l2 && l2.id === 'L8');
check('§2K: Пациент-2 → онко-гейт активен', T.cantMissGates(p2).some((g) => /лимфом|опухол/i.test(g.gate)));

// 14) тип люка L6 — причина⇄защита (Мири) + закон в выводе
const miri = { complaints: ['плотные холодные отёки, прибавка веса, зябкость; известный гипотиреоз'], labs: {}, currentDrugs: ['левотироксин', 'метотрексат'] };
const lMiri = T.detectLock(miri, { membrane: 'M-D1', energies: ['Холод'] });
check('§2K: Мири → люк L6 «причина⇄защита»', !!lMiri && lMiri.id === 'L6');
const trMiri = T.assessTransition(miri, { membrane: 'M-D1', energies: ['Холод'], direction: 'анаболик' });
check('§2K: закон причина⇄защита попал в вывод', typeof trMiri.causeProtection === 'string' && /причин/i.test(trMiri.causeProtection));

// 15) страховка от переката — обязательна для катаболического вектора
const gCat = T.overshootGuards('контролируемый катаболик');
check('§2K: катаболик → страховка «беречь мышцу» (перекат в M-D2)', gCat.some((g) => /M-D2|саркопен/i.test(g.overshoot) && /белок|лейцин/i.test(g.guard)));

// 16) замена по классу АТХ (недоступность препарата)
const sub = T.substituteByClass('дапаглифлозин');
check('§2K: замена по классу АТХ найдена', !!sub && /SGLT-2/i.test(sub.cls) && /эмпаглифлозин/i.test(sub.alternatives));
check('§2K: кластеров замены >= 13', T.CLASS_CLUSTERS.length >= 13);
check('§2K: типов люка = 8', T.LOCK_TYPES.length === 8);
check('§2K: правило контекста загружено (один признак — три исхода)', /контекст/i.test(T.CONTEXT_RULE['правило'] || ''));

// 17) трасса §2J несёт слой перехода
const trace2K = A.runDiagnosisAlgorithm(itamar, { dominantEnergies: ['Холод'], membrane: 'M-D2', phase: 'PCL-B', hangingPoint: 'Сухость↔Холод' });
check('§2K: трасса §2J содержит слой перехода', !!trace2K.transition && !!trace2K.transition.lock && trace2K.transition.lock.id === 'L1');

// ── §2L — ПОРОГ M-D + СОГЛАСОВАННОСТЬ ФЛАГ→ТЕСТ + ГИГИЕНА ────────────
const C = require('./_buildA/engines/consistency.js');

// 18) порог M-D: нет данных → безопасная сторона M-D2 + запрос
const mdNone = C.mdSubtype({});
check('§2L: нет данных → M-D2 (безопасная сторона) + assumed', mdNone.subtype === 'M-D2' && mdNone.cata === true && mdNone.assumed === true && mdNone.needsMoreData.length >= 2);

// М.77: PA50 4.3 + саркопения → M-D2 по порогу, а не по drug-логике
const md77 = C.mdSubtype({ phaseAngle: 4.3, sarcopenia: true });
check('§2L: М.77 (PA50 4.3 + саркопения) → M-D2 по порогу', md77.subtype === 'M-D2' && md77.cata === true && md77.assumed === false);

// лёгкий случай: один критерий не набирает порог → M-D1 без жёсткого запрета
const md1 = C.mdSubtype({ phaseAngle: 5.4, weightLossPct: 6 });
check('§2L: один критерий → M-D1 (жёсткий запрет не включается)', md1.subtype === 'M-D1' && md1.cata === false);

// кахексия с альбумином < 30 → M-D3
const md3 = C.mdSubtype({ phaseAngle: 4.1, weightLossPct: 10, albumin: 28 });
check('§2L: альбумин < 30 + критерии → M-D3', md3.subtype === 'M-D3' && md3.cata === true);

// 19) флаг → тест: дефект Efi (флаг кровотечения без FIT) должен ловиться
const gapsEfi = C.checkFlagTest(
  ['скрытое кровотечение под антикоагулянтом (бледность + потеря веса)', 'эугликемическая ДКА на SGLT2'],
  ['NT-proBNP', 'K, Na, Mg, креатинин', 'кетоны / β-гидроксибутират', 'липидограмма']);
check('§2L: флаг кровотечения без FIT → пробел найден', gapsEfi.some((g) => /кровотеч/i.test(g.flag) && g.missing.some((m) => /FIT/i.test(m))));
check('§2L: флаг ДКА с кетонами → пробела нет', !gapsEfi.some((g) => /ДКА/i.test(g.flag)));

// когда тест есть — пробелов нет вовсе
const gapsOk = C.checkFlagTest(['скрытое кровотечение'], ['FIT (скрытая кровь в кале)', 'ОАК + ретикулоциты']);
check('§2L: тест на месте → согласовано', gapsOk.length === 0);
check('§2L: карта флаг→тест загружена (>=10)', C.FLAG_TEST_MAP.length >= 10);

// 20) гигиена: дедуп ЭКГ×3 / ЭхоКГ×4 и отбрасывание строк без основания
const raw = [
  { text: 'ЭКГ', basis: ['ФП'] },
  { text: 'ЭКГ / холтер', basis: ['аритмия'] },
  { text: 'ЭКГ (брадикардия / β-блокатор)', basis: ['бисопролол'] },
  { text: 'ЭхоКГ (ФВ, МР, давление в ЛА)', basis: ['ФВ 20%'] },
  { text: 'ЭхоКГ по показанию', basis: ['шум'] },
  { text: 'ЭхоКГ-переоценка ФВ', basis: ['динамика ФВ'] },
  { text: 'ЭхоКГ-контроль ФВ', basis: ['контроль'] },
  { text: 'после пластики/протеза — антитромботическая по типу' },
];
const clean2L = C.dedupeSteps(raw, true);
check('§2L: ЭКГ склеен в одну строку', clean2L.filter((i) => i.key === 'ЭКГ').length === 1);
check('§2L: ЭхоКГ склеен в одну строку', clean2L.filter((i) => i.key === 'ЭхоКГ').length === 1);
check('§2L: шаблон без основания отброшен', !clean2L.some((i) => /пластик/i.test(i.text)));
check('§2L: обоснования объединены при слиянии', clean2L.find((i) => i.key === 'ЭКГ').basis.length === 3);

// ── §2M — БИБЛИОТЕКА ПО МЕМБРАНЕ · НУТРИЦЕВТИКА · ИНДЕКС ГРУЗА ──────
const L = require('./_buildA/engines/membraneLibrary.js');

// 21) библиотека: блок по мембране + разведение двух вкусов M-A2
const libMA2 = L.libraryFor('M-A2', 'ожирение, МетС, стеатоз');
check('§2M: M-A2 без эритроцитоза → метаболический блок', !!libMA2 && libMA2.membrane === 'M-A2-обмен' && /инкретин|семаглутид/i.test(JSON.stringify(libMA2.drugs)));
const libBlood = L.libraryFor('M-A2', 'Hct 51, эритроцитоз, гипервязкость');
check('§2M: M-A2 крови → блок разгеливания (⛔ железо)', !!libBlood && libBlood.membrane === 'M-A2-кровь' && /железо/i.test(libBlood.hardStop));
const libMD2 = L.libraryFor('M-D2');
check('§2M: M-D2 → красная зона с жёстким запретом катаболиков', !!libMD2 && /ЗАПРЕЩЕН/i.test(libMD2.hardStop));
check('§2M: M-D3 ведётся по блоку M-D2', L.libraryFor('M-D3').membrane === 'M-D2');
const libMS = L.libraryFor('M-S');
check('§2M: M-S несёт три столпа и цели с эластометрией', !!libMS && /пластический пул/i.test(libMS.supplements) && /эластометри|FIB-4/i.test(libMS.goals));
check('§2M: у каждого блока есть мониторинг и hardStop', L.LIBRARY_BLOCKS.every((b) => typeof b.monitoring === 'string' && typeof b.hardStop === 'string'));

// 22) нутрицевтика как часть схемы — детерминированные правила
const sStatin = L.supplementPlan({ membrane: 'M-S', currentDrugs: ['аторвастатин 80', 'апиксабан 5 мг ×2'] });
check('§2M: статин 80 → CoQ10 обязателен', sStatin.some((x) => /CoQ10/i.test(x.item) && /обязательн/i.test(x.reason)));
check('§2M: M-S + антикоагулянт → энзимы под вето', sStatin.some((x) => /энзим/i.test(x.item) && /вето/i.test(x.step)));
check('§2M: M-S → пластический пул выдан', sStatin.some((x) => /пластический пул/i.test(x.item)));

const sCkd = L.supplementPlan({ membrane: 'M-D2', egfr: 42, currentDrugs: ['метформин'] });
const prot = sCkd.find((x) => /белок/i.test(x.item));
check('§2M: кахексия + ХБП → белок ~1.0 г/кг, не 1.2–1.6', !!prot && /1\.0 г\/кг/.test(prot.dose) && /нефролог/i.test(prot.caution || ''));
check('§2M: метформин → B12', sCkd.some((x) => /B12/i.test(x.item)));
const sNoCkd = L.supplementPlan({ membrane: 'M-D2', currentDrugs: [] });
check('§2M: кахексия без ХБП → белок 1.2–1.6 г/кг', sNoCkd.some((x) => /белок/i.test(x.item) && /1\.2–1\.6/.test(x.dose)));

const sGlp = L.supplementPlan({ membrane: 'M-A2', currentDrugs: ['семаглутид 1 мг'] });
check('§2M: GLP-1 при M-A2 → страховка от переката (мышца)', sGlp.some((x) => /креатин|белок/i.test(x.item) && /перекат/i.test(x.step)));

const sRedox = L.supplementPlan({ membrane: 'M-D2', hint: 'окисление MDA↑' });
const redox = sRedox.find((x) => /редокс/i.test(x.item));
check('§2M: редокс при M-D2 — без NAC', !!redox && /глутатион/i.test(redox.dose) && !/\bNAC\b/.test(redox.dose));

const sBlood = L.supplementPlan({ membrane: 'M-A2', hint: 'эритроцитоз, гематокрит 51' });
check('§2M: M-A2 крови → ⛔ железо в плане добавок', sBlood.some((x) => /железо/i.test(x.item) && /вето/i.test(x.step)));
check('§2M: каждая позиция несёт причину', L.supplementPlan({ membrane: 'M-D1' }).every((x) => typeof x.reason === 'string' && x.reason.length > 5));

// 23) индекс груза
const bNone = L.burdenIndex({});
check('§2M: нет компонентов → индекс не считается (не ноль)', bNone.index === null && bNone.needsMoreData.length === 7);
const bLow = L.burdenIndex({ phaseAngle: 6.2, muscle: 'норма', crpChronic: 0.4, fibrosis: 'низкий' });
check('§2M: здоровый профиль → низкий груз', bLow.index === 0 && bLow.band === 'низкий' && bLow.provisional === false);
const bHigh = L.burdenIndex({ phaseAngle: 4.3, muscle: 'саркопения', crpChronic: 8, fibrosis: 'высокий', deficits: 2, epiAgeDelta: 6 });
check('§2M: тяжёлый профиль → высокий/очень высокий груз', bHigh.index >= 50 && /высокий/.test(bHigh.band));
check('§2M: покрытие показано честно', /из 7/.test(bHigh.coverage) && bHigh.needsMoreData.length === 1);
const bThin = L.burdenIndex({ phaseAngle: 4.3 });
check('§2M: покрытие < 3 → индекс помечен ориентировочным', bThin.provisional === true && /ориентировочн/i.test(bThin.note));
check('§2M: границы рамки заявлены в выводе', /не диагноз/i.test(bThin.note));
check('§2M: каналы старения ↔ типы люка загружены', L.BURDEN_CHANNELS.length >= 9 && L.BURDEN_CHANNELS.some((c) => /inflammaging/i.test(c.hallmark)));
check('§2M: теломеразу активировать запрещено', /не активиру/i.test(L.TELOMERE_RULE['правило'] || ''));

// ── §2N — ДВУХУРОВНЕВАЯ МЕМБРАНА: СИСТЕМА × ОРГАН ───────────────────
const N = require('./_buildA/engines/compartments.js');

// 24) матрица 9 клеток и правило конфликта
check('§2N: матрица содержит 9 клеток', N.MATRIX_CELLS.length === 9);
check('§2N: диагональ = согласие', ['M-A','M-D','M-S'].every((p) => N.matrixCell(p, p).relation === 'согласие'));
check('§2N: орган M-D × тело M-A = конфликт (саркопеническое ожирение)', N.matrixCell('M-D','M-A').relation === 'конфликт' && /К3/.test(N.matrixCell('M-D','M-A').id));
check('§2N: правило Литвака загружено', /ВНУТРИ этого фона/i.test(N.TWO_LEVEL_RULE));

// 25) СД2 — эталон конфликта уровней: тело M-A, β-клетка M-S
const t2d = N.assessCompartments(
  { complaints: ['СД2, HbA1c 7.8, инсулинорезистентность; нейропатия стоп'], labs: {}, currentDrugs: [] },
  { systemicMembrane: 'M-A2' });
const beta = t2d.compartments.find((c) => /β-клетк/.test(c.target || ''));
check('§2N: СД2 → компартмент β-клетка M-S', !!beta && beta.membrane === 'M-S');
check('§2N: СД2 → конфликт уровней отмечен', t2d.conflicts.some((c) => /β-клетк/.test(c)));
const betaPlan = t2d.plans.find((x) => /β-клетк/.test(x.organ));
check('§2N: β-клетка — щадить, ⛔ сульфонилмочевина', !!betaPlan && /ЩАДИТЬ/i.test(betaPlan.action) && /сульфонилмочевин/i.test(betaPlan.cell.hardStop));
check('§2N: нейропатия → компартмент нерва', t2d.compartments.some((c) => /нерв/.test(c.target || '')));

// 26) ИНВАРИАНТ: компартмент M-D2 запрещает катаболики всему телу (случай Efi)
const efi = N.assessCompartments(
  { complaints: ['ХСН, ФВ 20, фиброз миокарда; потеря веса 90→81, саркопения'], labs: {}, currentDrugs: ['апиксабан'] },
  { systemicMembrane: 'M-S' });
check('§2N: Efi → минимум 3 компартмента (тело + сердце + мышца)', efi.compartments.length >= 3);
check('§2N: Efi → сердце M-S', efi.compartments.some((c) => /сердце/.test(c.target || '') && c.membrane === 'M-S'));
check('§2N: Efi → мышца M-D2', efi.compartments.some((c) => /мышц/.test(c.target || '') && c.membrane === 'M-D2'));
check('§2N: ИНВАРИАНТ — катаболики запрещены всему телу при M-D2-компартменте', efi.cataBodywide === true && /ВСЕМУ ТЕЛУ/i.test(efi.safetyNote || ''));

// 27) Preston — кость в векторе, противоположном системному
const preston = N.assessCompartments(
  { complaints: ['истощение после ДТП, перелом, гиперкальциемия, резорбция кости'], labs: {}, currentDrugs: [] },
  { systemicMembrane: 'M-D2' });
const bone = preston.compartments.find((c) => c.level === 'кость');
check('§2N: Preston → компартмент кости отдельно от организма', !!bone && /АРЕСТ резорбции/i.test(bone.vector) && !/кальци[йя]/i.test(bone.vector.replace('НЕ кальций','')));
check('§2N: Preston → организм и кость имеют разные векторы', !!bone && bone.vector !== preston.systemic.vector);

// 28) Мири — микседема как локальный гель, лечить причину
const miriN = N.assessCompartments(
  { complaints: ['гипотиреоз, плотные холодные отёки, прибавка веса'], labs: {}, currentDrugs: ['левотироксин'] },
  { systemicMembrane: 'M-D1' });
const tissue = miriN.compartments.find((c) => /микседем/.test(c.target || ''));
check('§2N: Мири → локальный M-A-гель (микседема)', !!tissue && tissue.pole === 'M-A');
check('§2N: Мири → не бить местно, убрать причину', !!tissue && /причин/i.test(tissue.vector));

// 29) честность: нет данных по органам → запрос, а не выдумка
const bare = N.assessCompartments({ complaints: ['слабость'], labs: {}, currentDrugs: [] }, { systemicMembrane: 'M-D1' });
check('§2N: без органных данных — только системный компартмент', bare.compartments.length === 1 && bare.compartments[0].level === 'организм');
check('§2N: и честный запрос данных', bare.needsMoreData.some((x) => /орган/i.test(x)));

// 30) трасса §2J несёт двухуровневую мембрану
const traceN = A.runDiagnosisAlgorithm(
  { complaints: ['СД2, саркопения, потеря веса'], labs: {}, currentDrugs: [] },
  { dominantEnergies: ['Влажность'], membrane: 'M-A2', phase: 'CA', hangingPoint: '—' });
check('§2N: трасса содержит компартменты', !!traceN.compartments && traceN.compartments.list.length >= 2);
check('§2N: трасса несёт инвариант катаболиков', traceN.compartments.cataBodywide === true);
check('§2N: каждый компартмент объяснён (why)', traceN.compartments.list.every((c) => typeof c.why === 'string' && c.why.length > 5));

// ── ДВИЖОК ЗАМЕНЫ: пересобран из Excel-первоисточника ───────────────
check('замена: курированных классов 24 (добавлен H2-блокаторы)', T.CLASS_CLUSTERS.length === 24);

// ── §2K.1 отрицание в тексте жалоб (разбор 23ж/СД1) ──
check('отрицание: «лихорадки нет» НЕ считается признаком лихорадки',
  T.hasSign('лихорадки при эпизодах, как правило, нет', /лихорад/) === false);
check('отрицание: «лихорадки нет» распознаётся как самостоятельный факт',
  T.isDenied('лихорадки при эпизодах, как правило, нет', /лихорад/) === true);
check('отрицание: утвердительный признак по-прежнему виден',
  T.hasSign('лихорадка до 39 в каждом эпизоде', /лихорад/) === true);
const _p23 = { age: 23, sex: 'ж', labs: {}, currentDrugs: ['омепразол 20 мг x2', 'ранитидин'],
  complaints: ['рецидивирующая боль в горле, налёты в глотке и на языке',
               'лихорадки при эпизодах, как правило, нет',
               'тонзиллэктомия — частичный эффект, рецидив в последний год',
               'сахарный диабет 1 типа с 13 лет',
               'папилломатозные образования («бородавки») в глотке'] };
const _lock23 = T.detectLock(_p23, { membrane: 'M-D2', energies: ['Влажность'], phase: 'PCL-A', mode: 'завис' });
check('люк: неудача органного вмешательства читается как L6 причина⇄защита', _lock23 && _lock23.id === 'L6');
const _g23 = T.cantMissGates(_p23).map((g) => g.trigger).join(' | ');
check('гейт: слизистая + рецидив + БЕЗ лихорадки → ОАК с формулой в эпизод', /БЕЗ лихорадки/.test(_g23));
check('гейт: СД1 + слизистая → АПС-1/APECED', /эндокринопатия/.test(_g23));
check('гейт: образование без гистологии → биопсия', /без гистологии/.test(_g23));
const _ran = T.substituteByClass('ранитидин');
check('отозванный: ранитидин не предлагается как альтернатива', _ran && !/ранитидин/i.test(_ran.alternatives));
check('отозванный: ранитидин помечен причиной отзыва', _ran && /NDMA/.test(_ran.note || ''));
const _fam = T.substituteByClass('фамотидин');
check('класс: фамотидин — H2, а не ИПП', _fam && /H2/.test(_fam.cls));
check('замена: авто-кластеров из 658 (>=100)', T.AUTO_CLASS_CLUSTERS.length >= 100);
const subDapa = T.substituteByClass('дапаглифлозин 10 мг');
check('замена: глифлозин → курированный класс с запретом M-D2', !!subDapa && subDapa.source === 'курированный' && /M-D2/.test(subDapa.note || ''));
const subSema = T.substituteByClass('семаглутид');
check('замена: GLP-1 несёт ⛔ при M-D', !!subSema && /⛔ при M-D/.test(subSema.note || ''));
const subRare = T.substituteByClass('амиодарон');
check('замена: редкий класс закрыт авто-охватом с АТХ', !!subRare && subRare.source === 'авто' && /^C01/.test(subRare.atc || ''));
check('замена: у авто-кластера есть альтернативы', !!subRare && /⇄/.test(subRare.alternatives));

// ── СВЕРКА МАТРИЦЫ С EXCEL-ПЕРВОИСТОЧНИКОМ ──────────────────────────
check('матрица: правило согласия зафиксировано (К1/К5/К6/К8)', /К5/.test(N.DIAGONAL_RULE) && /согласие/i.test(N.DIAGONAL_RULE));
check('матрица: согласие там, где векторы не борются (К1/К5/К6/К8)', ['К1','К5','К6','К8'].every((id) => N.MATRIX_CELLS.find((c) => c.id === id).relation === 'согласие'));
check('матрица: остальные пять клеток — конфликт', N.MATRIX_CELLS.filter((c) => !['К1','К5','К6','К8'].includes(c.id)).every((c) => c.relation === 'конфликт'));
check('матрица: расхождение шапки Excel с её же строкой К5 зафиксировано', /К5/.test(N.MATRIX_VERIFICATION['расхождение_в_источнике'] || ''));
check('матрица: К8 несёт числовой порог ЧСС<150 из Excel', /ЧСС<150/.test(N.matrixCell('M-S','M-S').hardStop));
check('матрица: происхождение HARD-STOP помечено у каждой клетки', N.MATRIX_CELLS.every((c) => typeof c.hardStopSource === 'string' && c.hardStopSource.length > 5));
check('матрица: производные HARD-STOP честно помечены (К7, К9)', ['К7','К9'].every((id) => /производное/.test(N.MATRIX_CELLS.find((c) => c.id === id).hardStopSource)));
check('матрица: факт сверки записан в канон', /совпали полностью/.test(N.MATRIX_VERIFICATION['результат'] || ''));

// ── ось ИППП ротоглотки (версия д-ра Литвака, канон v1.9) ──
const _pSti = { age: 23, sex: 'ж', labs: {}, currentDrugs: [],
  complaints: ['рецидивирующая боль в горле, налёты в глотке и на щеках',
               'безболезненные бляшки на щеках и языке',
               'лихорадки при эпизодах, как правило, нет',
               'сексуально активна, орально-генитальный контакт, партнёр не обследован'] };
const _gSti = T.cantMissGates(_pSti).map((g) => g.trigger).join(' | ');
check('гейт ИППП: рецидивирующий фарингит у сексуально активного → NAAT глотки', /сексуально активн/.test(_gSti));
check('гейт ИППП: безболезненные бляшки щёк и языка → вторичный сифилис', /безболезненные бляшки/.test(_gSti));
const _pChild = { age: 6, sex: 'м', labs: {}, currentDrugs: [],
  complaints: ['рецидивирующая боль в горле, налёты в глотке', 'лихорадки нет'] };
check('гейт ИППП: не навязывается ребёнку 6 лет', !/сексуально активн/.test(T.cantMissGates(_pChild).map((g) => g.trigger).join(' | ')));


// ── РАНЖИРОВАНИЕ ВЫДАЧИ 658 (регрессия: алфавитный срез) ──────────────
// Дефект 74ж: quench658 отдавал .slice(0, limit) по файловому (алфавитному) порядку,
// поэтому в строке «Холод — застой» варфарин и альфузосин выходили раньше левотироксина,
// хотя вся строка Общей таблицы держится на левотироксине как Государе.
const _rowCold = A.matchTreatmentRow(['Холод'], 'зябкость, отёки, утомляемость, запор');
check('ранжир: строка «Холод — застой» подобрана', !!_rowCold && /Холод — застой/.test(_rowCold.energy));
const _qPref = A.quench658('Холод', { limit: 10, prefer: _rowCold && _rowCold.drugs658 });
check('ранжир: при prefer=строка таблицы левотироксин выходит ПЕРВЫМ', /левотироксин/i.test(_qPref[0] && _qPref[0].n));
const _namesPref = _qPref.map((d) => d.n).join(' · ');
// v3.8: после курации по механизму варфарин выпал из десятки ВОВСЕ — проверяем это,
// а не прежний порядок «левотироксин раньше варфарина» (он стал недостижим).
check('ранжир: левотироксин в выдаче, а варфарина в десятке больше нет вовсе',
  _namesPref.search(/левотироксин/i) >= 0 && _namesPref.search(/варфарин/i) === -1);
const _qPlain = A.quench658('Холод', 10);
// Без prefer первым идёт не алфавит, а группа 1 курации (ядро термогенеза);
// левотироксин по-прежнему не первый, потому что внутри группы порядок алфавитный.
check('ранжир: без prefer верхушка — ядро термогенеза, а не алфавитный мусор',
  !/левотироксин/i.test(_qPlain[0] && _qPlain[0].n)
  && _qPlain.slice(0, 5).every((d) => /B12|Инозитол|Кетонов|Креатин|Левотироксин|Лиотиронин|Мирабегрон|Фолиев|глутатион|Среднецепочеч/i.test(d.n)));
check('ранжир: старая сигнатура quench658(energy, number) жива', Array.isArray(_qPlain) && _qPlain.length === 10);
const _qAll = A.quench658('Холод', 500).map((d) => d.n);
// ⭐ 22.09.2026: акорамидис — орфанный стабилизатор ATTR, то есть полоса 4.
// Раньше он просто опускался вниз ранжиром; теперь он не в выдаче вовсе, а в
// списке «за специалистом». Проверка усилена, а не ослаблена: годится любой
// из двух исходов, но «в голове выдачи» не годится ни при каком.
check('ранжир: узкий класс (акорамидис, ATTR-стабилизатор) не в голове выдачи',
  (() => {
    const i = _qAll.findIndex((n) => /акорамидис/i.test(n));
    const за = A.quench658ЗаСпециалистом('Холод').some((d) => /акорамидис/i.test(d.n));
    return (i < 0 && за) || i > 20;
  })());
const _qHint = A.quench658('Холод', { limit: 10, hint: 'гипотиреоз, ТТГ повышен' });
check('ранжир: hint без prefer тоже поднимает левотироксин в голову',
  _qHint.slice(0, 3).some((d) => /левотироксин/i.test(d.n)));
// Версия канона проверяется явно: каждый подъём версии обязан пройти через CHANGELOG.
check('канон: текущая версия (снят самовольный приговор)', ВЕРСИЯ_КАНОНА.совпадает(A.ALGO_SOURCE) && /СЛОЙ ГАРКАВИ/.test(A.ALGO_SOURCE));

// ── гейты метаболического курса (канон v2.9) ─────────────────────────
const _sglt = T.cantMissGates({ age: 52, sex: 'м', labs: {},
  complaints: ['ожирение, висцеральный жир', 'курс снижения веса', 'интервальное голодание, окно питания 8 часов'],
  currentDrugs: ['эмпаглифлозин 10 мг', 'семаглутид 1 мг/нед'] }).map((g) => g.gate).join(' | ');
check('гейт: SGLT-2 + дефицит энергии → эугликемический кетоацидоз', /кетоны крови/.test(_sglt));
check('гейт: сказано, что нормальный сахар НЕ исключает диагноз',
  T.cantMissGates({ age: 52, sex: 'м', labs: {}, complaints: ['кето-диета'], currentDrugs: ['дапаглифлозин'] })
    .some((g) => /близкой к норме глюкозе/.test(g.rule)));
check('гейт: катаболик при снижении веса требует плана перепроверки мембраны', /ПЕРЕПРОВЕРКИ мембраны/.test(_sglt));
check('гейт: при наличии плана перепроверки не навязывается',
  !T.cantMissGates({ age: 52, sex: 'м', labs: {},
    complaints: ['ожирение, курс снижения веса', 'контроль мышечной массы и фазового угла ежемесячно'],
    currentDrugs: ['семаглутид'] }).some((g) => /ПЕРЕПРОВЕРКИ мембраны/.test(g.gate)));
const _canon = require('./_buildA/data/diagnosis_algorithm_canon.json');
const _rank = _canon['база_658'] && _canon['база_658']['ранжирование_выдачи'];
check('канон: блок ранжирование_выдачи существует', !!_rank && /ЗАПРЕЩЁН/.test(_rank['правило']));
check('канон: веса prefer/hint/узкий_класс заданы числами',
  !!_rank && /\+100/.test(_rank['вес']['prefer']) && /\+25/.test(_rank['вес']['hint']) && /−40/.test(_rank['вес']['узкий_класс']));
check('канон: честно записано, что блок «Холод» требует врачебной курации',
  !!_rank && /курация|курации/.test(_rank['знаем_не_исправлено']));


// ══ КУРАЦИЯ БЛОКА «ХОЛОД» ПО ПРИНЦИПУ ДЕЙСТВИЯ (канон v3.8) ═════════
// Задание врача 16.09.2026: «искать по принципу действия и эффекту».
const КУР = A.COLD_CURATION || {};
check('курация: пять групп по механизму', (КУР['группы'] || []).length === 5);
check('курация: помечена как предложение движка, ждущее подписи врача',
  /ЖДЁТ ПОДПИСИ ВРАЧА/.test(String(КУР['статус'] || '')));
check('курация: ни одна позиция не удалена из базы', A.DRUGBASE_658_COUNT === 658
  && /Ни одна позиция не удалена/.test(String(КУР['статус'] || '')));
check('курация: найдена ловушка альфа-агонистов (греют ядро, холодят периферию)',
  /ХОЛОДНЕЮТ/.test(String((КУР['группы'] || [])[2]['⚠_находка'] || '')));
check('курация: антихолинергики вынесены в опасные для этого блока',
  /Оксибутинин/.test(String((КУР['группы'] || [])[4]['позиции'] || ''))
  && /⛔/.test(String((КУР['группы'] || [])[4]['группа'] || '')));

const холод = A.quench658('Холод', 12).map((d) => d.n);
check('верхушка «гасит Холод» — ядро термогенеза, а не алфавит',
  /Левотироксин/.test(холод.join(' ')) && /Лиотиронин/.test(холод.join(' ')) && /Мирабегрон/.test(холод.join(' ')));
check('⚠ ГЛАВНОЕ: варфарина в верхушке больше нет', !холод.includes('Варфарин'));
check('и антидотов с хелаторами тоже',
  !холод.some((n) => /Андексанет|Сугаммадекс|Дефероксамин|Димеркапрол/.test(n)));
const весь = A.quench658('Холод', 60).map((d) => d.n);
// ⛔⛔⛔ 22.09.2026, вечер. ЗДЕСЬ СТОЛКНУЛИСЬ ДВА ЗАПИСАННЫХ ПРАВИЛА, и это
// столкновение стоит объяснить, а не замазать цифрой.
//   ПЕРВОЕ (v3.8): «курация меняет ПОРЯДОК и не удаляет ни одной позиции» —
//     сторож против тихой пропажи из выдачи.
//   ВТОРОЕ (Р-ГЕЛЬЗОЛЬ-18): «полоса 4 не подбирается вовсе» — онкология,
//     системная иммуносупрессия и орфанные не попадают в подбор нигде.
// Утром 22.09 второе правило было поставлено в drugSelect.ts и объявлено
// перенесённым. Вечером выяснилось, что по индексу 658 идут ещё ДВА пути
// мимо него: quench658('Ветер') возвращал 109 позиций полосы 4, включая
// CAR-T и 5-фторурацил.
// ⭐ Правила не противоречат друг другу: полоса 4 не ПРОПАДАЕТ, она
// РАЗДЕЛЕНА на два названных списка. Сумма сохраняется — на это и стоит
// проверка, вместо прежнего «ровно 55 в выдаче».
const заСпец = A.quench658ЗаСпециалистом('Холод');
check('опасные в этом блоке уходят в самый низ', весь.indexOf('Оксибутинин') > весь.length - 5);
// ⛔ 23.09.2026. ЗДЕСЬ СТОЯЛА КОНСТАНТА, ОТКАЛИБРОВАННАЯ НА ДЕФЕКТЕ.
// Было: `весь.indexOf('Варфарин') > 25`. Число 25 подобрали под тогдашний
// порядок, а порядок тогда держался на ОПЕЧАТКЕ: «Андексaнет альфа» был
// записан с ЛАТИНСКОЙ «a», латиница сортируется раньше кириллицы, и позиция
// стояла выше Варфарина, отодвигая его на 26. Как только опечатку починили
// (сторож §4S), Варфарин встал на 25 — и сторож упал, хотя порядок стал
// ПРАВИЛЬНЕЕ, а не хуже. Зелёный тест держался на битых данных.
// Поэтому пишем ПРАВИЛО, а не число: «ниже середины» — это и есть середина
// списка, вычисленная в момент проверки. И добавляем вторую половину правила,
// которой не было вовсе: верхушка обязана быть ЧИСТЫМ ядром термогенеза.
check('формальные уходят ниже середины — считая середину, а не по константе',
  весь.indexOf('Варфарин') > Math.floor(весь.length / 2));
// ⚠ ПЕРВАЯ РЕДАКЦИЯ ЭТОЙ ПРОВЕРКИ БЫЛА БРАКОМ, и это стоит оставить записанным.
// Она сравнивала ПЕРВОЕ СЛОВО имени с текстом группы: «Витамин B12» давал ключ
// «Витамин», а в группе 4 стоит «Витамин K1» — и ядро термогенеза объявлялось
// формальной позицией. Сторож, который врёт, хуже отсутствующего сторожа.
// Чиним причину: сравниваем ПОЛНЫЕ имена, разобрав список группы по разделителю,
// а не подстрокой по первому слову.
check('⭐ и верхушка «гасит Холод» — только группа 1, без формальных и опасных',
  (() => {
    const имена = (i) => String((КУР['группы'] || [])[i]['позиции'] || '')
      .split('·').map((s) => s.trim()).filter(Boolean);
    const низ = new Set([...имена(3), ...имена(4)]);
    const верх = весь.slice(0, 9);
    const чужие = верх.filter((n) => низ.has(n));
    if (чужие.length) console.log('     ⚠ в верхушке чужие: ' + чужие.join(', '));
    return чужие.length === 0 && верх.length === 9;
  })());
check('⛔⭐⭐⭐ полоса 4 из выдачи убрана, но НЕ пропала: сумма двух списков прежняя',
  весь.length + заСпец.length === 55 && заСпец.length > 0);
check('⭐⭐ и у каждой исключённой позиции стоит жёсткий стоп словами',
  заСпец.every((d) => /за онкологом, ревматологом или центром/.test(d.стоп)));
// ⛔ Правило, а не пример: ни по одной энергии подбор не возвращает полосу 4.
check('⛔⭐⭐⭐ НИ ПО ОДНОЙ энергии подбор по индексу 658 не возвращает полосу 4',
  ['Жар', 'Тепло', 'Холод', 'Влажность', 'Сухость', 'Ветер'].every((e) => {
    const выдано = A.quench658(e, 400).map((d) => d.n);
    const за = A.quench658ЗаСпециалистом(e).map((d) => d.n);
    return за.every((n) => выдано.indexOf(n) < 0);
  }));

// ── карточки четырёх добавок протокола ──────────────────────────────
check('карточки четырёх добавок заведены', (A.PROTOCOL_SUPPLEMENT_CARDS || []).length === 4);
check('у каждой карточки есть механизм, доза-ориентир, взаимодействия и HARD-STOP',
  A.PROTOCOL_SUPPLEMENT_CARDS.every((c) => c['механизм'] && c['доза_ориентир'] && c['взаимодействия'] && c['hard_stop']));
check('бутират привязан к кишечному барьеру — адресу v3.6',
  /КИШЕЧНЫЙ БАРЬЕР/.test(String((A.PROTOCOL_SUPPLEMENT_CARDS.find((c) => /Бутират/i.test(c['мнн'])) || {})['уровень_затвора'] || '')));
check('CoQ10 несёт предупреждение про варфарин',
  /варфарин/i.test(String((A.PROTOCOL_SUPPLEMENT_CARDS.find((c) => /Q10/.test(c['мнн'])) || {})['взаимодействия'] || '')));
check('кверцетин несёт CYP3A4 и P-gp',
  /CYP3A4/.test(String((A.PROTOCOL_SUPPLEMENT_CARDS.find((c) => /Кверцетин/i.test(c['мнн'])) || {})['взаимодействия'] || '')));

console.log(`\nСЛОЙ АЛГОРИТМА ДИАГНОЗА: ${ok}/${total}`);
if (ok !== total) process.exit(1);
