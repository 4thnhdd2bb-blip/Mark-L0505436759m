// Тест §4M+§4N — КРАСНЫЕ ФЛАГИ И ФИЛЬТР ВЫХОДА.
//
// Повод 20.09.2026: врач строит сайт для пациента, где «все наши запреты и
// все наши разрешения остаются у нас». Разбор чужого production-кода показал,
// что там красные флаги НЕ ВЫЧИСЛЯЮТСЯ вовсе, а фильтр ждёт кодов, которых
// никто не присылает. Здесь оба слоя живут в кабинете и проверяются.
//
// ⭐ ЯДРО ЭТОГО НАБОРА — ДЕСЯТЬ ПРИЁМОЧНЫХ СЛУЧАЕВ T1–T10 ИЗ ДОКУМЕНТА ВРАЧА.
// Они написаны им, а не мной: если проходят — фильтр делает то, что заказано.

const F = require('./_buildA/engines/redFlags');
const G = require('./_buildA/engines/outputGate');
const ВЕРСИЯ_КАНОНА = require('./_canonVersion');
const canon = require('./_buildA/data/diagnosis_algorithm_canon.json');

let ok = 0, fail = 0;
function check(name, cond) { if (cond) { ok++; console.log('  OK ', name); } else { fail++; console.log('  FAIL', name); } }

check(ВЕРСИЯ_КАНОНА.имя(''), ВЕРСИЯ_КАНОНА.совпадает(canon['версия']));

// ═══ 1. КРАСНЫЕ ФЛАГИ СЧИТАЮТСЯ У НАС ══════════════════════════════
console.log('\n─── §4M красные флаги ───');

const чистый = F.computeRedFlags({ age: 40, symptom_count: 2 });
check('без тревожных данных флагов нет', чистый.флаги.length === 0 && чистый.остановка === 'none');
check('и план разрешён', чистый.планРазрешён === true);

const кризис = F.computeRedFlags({ phq9_item9: 2 });
check('⭐⭐ PHQ-9 п.9 = 2 → CRISIS', кризис.флаги[0] === 'CRISIS' && кризис.кризис === true);
check('и план запрещён', кризис.планРазрешён === false && кризис.остановка === 'crisis');
check('⭐ PHQ-9 п.9 = 1 НЕ даёт кризис — порог именно ≥2',
  F.computeRedFlags({ phq9_item9: 1 }).кризис === false);
check('отсутствие ответа на PHQ-9 не считается кризисом',
  F.computeRedFlags({}).кризис === false);

check('⭐ боль в груди → A_cardiac и жёсткий стоп',
  F.computeRedFlags({ chest_pain: true }).остановка === 'hard_stop');
check('одышка при нагрузке БЕЗ сердцебиения флага не даёт',
  F.computeRedFlags({ dyspnea_exertion: true }).флаги.length === 0);
check('⭐ одышка ВМЕСТЕ с сердцебиением — даёт',
  F.computeRedFlags({ dyspnea_exertion: true, palpitations: true }).флаги[0] === 'A_cardiac');

check('ночные поты + потеря веса → B_systemic',
  F.computeRedFlags({ night_sweats: true, weight_loss: true }).флаги[0] === 'B_systemic');
check('меняющиеся родинки → B_systemic',
  F.computeRedFlags({ changing_moles: true }).флаги[0] === 'B_systemic');
check('только ночные поты — не флаг',
  F.computeRedFlags({ night_sweats: true }).флаги.length === 0);

check('головокружение+онемение+внезапно → C_neuro, мягкий стоп',
  F.computeRedFlags({ dizziness: true, numbness: true, sudden_onset: true }).остановка === 'soft_stop');
check('⭐ два из трёх неврологических — не флаг',
  F.computeRedFlags({ dizziness: true, numbness: true }).флаги.length === 0);

check('≥5 симптомов и возраст ≥65 → D_multi',
  F.computeRedFlags({ symptom_count: 5, age: 65 }).флаги[0] === 'D_multi');
check('те же 5 симптомов в 40 лет — не флаг',
  F.computeRedFlags({ symptom_count: 5, age: 40 }).флаги.length === 0);
check('⭐ три хронических диагноза → D_multi независимо от возраста',
  F.computeRedFlags({ age: 30, diagnoses: ['диабет 2 типа', 'гипертония', 'астма'] })
    .флаги.indexOf('D_multi') >= 0);

check('варфарин → E_medication', F.computeRedFlags({ medications: ['варфарин 5 мг'] })
  .флаги.indexOf('E_medication') >= 0);
check('инсулин → E_medication', F.классыE(['Лантус']).length === 1);
check('⭐ добавки запрещены при E', F.computeRedFlags({ medications: ['ксарелто'] }).добавкиЗапрещены === true);
check('⭐⭐ и при беременности — без отдельного флага',
  F.computeRedFlags({ pregnancy: true }).добавкиЗапрещены === true);

// ⛔ Самое важное правило доверия входу.
const снаружи = F.computeRedFlags({ chest_pain: true, флагиСнаружи: [] });
check('⭐⭐⭐ флаг, посчитанный НАМИ, снаружи снять нельзя',
  снаружи.флаги.indexOf('A_cardiac') >= 0 && снаружи.планРазрешён === false);
const добавлен = F.computeRedFlags({ флагиСнаружи: ['CRISIS'] });
check('⭐ а ДОБАВИТЬ флаг снаружи можно — в сторону безопасности', добавлен.кризис === true);

// ═══ 2. ⭐⭐ ДЕСЯТЬ ПРИЁМОЧНЫХ СЛУЧАЕВ ВРАЧА T1–T10 ═════════════════
console.log('\n─── §4N приёмка T1–T10 (случаи врача) ───');

const действие = (o) => Object.assign({
  action: 'walking', category: 'movement', disease_independent: true, engineSource: 'test',
}, o);

// T1 · PHQ-9 п.143 = «nearly every day» → только ESC_CRISIS, план не генерируется
const t1 = G.ogFilterPlan([действие({}), действие({ action: 'morning_light', category: 'daily_rhythm' })],
  { phq9_item9: 3 });
check('T1 ⭐⭐ кризис: наружу НИ ОДНОГО действия', t1.наружу.length === 0);
check('T1 и единственная эскалация — кризисная', t1.эскалации.length === 1
  && t1.эскалации[0].code === 'ESC_CRISIS');
check('T1 в кризисном тексте есть ער"ן 1201 и 101',
  /1201/.test(t1.эскалации[0].текст.ru) && /101/.test(t1.эскалации[0].текст.ru));

// T2 · боль в груди → ESC_URGENT + максимум универсальный набор, никаких добавок
const t2 = G.ogFilterPlan([
  действие({ action: 'omega3', category: 'supplement_otc' }),
  действие({ action: 'walking' }),
], { chest_pain: true });
check('T2 ⭐⭐ боль в груди: плана нет', t2.наружу.length === 0 && t2.планРазрешён === false);
check('T2 и человеку сказано идти к врачу', t2.эскалации.some((e) => e.code === 'ESC_URGENT'));

// T3 · варфарин + движок предлагает омега-3 3 г → DROP добавки + ESC_MEDS
const t3 = G.ogFilterPlan([действие({ action: 'omega3', category: 'supplement_otc' })],
  { medications: ['варфарин'] });
check('T3 ⭐ добавка при антикоагулянте не выходит', t3.наружу.length === 0);
check('T3 и эскалация именно про препараты', t3.эскалации.some((e) => e.code === 'ESC_MEDS'));

// T4 · беременность + креатин → DROP + ESC_PREGNANCY
const t4 = G.ogFilterPlan([действие({ action: 'creatine', category: 'supplement_otc' })],
  { pregnancy: true });
check('T4 креатин при беременности не выходит', t4.наружу.length === 0);
check('T4 и эскалация про беременность', t4.эскалации.some((e) => e.code === 'ESC_PREGNANCY'));

// T5 · движок вернул строку со словом «мембрана» → DROP + запись дефекта
const t5 = G.ogFilterPlan([действие({ detail: 'Укрепляем мембрану клетки жирными кислотами' })], {});
check('T5 ⭐⭐ внутреннее слово не выходит', t5.наружу.length === 0);
check('T5 и в журнале записано правило лексики',
  t5.журнал[0].rule.indexOf('step5_lexicon') === 0);
check('T5 ⭐ и записан слой движка, который это породил', t5.журнал[0].engineSource === 'test');

// T6 · «метформин 500 мг» → DROP, НЕ escalate (не намекаем)
const t6 = G.ogFilterPlan([действие({ detail: 'Обсудите метформин 500 мг с врачом', category: 'nutrition' })], {});
check('T6 ⭐⭐ Rx-строка отброшена', t6.наружу.length === 0);
check('T6 ⭐⭐⭐ именно DROP, а не эскалация — намёка не остаётся',
  t6.журнал[0].decision === 'drop' && t6.эскалации.length === 0);

// T7 · ХБП + белок 1.5 г/кг → ESC_CONDITION вместо количественной рекомендации
const t7 = G.ogFilterPlan([действие({ action: 'protein_1_5', category: 'nutrition', detail: 'Белок 1.5 г/кг' })],
  { diagnoses: ['ХБП 3 стадии'] });
check('T7 ⭐ количественный белок при ХБП не выходит', t7.наружу.length === 0);
check('T7 и это эскалация «с учётом того, что вы сообщили»',
  t7.эскалации.some((e) => e.code === 'ESC_CONDITION'));
check('T7 ⭐⭐ и причина НЕ названа: в тексте нет слова ХБП',
  !/ХБП|почеч/i.test(t7.эскалации.map((e) => e.текст.ru).join(' ')));

// T8 · чистый пользователь без флагов → 2 действия, без терминов и причин
const t8 = G.ogFilterPlan([
  действие({ action: 'sleep_same_time', category: 'sleep' }),
  действие({ action: 'walking', category: 'movement' }),
], { age: 35 });
check('T8 два действия выходят', t8.наружу.length === 2);
check('T8 ⭐ и в них нет внутренних слов',
  !/мембран|энерги|золь|гель|затвор/i.test(JSON.stringify(t8.наружу)));

// T9 · движок вернул 6 рекомендаций → наружу максимум 2
const шесть = [];
for (let i = 0; i < 6; i++) шесть.push(действие({ action: 'walking_' + i }));
const t9 = G.ogFilterPlan(шесть, {});
check('T9 ⭐ из шести наружу ровно два', t9.наружу.length === 2);

// T10 · ХСН + 2 л воды → ESC_CONDITION
const t10 = G.ogFilterPlan([действие({ action: 'water_2l', category: 'hydration' })],
  { diagnoses: ['ХСН II ФК'] });
check('T10 вода при ХСН не выходит числом', t10.наружу.length === 0);
check('T10 и это ESC_CONDITION', t10.эскалации.some((e) => e.code === 'ESC_CONDITION'));

// ═══ 3. СЕМЬ ШАГОВ ПО ОТДЕЛЬНОСТИ ══════════════════════════════════
console.log('\n─── §4N шаги фильтра ───');

check('шаг 1: категория вне белого списка → DROP',
  G.ogItem(действие({ category: 'medication' }), {}).rule === 'step1_category');
check('⭐ белый список — ровно восемь категорий', G.БЕЛЫЙ_СПИСОК.length === 8);
check('и в нём нет ничего про лекарства',
  G.БЕЛЫЙ_СПИСОК.every((c) => !/med|drug|rx/i.test(c)));

check('⭐⭐ шаг 3 FAIL-CLOSED: независимость не заявлена → эскалация, а не выпуск',
  G.ogItem({ action: 'walking', category: 'movement' }, {}).decision === 'escalate');
check('и правило названо', G.ogItem({ action: 'walking', category: 'movement' }, {}).rule
  === 'step3_disease_dependent');

check('шаг 4: при мягком стопе выходит ТОЛЬКО универсальный набор',
  G.ogItem(действие({ action: 'cold_shower' }), { dizziness: true, numbness: true, sudden_onset: true })
    .rule === 'step4_soft_stop');
const мягкий = G.ogFilterPlan([
  действие({ action: 'walking' }), действие({ action: 'cold_shower' }),
], { dizziness: true, numbness: true, sudden_onset: true });
check('⭐ и ходьба из универсального набора при этом проходит',
  мягкий.наружу.length === 1 && мягкий.наружу[0].action === 'walking');

check('шаг 5: ложная гарантия → DROP',
  G.ogItem(действие({ detail: 'Это доказано и работает на 100%' }), {}).rule.indexOf('step5') === 0);
check('шаг 5: причинный язык «вызывает» → DROP',
  G.ogItem(действие({ detail: 'Недосып вызывает набор веса' }), {}).rule === 'step5_lexicon_causal');
check('⭐ а «связано с» — проходит: это принятый язык v2',
  G.ogItem(действие({ detail: 'Короткий сон связан с более сильным голодом днём' }), {}).decision === 'pass');

// ═══ 4. СВОБОДНЫЙ ТЕКСТ ТОЖЕ ЧЕРЕЗ ФИЛЬТР ══════════════════════════
console.log('\n─── §4N свободный текст ───');
check('⭐⭐ текст модели с внутренним словом не пройдёт',
  G.ogFreeText('Ваша мембрана в фазе золь').ok === false);
check('текст с названием болезни не пройдёт', G.ogFreeText('Это поможет при диабете').ok === false);
check('текст с дозой препарата не пройдёт', G.ogFreeText('Добавьте метформин').ok === false);
check('и причина названа', typeof G.ogFreeText('Добавьте метформин').причина === 'string');
check('нормальный wellness-текст проходит',
  G.ogFreeText('Ложитесь в одно и то же время, разница не больше получаса').ok === true);

// ═══ 5. ЖУРНАЛ И МЕТРИКА ЗДОРОВЬЯ ФИЛЬТРА ══════════════════════════
console.log('\n─── §4N журнал ───');
check('в журнале есть строка на каждое действие', t9.журнал.length === 6);
check('⭐ и у каждой записи есть правило и слой-источник',
  t9.журнал.every((z) => !!z.rule && !!z.engineSource));
const протечка = G.ogLexiconLeakRate([
  { rule: 'step5_lexicon_guard' }, { rule: 'pass' }, { rule: 'pass' }, { rule: 'pass' },
]);
check('⭐⭐ метрика протечки лексики считается (0.25 на четырёх записях)', Math.abs(протечка - 0.25) < 1e-9);
check('на чистом журнале протечка ноль', G.ogLexiconLeakRate([{ rule: 'pass' }]) === 0);
check('сводка называет fail-closed', /fail-closed/i.test(G.ogSummary()));

// ═══ 6. §4O БЕЛЫЙ СПИСОК ДОБАВОК (расширен по модулям либидо и сна) ═
console.log('\n─── §4O добавки ───');
const S = require('./_buildA/engines/supplements');

check('⭐ в списке четырнадцать позиций: 7 базовых + 5 из либидо + 2 из сна',
  S.suppWhitelist().length === 14);
const поИсточникам = S.suppBySource();
check('⭐⭐ из модуля либидо пришли L-цитруллин, гинкго, ашваганда, мака, цинк',
  (поИсточникам['либидо'] || []).join(',') === 'l_citrulline,ginkgo_biloba,ashwagandha_ksm66,maca,zinc');
check('⭐⭐ из модуля сна — магний глицинат и магний L-треонат',
  (поИсточникам['сон'] || []).join(',') === 'magnesium_glycinate,magnesium_threonate');
check('⭐ группа объявлена полем, а не выведена из текста источника: витамин D остался базовым',
  (поИсточникам['базовый'] || []).indexOf('vitamin_d') >= 0);
check('базовый набор на месте', (поИсточникам['базовый'] || []).length === 7);
check('⛔ доз в списке нет ни у одной позиции',
  !/\d+\s*(мг|mg|г\b|g\b|мкг|мкг)/i.test(JSON.stringify(S.ДОБАВКИ)));

check('⭐⭐⭐ добавка ВНЕ списка не выходит — белый список, а не чёрный',
  S.suppCheck('йохимбин', {}).решение === 'drop');
check('и сказано, что расширяется только подписью врача',
  /подписью врача/.test(S.suppCheck('йохимбин', {}).причина));

check('чистому взрослому омега-3 разрешена', S.suppCheck('omega3', { age: 45 }).решение === 'pass');
check('⭐⭐ гинкго при антикоагулянте ЗАПРЕЩЕНО, а не «через врача»',
  S.suppCheck('ginkgo_biloba', { medications: ['варфарин'] }).решение === 'drop');
check('и причина — риск кровотечения',
  /кровотечен/.test(S.suppCheck('ginkgo_biloba', { medications: ['варфарин'] }).причина));
check('⭐⭐ ашваганда при беременности ЗАПРЕЩЕНА',
  S.suppCheck('ashwagandha_ksm66', { pregnancy: true }).решение === 'drop');
check('ашваганда при болезни печени запрещена',
  S.suppCheck('ashwagandha_ksm66', { diagnoses: ['стеатогепатит'] }).решение === 'drop');
// ⚠ Здесь пол и возраст указаны НАМЕРЕННО. Без них сработает гейт
// беременности и вернёт «ask» раньше, чем дело дойдёт до щитовидной железы —
// и это правильно: ответ про беременность меняет исход (запрет против
// осторожности). Взаимодействие двух правил проверяется отдельно ниже.
check('⭐ ашваганда при болезни щитовидной железы — через врача, не запрет',
  S.suppCheck('ashwagandha_ksm66', { sex: 'м', diagnoses: ['гипотиреоз'] }).решение === 'escalate');
check('⭐⭐ магний при ХБП запрещён — он накапливается',
  S.suppCheck('magnesium_glycinate_evening', { diagnoses: ['ХБП 4 ст'] }).решение === 'drop');
check('⭐ и суффикс режима не мешает узнать вещество',
  S.suppCheck('magnesium_threonate_deep', { age: 40 }).решение === 'pass');
check('L-цитруллин с нитратами — через врача (риск гипотензии)',
  S.suppCheck('l_citrulline', { medications: ['изосорбида динитрат'] }).решение === 'escalate');
check('витамин D при гиперкальциемии запрещён',
  S.suppCheck('vitamin_d', { diagnoses: ['саркоидоз'] }).решение === 'drop');
check('CoQ10 при варфарине — через врача', S.suppCheck('coq10', { medications: ['варфарин'] }).решение === 'escalate');
check('⭐ добавки несовершеннолетним не предлагаются автоматически',
  S.suppCheck('omega3', { age: 15 }).решение === 'drop');

// и то же через сам фильтр выхода — сквозная проверка
const добавка = (код) => ({ action: код, category: 'supplement_otc', disease_independent: true, engineSource: 'supp' });
const сквозь = G.ogFilterPlan([добавка('ginkgo_biloba')], { medications: ['ксарелто'] });
check('⭐⭐ сквозь фильтр: гинкго при антикоагулянте наружу не идёт', сквозь.наружу.length === 0);
const сквозьОк = G.ogFilterPlan([добавка('magnesium_glycinate')], { age: 50 });
check('а разрешённая добавка проходит', сквозьОк.наружу.length === 1);
const сквозьЧужая = G.ogFilterPlan([добавка('мельдоний')], { age: 50 });
check('⭐ и добавка вне списка не проходит даже без противопоказаний',
  сквозьЧужая.наружу.length === 0 && сквозьЧужая.журнал[0].rule === 'step4_supp_not_allowed');
check('сводка называет правило белого списка', /белый список/.test(S.suppSummary()));

// ═══ 7. ⭐⭐⭐ ГЕЙТ БЕРЕМЕННОСТИ — ВОПРОС ПЕРЕД НАЗНАЧЕНИЕМ ═════════
// Правило врача 20.09.2026: «перед тем, как ты назначаешь, должно
// спроситься, беременная или нет». Закрывает дыру: раньше незаполненное
// поле молча означало «не беременна».
console.log('\n─── §4O гейт беременности ───');

check('⭐⭐⭐ женщина 30 лет, статус НЕ СПРОШЕН → ашваганда НЕ выдаётся',
  S.suppCheck('ashwagandha_ksm66', { age: 30, sex: 'ж' }).решение === 'ask');
check('⭐⭐ и это ВОПРОС, а не отказ — ответ «нет» её вернёт',
  S.suppCheck('ashwagandha_ksm66', { age: 30, sex: 'ж' }).эскалация === 'ASK_PREGNANCY');
check('⭐ ответила «нет» → добавка разрешена',
  S.suppCheck('ashwagandha_ksm66', { age: 30, sex: 'ж', pregnancy: 'нет' }).решение === 'pass');
check('ответила «да» → запрещена',
  S.suppCheck('ashwagandha_ksm66', { age: 30, sex: 'ж', pregnancy: 'да' }).решение === 'drop');
check('старый boolean false тоже понимается как «нет»',
  S.suppCheck('ashwagandha_ksm66', { age: 30, sex: 'ж', pregnancy: false }).решение === 'pass');

check('⭐ мужчине вопрос не задаётся',
  S.suppCheck('ashwagandha_ksm66', { age: 30, sex: 'м' }).решение === 'pass');
check('⭐ женщине 70 лет вопрос не задаётся — вне фертильного окна',
  S.suppCheck('ashwagandha_ksm66', { age: 70, sex: 'ж' }).решение === 'pass');
check('⭐⭐ пол НЕ УКАЗАН → вопрос задаётся: исключить нельзя',
  S.suppCheck('ashwagandha_ksm66', { age: 30 }).решение === 'ask');
check('⭐ возраст не указан и пол не указан → тоже вопрос',
  S.suppCheck('creatine', {}).решение === 'ask');

// ⭐ Порядок правил, проверенный явно: безусловный запрет СИЛЬНЕЕ вопроса,
// а вопрос СИЛЬНЕЕ осторожности. Так пациента не спрашивают там, где ответ
// ничего не изменит, и спрашивают там, где изменит.
check('⭐⭐ безусловный запрет (печень) срабатывает БЕЗ вопроса о беременности',
  S.suppCheck('ashwagandha_ksm66', { diagnoses: ['цирроз'] }).решение === 'drop');
check('⭐⭐ а осторожность (щитовидка) ждёт ответа про беременность',
  S.suppCheck('ashwagandha_ksm66', { diagnoses: ['гипотиреоз'] }).решение === 'ask');

check('⭐ добавка БЕЗ правил про беременность вопроса не вызывает',
  S.suppCheck('fiber', { age: 30, sex: 'ж' }).решение === 'pass');
check('и омега-3 тоже — у неё нет правил про беременность',
  S.suppCheck('omega3', { age: 30, sex: 'ж' }).решение === 'pass');

const г1 = S.pregnancyGate({ age: 30, sex: 'ж' });
check('гейт прямо говорит: статус неизвестен и надо спросить',
  г1.статус === 'неизвестна' && г1.надоСпросить === true);
check('и называет основание', /исключить его по полу и возрасту нельзя/.test(г1.основание));
check('у мужчины гейт спокоен', S.pregnancyGate({ sex: 'м' }).надоСпросить === false);
check('⭐ фертильное окно объявлено явно и его видно',
  S.ВОЗРАСТ_ФЕРТИЛЬНОСТИ.от === 12 && S.ВОЗРАСТ_ФЕРТИЛЬНОСТИ.до === 55);

// сквозь фильтр: вопрос попадает в отдельный список, не в эскалации
const сВопросом = G.ogFilterPlan([
  { action: 'ashwagandha_ksm66', category: 'supplement_otc', disease_independent: true, engineSource: 'supp' },
  { action: 'walking', category: 'movement', disease_independent: true, engineSource: 'plan' },
], { age: 30, sex: 'ж' });
check('⭐⭐ сквозь фильтр: добавка не выдана, ходьба выдана',
  сВопросом.наружу.length === 1 && сВопросом.наружу[0].action === 'walking');
check('⭐⭐⭐ и вопрос о беременности задан ОТДЕЛЬНЫМ списком',
  сВопросом.вопросы.length === 1 && сВопросом.вопросы[0].code === 'ASK_PREGNANCY');
check('вопрос сформулирован нейтрально, без медицинской причины',
  /возможна ли сейчас беременность/i.test(сВопросом.вопросы[0].текст.ru)
  && !/тератоген|аборт|риск для плода/i.test(сВопросом.вопросы[0].текст.ru));
check('вопрос есть на трёх языках',
  !!сВопросом.вопросы[0].текст.en && !!сВопросом.вопросы[0].текст.he);
check('⭐ в журнале записано правило, по которому спросили',
  сВопросом.журнал.some((z) => z.rule === 'step4_pregnancy_unknown'));
check('после ответа «нет» тот же план выдаёт добавку',
  G.ogFilterPlan([{ action: 'ashwagandha_ksm66', category: 'supplement_otc', disease_independent: true }],
    { age: 30, sex: 'ж', pregnancy: 'нет' }).наружу.length === 1);
check('⭐ при кризисе вопросов не задаётся — там один экран и всё',
  G.ogFilterPlan([{ action: 'maca', category: 'supplement_otc', disease_independent: true }],
    { age: 30, sex: 'ж', phq9_item9: 3 }).вопросы.length === 0);

console.log(`\n§4M+§4N+§4O КРАСНЫЕ ФЛАГИ · ФИЛЬТР ВЫХОДА · ДОБАВКИ · БЕРЕМЕННОСТЬ: ${ok}/${ok + fail}`);
if (fail) process.exit(1);
