#!/usr/bin/env bash
# Регресс стража: компилируем guard.ts и прогоняем оба доказательства (5×2 раундов).
# + §Е (releaseLayer/report): язык/бренд/атрибуция по рынку + golden RU (обратная совместимость).
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
npx tsc --module commonjs --target es2019 --outDir "$DIR/_build" "$DIR/../guard.ts"
node "$DIR/guard.adversarial.test.js"
node "$DIR/guard.harsh.test.js"
echo "СТРАЖ: регресс пройден."
# §Е — слой подачи
npx tsc --module commonjs --target es2019 --esModuleInterop --moduleResolution node \
  --outDir "$DIR/_buildE" "$DIR/../releaseLayer.ts" "$DIR/../report.ts" "$DIR/../guard.ts"
node "$DIR/releaseLayer.test.js"
echo "§Е: слой подачи пройден."
# §2H — слой алгоритма диагноза (объединяет Excel-таблицы + архитектуру)
# ⚠ ОТМЕТКА ВРЕМЕНИ СБОРКИ. Ставится ПЕРЕД tsc: всё, что собрано этим запуском, будет
# новее неё. Сторож ниже требует, чтобы КАЖДЫЙ требуемый тестами модуль был новее отметки —
# иначе он приехал из прежней сборки, и регресс по нему ничего не проверяет.
mkdir -p "$DIR/_buildA"
rm -f "$DIR/_buildA/.buildstamp"
touch "$DIR/_buildA/.buildstamp"
npx tsc --module commonjs --target es2019 --esModuleInterop --moduleResolution node --resolveJsonModule \
  --rootDir "$DIR/../.." \
  --outDir "$DIR/_buildA" "$DIR/../diagnosisAlgorithm.ts" "$DIR/../solGel.ts" \
  "$DIR/../membraneGate.ts" "$DIR/../phaseTransition.ts" "$DIR/../subjugation.ts" "$DIR/../energyFilter.ts" "$DIR/../clinch.ts" "$DIR/../geneLayer.ts" "$DIR/../geneSuspicion.ts" "$DIR/../chargeLayer.ts" "$DIR/../reviciLayer.ts" "$DIR/../garkavi.ts" "$DIR/../tom4.ts" "$DIR/../surveyCrosswalk.ts" "$DIR/../energyGrid.ts" "$DIR/../phaseUsin.ts" "$DIR/../quantityQuality.ts" "$DIR/../gateSixEnergies.ts" "$DIR/../gateSubstanceAxis.ts" "$DIR/../membraneOpenClose.ts" "$DIR/../geroEvidence.ts" "$DIR/../chronoLayer.ts" "$DIR/../redFlags.ts" "$DIR/../supplements.ts" "$DIR/../outputGate.ts" "$DIR/../prescribeGate.ts" "$DIR/../drugSelect.ts" "$DIR/../planGuards.ts" "$DIR/../gelSolDrugs.ts" "$DIR/../gelSolClasses.ts" "$DIR/../gelSolEffects.ts" "$DIR/../gelSolRoles.ts" "$DIR/../gelSolRoot.ts" "$DIR/../gelSolYinYang.ts" "$DIR/../baseExtend.ts" "$DIR/../baseTable.ts" "$DIR/../cabinetApi.ts" "$DIR/../coreContract.ts" "$DIR/../protocol.ts" \
  "$DIR/../pipeline.ts" "$DIR/../guard.ts" \
  "$DIR/../consistency.ts" "$DIR/../compartments.ts" "$DIR/../membraneLibrary.ts" \
  "$DIR/../readWindow.ts" "$DIR/../otherChoice.ts" "$DIR/../priorEvidence.ts" \
  "$DIR/../myelomaPrinciple.ts" "$DIR/../acuteKidney.ts" \
  "$DIR/../maturationCheckpoint.ts" "$DIR/../autoimmuneClone.ts" "$DIR/../phaseEnergy.ts" \
  "$DIR/../masks.ts" "$DIR/../safetyGate.ts" "$DIR/../enrich.ts" "$DIR/../signQueue.ts" \
  "$DIR/../canonRegistry.ts" "$DIR/../renalSyndrome.ts" "$DIR/../edemaBlock.ts" \
  "$DIR/../complaintGates.ts" "$DIR/../sequence.ts" "$DIR/../consent.ts" "$DIR/../surveyIntake.ts" "$DIR/../patientContour.ts" "$DIR/../imageIntake.ts" "$DIR/../lifestyleActions.ts" "$DIR/../identityGate.ts" "$DIR/../triage.ts" "$DIR/../homeostasisCost.ts" "$DIR/../dxDifferential.ts" "$DIR/../nextStep.ts" "$DIR/../ddiGuard.ts" "$DIR/../doseRange.ts" "$DIR/../drugName.ts" "$DIR/../comorbidity.ts" "$DIR/../neuroDegeneration.ts"
# ⛔⛔ 26.09.2026, ТОТ ЖЕ ДЕФЕКТ, ЧТО 16.09: четыре движка — readWindow, otherChoice,
# priorEvidence, myelomaPrinciple — тесты ТРЕБОВАЛИ, а run.sh НЕ СОБИРАЛ. Они лежали в
# _buildA от ручных сборок и регресс шёл по ним. Сторож сборки их пропускал, потому что
# проверял НАЛИЧИЕ файла, а не его СВЕЖЕСТЬ. Ниже сторож усилен отметкой времени.
# ⚠ 16.09.2026: consistency/compartments/membraneLibrary тесты ТРЕБУЮТ, а run.sh их не собирал.
# Регресс месяц проходил на СТАРОМ артефакте в _buildA, оставшемся от прежней сборки: стоило
# очистить каталог — и suite упал на пустом месте. Зелёный тест на устаревшем .js — это
# не проверка, а её имитация. Ниже стоит сторож, который ловит расхождение списков.
bash "$DIR/buildCoverage.sh" "$DIR"
mkdir -p "$DIR/_buildA/data"
cp "$DIR/../../data/diagnosis_algorithm_canon.json" "$DIR/_buildA/data/"
cp "$DIR/../../data/drug_index_658.json" "$DIR/_buildA/data/"
cp "$DIR/../../data/drugbase.json" "$DIR/_buildA/data/"
cp "$DIR/../../data/dx_organs.json" "$DIR/_buildA/data/"
cp "$DIR/../../data/phase_transitions.json" "$DIR/_buildA/data/"
cp "$DIR/../../data/gene_layer.json" "$DIR/_buildA/data/"
cp "$DIR/../../data/tom4_encyclopedia.json" "$DIR/_buildA/data/"
node "$DIR/diagnosisAlgorithm.test.js"
echo "§2H: слой алгоритма диагноза пройден."
# §2P — третья ось: затвор мембраны (Тепло открывает / Сухость закрывает)
node "$DIR/membraneGate.test.js"
echo "§2P: слой затвора мембраны пройден."
# §2Q — два закона: подчинение (цикл Ко) + противоподчинение (проф. Пак)
node "$DIR/subjugation.test.js"
echo "§2Q: два закона управления энергией пройдены."
# §2U — фильтр энергий: оси и пучки (канон v4.0)
node "$DIR/energyFilter.test.js"
echo "§2U: фильтр энергий пройден."
# §2T — клинч энергий по Ко: хроническое залипшее равновесие пары + двойное гашение
node "$DIR/clinch.test.js"
echo "§2T: клинч энергий пройден."
# §2V — ген-слой: ген как ОТВЕТ, а не выключатель (канон v4.1)
node "$DIR/geneLayer.test.js"
echo "§2V: ген-слой пройден."
# §2W — зацепки: энергия + симптом + семья → ген-модуль (канон v4.2)
node "$DIR/geneSuspicion.test.js"
echo "§2W: слой зацепок пройден."
# §2X — слой заряда: золь⇄гель на четырёх уровнях (канон v4.3)
node "$DIR/chargeLayer.test.js"
echo "§2X: слой заряда пройден."
# §2Y — слой Ревичи: архитектура принята, терапевтическая программа отвергнута (канон v4.4)
node "$DIR/reviciLayer.test.js"
echo "§2Y: слой Ревичи пройден."
# §3A/§3B — Гаркави: адаптационные реакции и опросник → предсказанная кровь → фаза (канон v4.7)
node "$DIR/garkavi.test.js"
echo "§3A/§3B: слой Гаркави пройден."
# §2Z — Том IV: полная энциклопедия «Мембрана→Ген» (канон v4.8)
node "$DIR/tom4.test.js"
echo "§2Z: слой Тома IV пройден."
# §3D — мост «наша анкета 169 → опросник Гаркави 10» (канон v5.0)
node "$DIR/surveyCrosswalk.test.js"
echo "§3D: мост анкеты пройден."
# §2S — единый регламент разбора и ГЕЙТ ВЫПУСКА (применяется к каждому разбору)
node "$DIR/protocol.test.js"
echo "§2S: регламент и гейт выпуска пройдены."
# §2S-2 — ПРИНУЖДЕНИЕ: регламент нельзя обойти ни пайплайном, ни ответом модели
node "$DIR/regulationEnforced.test.js"
echo "§2S-2: принуждение регламента пройдено."
# §4B — СЕТКА ЭНЕРГИЯ × ОРГАН: 84 клетки, найдена в Drive непрочитанной (v5.6)
node "$DIR/energyGrid.test.js"
echo "§4B: сетка 84 пройдена."
# §4C — ДУГА ФАЗ НА КОЛЬЦЕ У-СИН: противоподчинение, проверено расчётом (v5.7)
node "$DIR/phaseUsin.test.js"
echo "§4C: дуга фаз на кольце пройдена."
# §4E — ЯДРО: вход · автономный якорь · матрица анализ→энергия · формат (v5.9)
node "$DIR/coreContract.test.js"
echo "§4E: ядро пройдено."
# §4A — ДИСЦИПЛИНА ВОЗВРАТА: предупредить о сжатии · читать канон · не советовать вне канона (v5.5)
node "$DIR/discipline.test.js"
echo "§4A: дисциплина возврата пройдена."
# §4G — КОЛИЧЕСТВО и КАЧЕСТВО: магнит выведен из лечебного выхода METACOD (v6.4)
node "$DIR/quantityQuality.test.js"
echo "§4G: количество и качество пройдены."
# §4H — ЗАТВОР: шесть энергий · забрать или добавить (Drive 1nZfLIn1G5S..., v6.5)
node "$DIR/gateSixEnergies.test.js"
echo "§4H: затвор шести энергий пройден."
# §4I — ОТКРЫТИЕ И ЗАКРЫТИЕ МЕМБРАН (Drive 1x_isMF… и 12-XmbO…, v6.6)
node "$DIR/membraneOpenClose.test.js"
echo "§4I: открытие и закрытие мембран пройдено."
# §4J — ДОКАЗАТЕЛЬНОСТЬ ГЕРОПРОТЕКЦИИ: EBM-слой + стражи плана (v6.8)
node "$DIR/geroEvidence.test.js"
echo "§4J: слой доказательности геропротекции пройден."
# §4K — ХРОНО-СЛОЙ: перенос модуля @metacod/engine/chrono в кабинет (v6.9)
node "$DIR/chronoLayer.test.js"
echo "§4K: хроно-слой пройден."
# §4M+§4N — КРАСНЫЕ ФЛАГИ И ФИЛЬТР ВЫХОДА (заказ врача 20.09.2026: сайт для пациента)
node "$DIR/outputGate.test.js"
echo "§4M+§4N: красные флаги и фильтр выхода пройдены."
# §4P — ГЕЙТ НАЗНАЧЕНИЯ: граница по подписи (решение врача 20.09.2026, Р-САЙТ-3 «Первое»)
node "$DIR/prescribeGate.test.js"
echo "§4P: гейт назначения пройден."
# §4Q — ЗАЩИТА ПЛАНА · АРСЕНАЛ · КАЛЕНДАРЬ (два документа врача в Drive 20.09.2026)
node "$DIR/planGuards.test.js"
echo "§4Q: защита плана, арсенал и календарь пройдены."
# §4R — ГЕЛЬ⇄ЗОЛЬ И ЗАТВОР У ПРЕПАРАТОВ (упрёк врача 21.09.2026: таблицы есть, а не применялись)
node "$DIR/gelSolDrugs.test.js"
echo "§4R: гель-золь и затвор у препаратов пройдены."
# §4R-3 — ТРЕТЬЯ ОСЬ: побочка и кто её отменяет (распоряжение врача 21.09.2026)
node "$DIR/gelSolEffects.test.js"
echo "§4R-3: побочка и её отменитель пройдены."
# §4R-4 — РОЛЬ ПО ОСЯМ: правило выведено из подписи врача и ею же проверяется
node "$DIR/gelSolRoles.test.js"
echo "§4R-4: роль по осям пройдена."
# §4R-5 — КОРЕНЬ: «Царь бьёт по корню, Министр усиливает» (Р-ГЕЛЬЗОЛЬ-6)
node "$DIR/gelSolRoot.test.js"
echo "§4R-5: корень и роли из таблицы врача пройдены."
# §4R-6 — ИНЬ/ЯН · забрать или добавить · два лица Ветра (документ врача 21.09.2026)
node "$DIR/gelSolYinYang.test.js"
echo "§4R-6: инь/ян, забрать/добавить и два лица Ветра пройдены."
# §4S — ЕДИНАЯ БАЗОВАЯ ТАБЛИЦА: энергии · гель-золь · мембраны (распоряжение врача 21.09.2026)
node "$DIR/baseTable.test.js"
# §4Ж — ЗАВЕДЕНИЕ 12 ПОЗИЦИЙ И ПРАВКА ДВУХ КЛАССОВ (слово врача 25.09.2026 «заводи и правь»)
node "$DIR/baseEntered.test.js"
echo "§4Ж: заведение позиций и правка классов пройдены."
# ПЕЧАТЬ ПОДПИСАННОЙ БАЗЫ — НАСТОЯЩИЙ md5 ФАЙЛА (Р-БАЗА-1 и Р-ОПН-6, подпись врача 29.09.2026).
# ⛔ До 29.09.2026 неизменность базы «сторожили» два теста, искавшие строку md5 В ТЕКСТЕ КАНОНА,
# то есть проверявшие, что канон о себе говорит, а не что файл не изменён.
node "$DIR/drugbaseSeal.test.js"
echo "ПЕЧАТЬ БАЗЫ: настоящий md5 сверен, десять заведённых позиций без доктрины."
# §4И — ЗАВЕДЕНИЕ 16 ПОЗИЦИЙ И ПРАВИЛО ПОРЯДКА ХОДОВ (слово врача 25.09.2026 «заводи двадцать позиций и запиши правило»)
node "$DIR/baseEntered4I.test.js"
echo "§4И: шестнадцать позиций и правило порядка ходов пройдены."
# §4И-2 — ПОДПИСАННОЕ ПРАВИЛО ПОРЯДКА ХОДОВ СДЕЛАНО ИСПОЛНЯЕМЫМ (подпись врача 25.09.2026 «Подписываю правило порядка ходов»)
node "$DIR/orderOfMoves.test.js"
echo "§4И-2: подписанное правило порядка ходов исполняется движком."
# §4К — ОКНО ЧТЕНИЯ ОТВЕТА (слово врача 25.09.2026 «Запиши это в канон»; ЗАПИСАНО, не подписано)
node "$DIR/readWindow.test.js"
echo "§4К: окно чтения ответа пройдено."
# §4Л — КОГДА ВЫБРАН ДРУГОЙ ХОД (слово врача 25.09.2026 «Запиши это в канон»; ЗАПИСАНО, не подписано)
node "$DIR/otherChoice.test.js"
echo "§4Л: правило «когда выбран другой ход» пройдено."
# §4М — ПРЕЖДЕ ЧЕМ НАЗНАЧИТЬ (слово врача 25.09.2026 «Запиши это в канон»; ЗАПИСАНО, не подписано)
node "$DIR/priorEvidence.test.js"
echo "§4М: правило «прежде чем назначить» пройдено."
# §4Н — ПРИНЦИП МИЕЛОМЫ (слово врача 26.09.2026 «Запиши это в канон»; ЗАПИСАНО, не подписано)
node "$DIR/myelomaPrinciple.test.js"
echo "§4Н: принцип миеломы пройден."
# §4О — ПРИНЦИП ОСТРОЙ ПОЧКИ (слово врача 26.09.2026 «Запиши это в канон»; ЗАПИСАНО, не подписано)
node "$DIR/acuteKidney.test.js"
echo "§4О: принцип острой почки пройден."
echo "§4S: единая базовая таблица пройдена."
# §4L — API КАБИНЕТА: локальный HTTP-адаптер (заказ врача 19.09.2026)
node "$DIR/cabinetApi.test.js"
echo "§4L: API кабинета пройден."
# §4X — ОСЬ ЗАТВОРА ДЛЯ ВЕЩЕСТВА: fail-closed (упрёк врача 24.09.2026 «ты совсем это упустил»)
node "$DIR/gateSubstanceAxis.test.js"
echo "§4X: ось затвора для вещества пройдена."
# §4Z — ПРИНЦИП НЕЙРОДЕГЕНЕРАЦИИ: закон Тепла и Сухости, ось GLP-1, четыре ступени (слово врача 25.09.2026 «запиши это в канон»)
node "$DIR/principleNeurodegeneration.test.js"
echo "§4Z: принцип нейродегенерации пройден."
# §4F — АРХИТЕКТУРА И ПОЛНОТА ПАСПОРТА
node "$DIR/architecture.test.js"
echo "§4F: архитектура и полнота паспорта пройдены."
# §4П §4Р §4С — линия клона: точка созревания, аутоиммунный клон, движение по фазам.
# Заведены 27.09.2026, привиты к кабинету 28.09.2026 после возврата дерева из Drive.
node "$DIR/maturationCheckpoint.test.js"
echo "§4П: точка созревания пройдена."
node "$DIR/autoimmuneClone.test.js"
echo "§4Р: аутоиммунный клон пройден."
node "$DIR/phaseEnergy.test.js"
echo "§4С: движение энергии по фазам пройдено."

# §4Т — маски до вектора. Правило жило в SKILL.md прозой и не исполнялось ни одним
# движком; 28.09.2026 перенесено в канон дословно и сделано исполняемым.
node "$DIR/masks.test.js"
echo "§4Т: маски до вектора пройдены."

# §4У — предохранительный контур. Поставлен 28.09.2026 после аудита, показавшего, что
# 32 движка из 60 не вызывает никто, включая ПОДПИСАННЫЙ гейт назначения Р-САЙТ-3.
node "$DIR/safetyGate.test.js"
echo "§4У: предохранительный контур пройден."

# §4Ф — слой обогащения: семнадцать движков знания, до 28.09.2026 не вызываемых никем.
node "$DIR/enrich.test.js"
echo "§4Ф: слой обогащения пройден."

# ОЧЕРЕДЬ НА ПОДПИСЬ: чем снимается validated:false (28.09.2026).
node "$DIR/signQueue.test.js"
echo "Очередь на подпись пройдена."

# ПУТЬ В ОБЛАКО (01.10.2026): цепочка разбор → контур → очередь → подпись → документ пациента.
node "$DIR/cloudPath.test.js"
echo "Путь в облако пройден."

# §4V ПОЧЕЧНЫЙ СИНДРОМ и §4W БЛОК ОТЁКА — слои, потерянные до 28.09.2026.
node "$DIR/renalEdema.test.js"
echo "§4V и §4W пройдены."

# ПОСЛЕДОВАТЕЛЬНОСТЬ РАЗБОРА и СВЯЗКА ЖАЛОБ С АНАЛИЗАМИ (28.09.2026).
node "$DIR/sequence.test.js"
echo "Последовательность и связка пройдены."

# СОГЛАСИЕ ПАЦИЕНТА (28.09.2026).
node "$DIR/consent.test.js"
echo "Согласие пройдено."

# ПРИЁМ АНКЕТЫ В РАЗБОР (28.09.2026).
node "$DIR/surveyIntake.test.js"
echo "Приём анкеты пройден."

# ПАЦИЕНТСКИЙ КОНТУР: фильтр выхода §4N на пути (28.09.2026).
node "$DIR/patientContour.test.js"
echo "Пациентский контур пройден."

# ЗАГРУЗКА СНИМКА: распознанное не становится измерением без человека (28.09.2026).
node "$DIR/imageIntake.test.js"
echo "Загрузка снимка пройдена."

# СЛОЙ ДЕЙСТВИЙ: разбор становится тем, что человек может сделать (28.09.2026).
node "$DIR/lifestyleActions.test.js"
echo "Слой действий пройден."

# §4Э ТОЖДЕСТВО ЛИЧНОСТИ: Р-ФИШЕР-4 переписан подписью врача 29.09.2026.
# Связность клинической картины больше НЕ является доводом за тождество личности.
node "$DIR/identityGate.test.js"
echo "§4Э тождество личности пройдено."

# §4Ю ПЕРВИЧНЫЙ ФИЛЬТР ЖАЛОБЫ: слова больного → вход подписанных красных флагов.
# До 29.09.2026 этого пути не существовало: «боль в груди» давала план.
node "$DIR/triage.test.js"
echo "§4Ю первичный фильтр жалобы пройден."

# §4Я ЦЕНА ГОМЕОСТАЗА: подпись врача 29.09.2026. Норма, удержанная большим
# усилием регулятора, — это предболезнь. Пара локализует поломку.
node "$DIR/homeostasisCost.test.js"
echo "§4Я цена гомеостаза пройдена."

# §4Щ КАНОНИЧЕСКОЕ ИМЯ ПРЕПАРАТА: разрешение врача 30.09 «препараты можно все на
# Английском языке». Девять омоглифов, бренды и МНН ведут к одному препарату.
node "$DIR/drugName.test.js"
echo "§4Щ каноническое имя препарата пройдено."

# §5В БИБЛИОТЕКА КОМОРБИДНОСТИ: 1200 сочетаний, разобранных врачом. Лежала в
# кабинете с 28.09 и не читалась ни одним движком. ⛔ ПРЕЦЕДЕНТ, А НЕ НАЗНАЧЕНИЕ.
node "$DIR/comorbidity.test.js"
echo "§5В библиотека коморбидности пройдена."

# §4Z ДВИЖОК НЕЙРОДЕГЕНЕРАЦИИ: ключ жил прозой с 25.09 и числился долгом.
# Четыре ступени, гейт антиамилоида и правило противовеса стали исполняемыми.
node "$DIR/neuroDegeneration.test.js"
echo "§4Z движок нейродегенерации пройден."

# §4Ш ВИЛКА ДОЗЫ: мастер гель-золь, 658 препаратов. Молчал с 28.09.
# ⛔ Вилка — ОРИЕНТИР, а не граница: предохранителя на ней нет.
node "$DIR/doseRange.test.js"
echo "§4Ш вилка дозы пройдена."

# §4Ч СЛОЙ DDI: справочник врача на 724 пары. Лежал в кабинете с 28.09 и не
# читался НИ ОДНИМ движком; первая конвертация свела шесть колонок Excel к двум.
node "$DIR/ddiGuard.test.js"
echo "§4Ч слой DDI пройден."

# §5А ДИФФЕРЕНЦИАЛЬНЫЙ РЯД: блок 2 регламента наконец имеет движок. Гипотезы
# ПОРОЖДАЮТСЯ, а не только ранжируются. Опасность независима от вероятности.
node "$DIR/dxDifferential.test.js"
echo "§5А дифференциальный ряд пройден."

# §5Б АЛГОРИТМ 7: один следующий шаг. Безопасность перекрывает оптимизацию,
# подписанный гейт выше любого балла, порог действия Паукера–Кассирера.
node "$DIR/nextStep.test.js"
echo "§5Б Алгоритм 7 пройден."

# Структурные регрессы: кириллический \w/\b и покрытие канона движком
node "$DIR/lint.cyrillic.test.js"
# ЛИНТ СТОРОЖЕЙ: проверка, привязанная к одному имени, умирает от подписи врача
node "$DIR/lint.guards.test.js"
# СТОРОЖ СИРОТ: ни одного движка без вызова на пути разбора (28.09.2026).
node "$DIR/lint.orphans.test.js"
# ЛИНТ ГРАНИЦЫ СЛОВА: `\b` рядом с кириллицей — всегда дефект (28.09.2026).
node "$DIR/lint.wordboundary.test.js"
# СТОРОЖ ОДНОЙ ДВЕРИ: ни один транспорт не выдаёт разбор мимо политики (28.09.2026).
node "$DIR/lint.onedoor.test.js"
# СТОРОЖ ФАЙЛОВ ДАННЫХ: у каждой таблицы врача есть читатель или причина (30.09.2026).
node "$DIR/lint.dataReaders.test.js"
# СТОРОЖ ПОТЕРЯННЫХ СЛОЁВ: у каждого ключа канона есть исполнитель или причина (28.09.2026).
node "$DIR/lint.canonReaders.test.js"
# ЛИНТ СТИЛЕЙ: ни одного встроенного стиля в экранах (28.09.2026).
node "$DIR/lint.styles.test.js"
# ЛИНТ РАЗВЁРТЫВАНИЯ: ключи, роли, инструкция — и ни одного живого ключа (28.09.2026).
node "$DIR/lint.setup.test.js"
node "$DIR/canonCoverage.test.js"
echo "Структурные регрессы пройдены."
