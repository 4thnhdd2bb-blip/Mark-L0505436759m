// ДОКАЗАТЕЛЬСТВО: наружу (conventional) не выходит НИ ОДНОГО внутреннего слова.
// 5 раундов, вход перегружен внутренними терминами. Условие успеха: residualHits=[] всегда.
const G = require('./_build/guard.js');

// Атакующие входы — как будто модель «протекла» и насовала внутренних слов везде.
const attacks = [
  {
    logic: 'У пациента избыток энергии Холод и Влажность, дефицит Тепла; инь-ян разбаланс.',
    hypotheses: [
      { dx: 'Мембрана M-D1 повреждена, золь перешёл в гель', rank: 1, why: 'CA-фаза, Холод' },
      { dx: 'PCL-A с переходом на M-A2', rank: 2, why: 'эпикризис близко, норматония далеко' },
    ],
    cannotMiss: ['по Ревичи анаболизм', 'по Хамеру конфликт', 'JCZ: Царь слаб, Министр в избытке'],
    workup: {
      step1_history: ['Загускин биоритм', 'меридиан лёгких', 'точка канона'],
      step2_labs: ['MWI фазовый', 'GTM индекс', 'Слой-0 бислой'],
      step3_imaging: ['прижигание зоны', 'моксибастия', 'иглоукалывание'],
      step4_referrals: ['Помощник и Посол по JCZ'],
    },
    redFlags: ['Жар нарастает', 'сухость слизистых', 'ветер внутренний', 'тепло уходит'],
    summary: 'Итог: сдвиг мембраны M-S, золь-гель, CA→PCL-B, норматония как цель. Пак Дже Ву.',
  },
  {
    logic: 'ЭНЕРГИЯ ВЕТЕР и ЖАР; МЕМБРАНА M-A3; ЗОЛЬ/ГЕЛЬ; ЯН-дефицит.',
    hypotheses: [{ dx: 'M-0 норматония, эпикризис', rank: 1, why: 'MWI/GTM' }],
    cannotMiss: ['моксибастия', 'меридианы'],
    workup: { step1_history: ['инь'], step2_labs: ['ян'], step3_imaging: ['гель'], step4_referrals: ['золь'] },
    redFlags: ['холодная влажность'],
    summary: 'Царь-Министр-Помощник-Посол, PCL-A, Слой-0.',
  },
];

// Легальные клинические слова, которые НЕ должны пострадать (ложных срабатываний быть не должно).
const legalWords = ['кальян', 'ветеран', 'пожар', 'жаропонижающее', 'тепловой удар — это диагноз',
  'помощь пациенту', 'вспомогательная терапия', 'посольство', 'фаза болезни', 'фазовый угол биоимпеданса'];

const STOP = [/энерги/iu,/\bинь\b/iu,/\bян\b/iu,/холод/iu,/сухост/iu,/влажност/iu,/\bжар\b/iu,/\bтепло\b/iu,
  /золь/iu,/гель/iu,/мембран/iu,/бислой/iu,/M-?[ADS0-9]/u,/PCL/iu,/эпикризис/iu,/норматони/iu,/Ревичи/iu,
  /Хамер/iu,/Загускин/iu,/JCZ/iu,/Царь/iu,/Министр/iu,/Помощник/iu,/Посол/iu,/меридиан/iu,/прижиг/iu,
  /мокс/iu,/иглоук/iu,/MWI/iu,/GTM/iu,/Слой-?0/iu,/CA[-\s]?фаз/iu];

let ok = true;
for (let round = 1; round <= 5; round++) {
  for (let i = 0; i < attacks.length; i++) {
    const enforced = G.enforceConventional(JSON.parse(JSON.stringify(attacks[i])));
    const out = JSON.stringify(enforced.obj);
    // 1) страж говорит чисто
    if (!enforced.clean || enforced.residualHits.length) { ok = false;
      console.log(`❌ R${round} attack${i}: residualHits=`, enforced.residualHits); }
    // 2) независимый grep стоп-слов по финальному тексту
    const leaked = STOP.filter((re) => re.test(out)).map(String);
    if (leaked.length) { ok = false; console.log(`❌ R${round} attack${i}: LEAK grep`, leaked, out); }
  }
}

// 3) ложных срабатываний нет: легальные слова целы
const legalOut = G.enforceClean({ t: legalWords.join(' | ') });
const survived = legalWords.filter((w) => legalOut.obj.t.includes(w));
console.log(`Легальные слова целы: ${survived.length}/${legalWords.length}`);
if (survived.length !== legalWords.length) {
  ok = false; console.log('❌ пострадали:', legalWords.filter((w)=>!legalOut.obj.t.includes(w)));
}

console.log(ok
  ? '\n✅ 5/5 РАУНДОВ ЧИСТО — ни одно внутреннее слово не вышло наружу. residualHits=[] везде.'
  : '\n❌ ЕСТЬ УТЕЧКА — НЕ ВЫПУСКАТЬ.');
process.exit(ok ? 0 : 1);
