// ═══════════════════════════════════════════════════════════════════
// ЛИНТ СТИЛЕЙ: ни одного встроенного стиля в экранах.
//
//   СТИЛЬ, НАПИСАННЫЙ ВНУТРИ ЭКРАНА, РАСХОДИТСЯ С ТАКИМ ЖЕ В СОСЕДНЕМ
//   ЭКРАНЕ — И НИКТО ЭТОГО НЕ ЗАМЕЧАЕТ.
//
// ⛔ Требование врача 28.09.2026 для передачи Омеру: «разделите все стили на
// отдельные файлы». Требование не разовое: без сторожа встроенные стили
// возвращаются с первым же новым экраном.
// ═══════════════════════════════════════════════════════════════════
const fs = require('fs');
const path = require('path');

const КОРЕНЬ = path.join(__dirname, '..', '..', '..');
const CLIENT = path.join(КОРЕНЬ, 'client');

let ok = 0;
let fail = 0;
function check(имя, условие) {
  if (условие) { ok++; console.log('  OK  ' + имя); }
  else { fail++; console.log('  FAIL ' + имя); }
}

function файлы(каталог, где) {
  if (!fs.existsSync(каталог)) { return где; }
  for (const имя of fs.readdirSync(каталог)) {
    const п = path.join(каталог, имя);
    if (fs.statSync(п).isDirectory()) { файлы(п, где); }
    else if (/\.tsx$/.test(имя)) { где.push(п); }
  }
  return где;
}

const экраны = файлы(path.join(CLIENT, 'src', 'screens'), []);
const все = экраны.concat(fs.existsSync(path.join(CLIENT, 'App.tsx'))
  ? [path.join(CLIENT, 'App.tsx')] : []);

check('экраны найдены', экраны.length >= 10);

const сВстроенными = все.filter((п) => /style=\{\{/.test(fs.readFileSync(п, 'utf8')))
  .map((п) => path.basename(п));
check('⛔⛔⛔ НИ ОДНОГО ВСТРОЕННОГО СТИЛЯ В ЭКРАНАХ', сВстроенными.length === 0);
if (сВстроенными.length) {
  console.log('     ⚠ встроенные стили в: ' + сВстроенными.join(', '));
  console.log('     Вынесите их в client/src/styles/*.styles.ts.');
}

// ⛔ И обратная сторона: StyleSheet.create не должен появляться в экране.
const сТаблицей = все.filter((п) => /StyleSheet\.create/.test(fs.readFileSync(п, 'utf8')))
  .map((п) => path.basename(п));
check('⛔ и ни одной таблицы стилей, объявленной прямо в экране',
  сТаблицей.length === 0);

const стили = fs.existsSync(path.join(CLIENT, 'src', 'styles'))
  ? fs.readdirSync(path.join(CLIENT, 'src', 'styles')).filter((f) => /\.ts$/.test(f)) : [];
check('⭐ файлов стилей не меньше пяти', стили.length >= 5);
check('⭐ тема вынесена отдельным файлом', стили.indexOf('theme.ts') >= 0);

// ⭐ Каждый экран, который стилями пользуется, берёт их из файла стилей.
const безИмпорта = экраны.filter((п) => {
  const t = fs.readFileSync(п, 'utf8');
  return /style=\{/.test(t) && !/from '\.\.\/styles\//.test(t);
}).map((п) => path.basename(п));
check('⭐ каждый экран берёт стили из файла стилей', безИмпорта.length === 0);
if (безИмпорта.length) { console.log('     ⚠ ' + безИмпорта.join(', ')); }

console.log('\nlint.styles: OK=' + ok + ' FAIL=' + fail
  + ' · экранов ' + экраны.length + ', файлов стилей ' + стили.length);
process.exit(fail === 0 ? 0 : 1);
