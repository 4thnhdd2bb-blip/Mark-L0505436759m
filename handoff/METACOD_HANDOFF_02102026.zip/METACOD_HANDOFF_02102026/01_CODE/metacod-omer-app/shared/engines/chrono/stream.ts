/**
 * @metacod/engine — module `chrono`
 * stream.ts — real-time sliding-window controller for the C-Stell loop.
 *
 * Feeds raw samples in, recomputes the chrono-index every `hopSec`, and — in
 * between recomputes — emits an instantaneous GATE for the therapy apparatus,
 * phase-locked to the CANONICAL favourable phase (systole + inspiration),
 * exactly as Zaguskin / the Mustang-2000 "BIO" doctrine requires.
 *
 * Two gate modes:
 *   "envelope" — continuous gain g(t)∈[0,1] (modulate laser/stim amplitude)
 *   "pulse"    — discrete trigger at the PREDICTED next systole (hard gate)
 *
 * The gate is PREDICTIVE: the next R-peak is extrapolated from a smoothed RR,
 * so BLE/transport latency never enters the timing path (see AFE-TRIG spec).
 */
import { analyzeChrono } from "./analyzeChrono";
import { hilbertPhase, bandpassFFT, clamp } from "./dsp";
import { DEFAULT_REFERENCE, DEFAULT_WEIGHTS } from "./chronoIndex";
import { detectBeats } from "./metrics";
import type { ChronoInput, ChronoResult, ChronoReference, ChronoWeights } from "./types";

export type GateMode = "envelope" | "pulse";

export interface ChronoStreamConfig {
  fs: number;                 // sampling rate, Hz
  windowSec?: number;         // analysis window (default 60)
  hopSec?: number;            // recompute period (default 5)
  gateMode?: GateMode;        // default "envelope"
  systoleFrac?: number;       // RR fraction where systole gain peaks (default 0.15)
  gateWidthFrac?: number;     // pulse-mode gate half-width as RR fraction (default 0.04)
  doseFloor?: number;         // min adaptive dose scale (default 0.3)
  doseGain?: number;          // how strongly desync raises dose (default 0.7)
  reference?: Partial<ChronoReference>;
  weights?: Partial<ChronoWeights>;
}

export interface GateOutput {
  tAbs: number;               // absolute time, s
  mode: GateMode;
  gain: number;               // [0,1] instantaneous modulation (envelope mode)
  fire: boolean;              // pulse mode: inside the systole gate window
  nextTriggerTime: number | null; // pulse mode: absolute time of next systole peak
  cardiacPhase: number;       // [0,1) within the current RR
  respPhase: number;          // [0,2π)
  doseScale: number;          // [0,1] adaptive dose from the chrono-index
}

/** Raised-cosine bump: 1 at center, →0 at ±width (circular distance `d`). */
function bump(d: number, width: number): number {
  const a = Math.abs(d);
  return a < width ? 0.5 * (1 + Math.cos((Math.PI * a) / width)) : 0;
}
/** Circular distance on the unit interval [0,1). */
function circDist(a: number, b: number): number {
  let d = ((a - b) % 1 + 1) % 1;
  if (d > 0.5) d -= 1;
  return d;
}

export class ChronoStreamController {
  private cfg: Required<Omit<ChronoStreamConfig, "reference" | "weights">>;
  private ref: ChronoReference;
  private weights: ChronoWeights;

  // ring buffers (bounded to the window)
  private ecg: number[] = [];
  private ppg: number[] = [];
  private resp: number[] = [];
  private beats: number[] = [];      // absolute beat times, s
  private hasEcg = false; private hasPpg = false; private hasResp = false; private hasBeats = false;

  private total = 0;                 // total samples pushed → time base
  private lastAnalysisT = -Infinity;

  // phase model (updated each analyze)
  private meanRR = 0.8;              // s (EMA)
  private lastBeatTime = 0;          // s
  private respFreq = 0.25;           // Hz
  private respPhaseRef = 0;          // rad at respTRef
  private respTRef = 0;              // s
  private doseScale = 0.3;
  private lastResult: ChronoResult | null = null;

  constructor(config: ChronoStreamConfig) {
    this.cfg = {
      fs: config.fs,
      windowSec: config.windowSec ?? 60,
      hopSec: config.hopSec ?? 5,
      gateMode: config.gateMode ?? "envelope",
      systoleFrac: config.systoleFrac ?? 0.15,
      gateWidthFrac: config.gateWidthFrac ?? 0.04,
      doseFloor: config.doseFloor ?? 0.3,
      doseGain: config.doseGain ?? 0.7,
    };
    this.ref = { ...DEFAULT_REFERENCE, ...config.reference };
    this.weights = { ...DEFAULT_WEIGHTS, ...config.weights };
  }

  /** Current stream time (s). */
  get time(): number { return this.total / this.cfg.fs; }
  get result(): ChronoResult | null { return this.lastResult; }

  /**
   * Push a chunk of synchronous samples. `beats` are ABSOLUTE times (s) — pass
   * MAX30001 R-R events here for the precise path; otherwise omit and let the
   * controller detect from ecg/ppg.
   */
  push(chunk: { ecg?: number[]; ppg?: number[]; resp?: number[]; beats?: number[] }): void {
    const n = chunk.ecg?.length ?? chunk.ppg?.length ?? chunk.resp?.length ?? 0;
    if (chunk.ecg) { this.ecg.push(...chunk.ecg); this.hasEcg = true; }
    if (chunk.ppg) { this.ppg.push(...chunk.ppg); this.hasPpg = true; }
    if (chunk.resp) { this.resp.push(...chunk.resp); this.hasResp = true; }
    if (chunk.beats?.length) { this.beats.push(...chunk.beats); this.hasBeats = true; }
    this.total += n;
    this.trim();
  }

  /** Drop samples/beats older than the analysis window. */
  private trim(): void {
    const maxN = Math.round(this.cfg.windowSec * this.cfg.fs);
    const drop = (a: number[]) => { if (a.length > maxN) a.splice(0, a.length - maxN); };
    drop(this.ecg); drop(this.ppg); drop(this.resp);
    const tMin = this.time - this.cfg.windowSec;
    while (this.beats.length && this.beats[0] < tMin) this.beats.shift();
  }

  /**
   * Recompute the chrono-index if a hop has elapsed and enough data exists.
   * Returns the fresh result, or null if it wasn't time / not enough data.
   */
  analyze(): ChronoResult | null {
    if (this.time - this.lastAnalysisT < this.cfg.hopSec) return null;
    const winStart = this.time - this.ecgLen() / this.cfg.fs;

    const input: ChronoInput = {
      fs: this.cfg.fs,
      reference: this.ref,
      weights: this.weights,
    };
    if (this.hasEcg) input.ecg = this.ecg;
    if (this.hasPpg) input.ppg = this.ppg;
    if (this.hasResp) input.resp = this.resp;
    if (this.hasBeats) input.beats = this.beats.map((t) => t - winStart); // window-relative

    let res: ChronoResult;
    try { res = analyzeChrono(input); }
    catch { return null; } // not enough beats yet, etc.

    this.lastAnalysisT = this.time;
    this.lastResult = res;

    // --- update the predictive phase model ---
    const rr = res.periodRatio.meanRR;
    this.meanRR = this.meanRR > 0 ? 0.6 * this.meanRR + 0.4 * rr : rr; // EMA
    // last beat absolute time
    if (this.hasBeats && this.beats.length) this.lastBeatTime = this.beats[this.beats.length - 1];
    else this.lastBeatTime = this.time - (this.time % this.meanRR);
    this.respFreq = res.periodRatio.meanRespT > 0 ? 1 / res.periodRatio.meanRespT : this.respFreq;

    // respiration phase at "now" from a Hilbert on the recent resp window
    if (this.hasResp && this.resp.length > this.cfg.fs * 4) {
      const bp = bandpassFFT(this.resp, this.cfg.fs, 0.1, 0.5);
      const ph = hilbertPhase(bp);
      this.respPhaseRef = ph[ph.length - 1];
      this.respTRef = this.time;
    }

    // adaptive dose from desync (more desync → more corrective assist, capped)
    this.doseScale = clamp(this.cfg.doseFloor + this.cfg.doseGain * (res.chronoIndex / 100));
    return res;
  }

  private ecgLen(): number {
    return (this.hasEcg ? this.ecg.length : this.hasResp ? this.resp.length : this.ppg.length);
  }

  /**
   * Instantaneous gate at absolute time `tAbs` (may be ahead of `now` for
   * predictive scheduling). Cheap — call it at the control-loop rate.
   */
  gate(tAbs: number): GateOutput {
    const cardiacPhase = (((tAbs - this.lastBeatTime) / this.meanRR) % 1 + 1) % 1;
    const respPhase = (((this.respPhaseRef + 2 * Math.PI * this.respFreq * (tAbs - this.respTRef)) % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);

    // favourable phase: systole (cardiac) × inspiration (respiration first half)
    const cardiacGain = bump(circDist(cardiacPhase, this.cfg.systoleFrac), 0.25);
    const respGain = bump((respPhase - Math.PI / 2) / (2 * Math.PI), 0.25); // peak at inspiration mid
    const gain = clamp(cardiacGain * respGain);

    // pulse mode: next systole peak after tAbs
    const kNext = Math.ceil((tAbs - this.lastBeatTime) / this.meanRR);
    const nextR = this.lastBeatTime + kNext * this.meanRR;
    const nextTriggerTime = nextR + this.cfg.systoleFrac * this.meanRR;
    const fire = Math.abs(circDist(cardiacPhase, this.cfg.systoleFrac)) < this.cfg.gateWidthFrac;

    return {
      tAbs, mode: this.cfg.gateMode, gain, fire,
      nextTriggerTime: this.cfg.gateMode === "pulse" ? nextTriggerTime : null,
      cardiacPhase, respPhase, doseScale: this.doseScale,
    };
  }
}
