/**
 * @metacod/engine — module `chrono`
 * analyzeChrono.ts — orchestrates the full pipeline:
 *
 *   raw series → beats → { periodRatio, phaseSync, hrv, flowmotion }
 *              → sub-scores → chrono-index → band → notes
 *
 * Deterministic: same input always yields the same result (doctrine).
 */
import { detectBeats, rrIntervals, periodRatio, phaseSync, hrv, flowmotion } from "./metrics";
import {
  DEFAULT_REFERENCE, DEFAULT_WEIGHTS, subScores, composite, bandOf,
} from "./chronoIndex";
import type { ChronoInput, ChronoResult, ChronoReference, ChronoWeights } from "./types";

export function analyzeChrono(input: ChronoInput): ChronoResult {
  const notes: string[] = [];
  const ref: ChronoReference = { ...DEFAULT_REFERENCE, ...input.reference };
  const weights: ChronoWeights = { ...DEFAULT_WEIGHTS, ...input.weights };

  // --- 1. beats: prefer AFE-provided R-R (MAX30001), else detect ---
  let beats = input.beats;
  if (!beats || beats.length < 8) {
    if (input.ecg) { beats = detectBeats(input.ecg, input.fs, false); notes.push("beats: detected from ECG"); }
    else if (input.ppg) { beats = detectBeats(input.ppg, input.fs, true); notes.push("beats: detected from PPG (less precise)"); }
    else throw new Error("chrono: need beats, or ecg, or ppg to derive pulse");
  } else {
    notes.push("beats: supplied by AFE (precise path)");
  }
  if (beats.length < 8) throw new Error("chrono: too few beats for stable metrics (<8)");

  const rr = rrIntervals(beats);

  // --- 2. respiration is required for the coupling metrics ---
  if (!input.resp) throw new Error("chrono: respiration channel required for coupling metrics");
  const pr = periodRatio(rr, input.resp, input.fs);
  const ps = phaseSync(beats, input.resp, input.fs);

  // --- 3. HRV ---
  const h = hrv(rr);

  // --- 4. flowmotion (optional, needs PPG + long record) ---
  const durationS = beats[beats.length - 1] - beats[0];
  let fm = null as ReturnType<typeof flowmotion> | null;
  if (input.ppg) {
    if (durationS >= 100) fm = flowmotion(input.ppg, input.fs);
    else notes.push("flowmotion: skipped (record <100 s — low bands unreliable)");
  }

  // --- 5. scores + composite ---
  const scores = subScores({ periodRatio: pr, phaseSync: ps, hrv: h, flowmotion: fm, reference: ref });
  const chronoIndex = composite(scores, weights, !!fm);
  const band = bandOf(chronoIndex);

  // --- 6. dominant driver note (which sub-score pushed the index) ---
  const driver = (Object.entries(scores) as [string, number][])
    .sort((a, b) => b[1] - a[1])[0];
  notes.push(`dominant desync driver: ${driver[0]} (${(driver[1] * 100).toFixed(0)}%)`);
  notes.push(`pulse:resp lock ≈ ${pr.k}:1, PLV=${ps.plv.toFixed(2)}`);

  return { periodRatio: pr, phaseSync: ps, hrv: h, flowmotion: fm, subScores: scores, chronoIndex, band, notes };
}
