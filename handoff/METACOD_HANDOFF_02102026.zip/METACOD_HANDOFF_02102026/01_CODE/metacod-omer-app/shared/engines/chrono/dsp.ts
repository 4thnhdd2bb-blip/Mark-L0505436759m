/**
 * @metacod/engine — module `chrono`
 * dsp.ts — self-contained signal processing primitives (NO external deps),
 * so the module runs identically on the server and on-device.
 *
 * Everything here is deterministic and unit-tested via the demo.
 */

/** In-place iterative radix-2 Cooley–Tukey FFT. `re`/`im` length MUST be a power of two. */
export function fft(re: number[], im: number[], inverse = false): void {
  const n = re.length;
  // bit-reversal permutation
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      [re[i], re[j]] = [re[j], re[i]];
      [im[i], im[j]] = [im[j], im[i]];
    }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = ((inverse ? 2 : -2) * Math.PI) / len;
    const wr = Math.cos(ang), wi = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let cr = 1, ci = 0;
      for (let k = 0; k < len / 2; k++) {
        const a = i + k, b = i + k + len / 2;
        const vr = re[b] * cr - im[b] * ci;
        const vi = re[b] * ci + im[b] * cr;
        re[b] = re[a] - vr; im[b] = im[a] - vi;
        re[a] += vr;        im[a] += vi;
        const ncr = cr * wr - ci * wi;
        ci = cr * wi + ci * wr; cr = ncr;
      }
    }
  }
  if (inverse) for (let i = 0; i < n; i++) { re[i] /= n; im[i] /= n; }
}

/** Smallest power of two ≥ n. */
export function nextPow2(n: number): number { let p = 1; while (p < n) p <<= 1; return p; }

/** Remove linear trend (least-squares) — required before FFT/Hilbert. */
export function detrend(x: number[]): number[] {
  const n = x.length;
  let sx = 0, sy = 0, sxx = 0, sxy = 0;
  for (let i = 0; i < n; i++) { sx += i; sy += x[i]; sxx += i * i; sxy += i * x[i]; }
  const d = n * sxx - sx * sx || 1;
  const slope = (n * sxy - sx * sy) / d;
  const intercept = (sy - slope * sx) / n;
  return x.map((v, i) => v - (slope * i + intercept));
}

/**
 * Instantaneous phase via the analytic (Hilbert) signal.
 * φ(t) = atan2(Im{Hilbert(x)}, Re{x}); returns radians, length = x.length.
 */
export function hilbertPhase(x: number[]): number[] {
  const N = nextPow2(x.length);
  const re = new Array(N).fill(0), im = new Array(N).fill(0);
  const xd = detrend(x);
  for (let i = 0; i < xd.length; i++) re[i] = xd[i];
  fft(re, im, false);
  // one-sided spectral doubling → analytic signal
  const h = new Array(N).fill(0);
  h[0] = 1; if (N % 2 === 0) h[N / 2] = 1;
  for (let i = 1; i < N / 2; i++) h[i] = 2;
  for (let i = 0; i < N; i++) { re[i] *= h[i]; im[i] *= h[i]; }
  fft(re, im, true);
  const ph = new Array(x.length);
  for (let i = 0; i < x.length; i++) ph[i] = Math.atan2(im[i], re[i]);
  return ph;
}

/**
 * Zero-phase FFT-domain band-pass. Keeps [f1,f2] Hz, zeroes the rest,
 * inverse-transforms. Zero-phase = no group delay (fine for offline analysis).
 */
export function bandpassFFT(x: number[], fs: number, f1: number, f2: number): number[] {
  const N = nextPow2(x.length);
  const re = new Array(N).fill(0), im = new Array(N).fill(0);
  const xd = detrend(x);
  for (let i = 0; i < xd.length; i++) re[i] = xd[i];
  fft(re, im, false);
  for (let i = 0; i < N; i++) {
    const f = (i <= N / 2 ? i : i - N) * (fs / N); // signed frequency of bin
    const af = Math.abs(f);
    if (af < f1 || af > f2) { re[i] = 0; im[i] = 0; }
  }
  fft(re, im, true);
  return re.slice(0, x.length);
}

/** Band power = variance of the band-passed signal (Parseval-consistent, robust). */
export function bandPower(x: number[], fs: number, f1: number, f2: number): number {
  const b = bandpassFFT(x, fs, f1, f2);
  const mean = b.reduce((a, v) => a + v, 0) / b.length;
  return b.reduce((a, v) => a + (v - mean) ** 2, 0) / b.length;
}

/**
 * Resample an irregular (t,y) series onto a uniform grid at `fsOut` Hz by
 * linear interpolation. Used to turn the RR tachogram into an evenly sampled
 * series for spectral HRV.
 */
export function resampleLinear(t: number[], y: number[], fsOut: number): { grid: number[]; values: number[] } {
  const t0 = t[0], t1 = t[t.length - 1];
  const n = Math.max(2, Math.floor((t1 - t0) * fsOut));
  const grid: number[] = new Array(n), values: number[] = new Array(n);
  let j = 0;
  for (let i = 0; i < n; i++) {
    const tt = t0 + i / fsOut;
    grid[i] = tt;
    while (j < t.length - 2 && t[j + 1] < tt) j++;
    const span = t[j + 1] - t[j] || 1;
    const frac = (tt - t[j]) / span;
    values[i] = y[j] + frac * (y[j + 1] - y[j]);
  }
  return { grid, values };
}

/**
 * One-sided power spectral density via a single Hann-windowed periodogram.
 * Returns { freq[], psd[] } with psd in (unit²/Hz). Adequate for HRV bands.
 */
export function periodogram(x: number[], fs: number): { freq: number[]; psd: number[] } {
  const N = nextPow2(x.length);
  const re = new Array(N).fill(0), im = new Array(N).fill(0);
  const xd = detrend(x);
  // Hann window + coherent-gain normalization
  let winPow = 0;
  for (let i = 0; i < xd.length; i++) {
    const w = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (xd.length - 1));
    re[i] = xd[i] * w; winPow += w * w;
  }
  fft(re, im, false);
  const half = N / 2;
  const freq = new Array(half), psd = new Array(half);
  const norm = 1 / (fs * winPow);
  for (let i = 0; i < half; i++) {
    freq[i] = (i * fs) / N;
    const p = (re[i] * re[i] + im[i] * im[i]) * norm;
    psd[i] = i === 0 ? p : 2 * p; // one-sided
  }
  return { freq, psd };
}

/** Integrate PSD over [f1,f2) Hz (trapezoid) → band power. */
export function integrateBand(freq: number[], psd: number[], f1: number, f2: number): number {
  let s = 0;
  for (let i = 1; i < freq.length; i++) {
    if (freq[i] < f1 || freq[i] > f2) continue;
    s += 0.5 * (psd[i] + psd[i - 1]) * (freq[i] - freq[i - 1]);
  }
  return s;
}

/** Clamp helper. */
export function clamp(v: number, lo = 0, hi = 1): number { return Math.max(lo, Math.min(hi, v)); }
