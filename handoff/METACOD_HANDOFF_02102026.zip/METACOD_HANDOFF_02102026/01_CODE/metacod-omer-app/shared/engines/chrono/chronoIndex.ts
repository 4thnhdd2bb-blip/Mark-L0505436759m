/**
 * @metacod/engine — module `chrono`
 * chronoIndex.ts — combine metrics into ONE desynchronosis index.
 *
 * Every sub-score is in [0,1] where 0 = coherent, 1 = maximally desynchronized.
 * The composite is a transparent weighted mean → mapped to [0,100] and a band.
 * Weights and the reference profile are configurable — CALIBRATE per cohort.
 */
import { clamp } from "./dsp";
import type {
  ChronoReference, ChronoWeights, PeriodRatio, PhaseSync, HRV, Flowmotion,
  DesyncBand,
} from "./types";

/** Literature-plausible defaults. Treat as a starting point, not ground truth. */
export const DEFAULT_REFERENCE: ChronoReference = {
  k: 4,
  kratDevTol: 0.25,       // 25% off the integer lock = full kratnost desync
  plvHealthy: 0.5,        // healthy resting cardiorespiratory coupling
  rmssdHealthy: 30,       // ms — lower bound of a healthy resting range
  logLfhfCenter: 0,       // log(LF/HF)=0 → LF≈HF balance center
  flowmotion: {
    endothelial: 0.22, neurogenic: 0.20, myogenic: 0.20,
    respiratory: 0.18, cardiac: 0.20,
  },
};

export const DEFAULT_WEIGHTS: ChronoWeights = {
  kratnost: 0.25,
  phaseSync: 0.30,   // coupling loss is the earliest desync sign → highest weight
  rsa: 0.15,
  lfhf: 0.15,
  flowmotion: 0.15,
};

/** L1 distance between two flowmotion distributions, normalized to [0,1]. */
function flowmotionDistance(a: Flowmotion, b: Flowmotion): number {
  const keys: (keyof Flowmotion)[] = [
    "endothelial", "neurogenic", "myogenic", "respiratory", "cardiac",
  ];
  const d = keys.reduce((s, k) => s + Math.abs(a[k] - b[k]), 0);
  return clamp(d / 2); // max L1 over two distributions is 2
}

export interface SubScoreInputs {
  periodRatio: PeriodRatio;
  phaseSync: PhaseSync;
  hrv: HRV;
  flowmotion: Flowmotion | null;
  reference: ChronoReference;
}

/** Compute the five sub-scores (each 0..1, higher = worse). */
export function subScores(inp: SubScoreInputs): Record<keyof ChronoWeights, number> {
  const { periodRatio: pr, phaseSync: ps, hrv, flowmotion, reference: ref } = inp;

  // (1) kratnost: deviation from integer lock, saturated at tolerance
  const kratnost = clamp(pr.deviation / ref.kratDevTol);

  // (2) phase sync deficit: 1 − PLV, but only the shortfall below healthy
  const phaseSyncScore = clamp((ref.plvHealthy - ps.plv) / ref.plvHealthy);

  // (3) RSA / vagal deficit: shortfall of RMSSD below healthy (RSA lives in HF/RMSSD)
  const rsa = clamp((ref.rmssdHealthy - hrv.rmssd) / ref.rmssdHealthy);

  // (4) LF/HF imbalance: distance of log(LF/HF) from center, saturated at ~±ln(4)
  const logLfhf = Number.isFinite(hrv.lfhf) ? Math.log(hrv.lfhf) : ref.logLfhfCenter;
  const lfhf = clamp(Math.abs(logLfhf - ref.logLfhfCenter) / Math.log(4));

  // (5) flowmotion distribution distance (0 if no PPG)
  const fm = flowmotion ? flowmotionDistance(flowmotion, ref.flowmotion) : 0;

  return { kratnost, phaseSync: phaseSyncScore, rsa, lfhf, flowmotion: fm };
}

/** Weighted composite → [0,100]. If PPG is absent, flowmotion weight is redistributed. */
export function composite(
  scores: Record<keyof ChronoWeights, number>,
  weights: ChronoWeights,
  hasPPG: boolean,
): number {
  const w: ChronoWeights = { ...weights };
  if (!hasPPG) w.flowmotion = 0; // drop the missing channel; others renormalize below
  const entries = Object.entries(w) as [keyof ChronoWeights, number][];
  const wsum = entries.reduce((a, [, v]) => a + v, 0) || 1;
  const s = entries.reduce((a, [k, v]) => a + v * scores[k], 0) / wsum;
  return Math.round(s * 1000) / 10; // one decimal, 0..100
}

/** Map index → severity band. */
export function bandOf(index: number): DesyncBand {
  if (index < 15) return "coherent";
  if (index < 35) return "mild";
  if (index < 60) return "moderate";
  return "marked";
}
