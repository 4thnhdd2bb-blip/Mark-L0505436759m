/**
 * @metacod/engine — module `chrono`
 * types.ts — public data contracts for chronodiagnostics.
 *
 * Doctrine (Zaguskin): health = coherence of the biorhythm hierarchy;
 * disease begins as desynchronosis (loss of period coupling) BEFORE
 * structural markers move. This module turns raw pulse/respiration/PPG
 * time series into measurable coherence metrics and a single chrono-index.
 *
 * Comments are intentionally verbose so the math is auditable.
 */

/** Which physical channel a waveform represents. */
export type ChannelKind = "ecg" | "ppg" | "resp" | "bioz";

/** Raw synchronous input. All waveforms share the same sampling rate `fs`. */
export interface ChronoInput {
  /** Sampling rate of the raw waveforms, Hz (e.g. 250 for ECG, 50–125 for PPG). */
  fs: number;

  /** Raw ECG samples (optional if `beats` is supplied by the AFE, e.g. MAX30001). */
  ecg?: number[];

  /** Raw PPG samples — used for flowmotion (microcirculation) bands and, if no ECG, for pulse. */
  ppg?: number[];

  /** Respiration waveform — impedance pneumography (MAX30001/ADS1292R), thermistor, or PPG-derived. */
  resp?: number[];

  /**
   * R-peak times in SECONDS. If provided (e.g. MAX30001 on-chip R-R detection),
   * beat detection is skipped and these are used verbatim — the precise path.
   */
  beats?: number[];

  /** Optional override of the healthy reference profile (calibrate per cohort). */
  reference?: Partial<ChronoReference>;

  /** Optional override of chrono-index weights. */
  weights?: Partial<ChronoWeights>;
}

/** Period-ratio (kratnost) result: how close pulse:respiration is to an integer lock. */
export interface PeriodRatio {
  /** Mean RR interval, seconds. */
  meanRR: number;
  /** Mean respiration period, seconds. */
  meanRespT: number;
  /** Raw ratio T_resp / T_rr (≈ beats per breath). */
  ratio: number;
  /** Nearest integer k (canonical lock, ~4–5 in health). */
  k: number;
  /** Normalized deviation from the integer lock: |ratio−k|/k. 0 = perfect kratnost. */
  deviation: number;
}

/** Cardio-respiratory phase synchronization at the dominant n:m ratio. */
export interface PhaseSync {
  /** Beats per breath at the dominant lock (m in the m:1 relation φ_card ≈ m·φ_resp). */
  m: number;
  /** Phase-Locking Value ∈ [0,1]; 1 = perfect locking. Primary coupling strength. */
  plv: number;
  /** Shannon-entropy synchronization index λ ∈ [0,1]; secondary, more conservative. */
  lambda: number;
}

/** Heart-rate variability, time and frequency domain. */
export interface HRV {
  sdnn: number;   // ms — overall variability
  rmssd: number;  // ms — short-term (vagal) variability
  pnn50: number;  // fraction of |ΔRR|>50ms
  vlf: number;    // ms² — 0.003–0.04 Hz
  lf: number;     // ms² — 0.04–0.15 Hz
  hf: number;     // ms² — 0.15–0.40 Hz (respiratory / RSA band)
  lfhf: number;   // LF/HF — sympatho-vagal balance proxy (catabolic↔anabolic)
}

/**
 * Flowmotion (microcirculation) band powers from PPG — Stefanovska bands.
 * This is Zaguskin's rhythm hierarchy resolved inside ONE finger signal.
 * Values are RELATIVE power (sum ≈ 1).
 */
export interface Flowmotion {
  endothelial: number; // ~0.0095–0.021 Hz
  neurogenic: number;  // ~0.021–0.052 Hz
  myogenic: number;    // ~0.052–0.145 Hz
  respiratory: number; // ~0.145–0.6 Hz
  cardiac: number;     // ~0.6–2 Hz
}

/** Healthy reference profile. Defaults are literature-plausible; CALIBRATE on your cohort. */
export interface ChronoReference {
  /** Expected integer pulse:resp lock (kratnost). */
  k: number;
  /** Max tolerated kratnost deviation before it counts as full desync. */
  kratDevTol: number;
  /** Expected minimum healthy PLV. */
  plvHealthy: number;
  /** Expected RMSSD (ms) lower bound of a healthy range. */
  rmssdHealthy: number;
  /** Expected log(LF/HF) center (balance). */
  logLfhfCenter: number;
  /** Expected flowmotion distribution (relative powers, sum≈1). */
  flowmotion: Flowmotion;
}

/** Weights of each sub-score in the composite chrono-index. */
export interface ChronoWeights {
  kratnost: number;
  phaseSync: number;
  rsa: number;
  lfhf: number;
  flowmotion: number;
}

/** Severity band of the chrono-index. */
export type DesyncBand = "coherent" | "mild" | "moderate" | "marked";

/** Full chronodiagnostic result. */
export interface ChronoResult {
  periodRatio: PeriodRatio;
  phaseSync: PhaseSync;
  hrv: HRV;
  flowmotion: Flowmotion | null; // null if no PPG supplied
  /** Transparent sub-scores in [0,1] (higher = more desynchronosis). */
  subScores: Record<keyof ChronoWeights, number>;
  /** Composite chrono-index in [0,100] (0 = coherent, 100 = marked desync). */
  chronoIndex: number;
  /** Categorical severity. */
  band: DesyncBand;
  /** Human-readable notes (data quality, dominant driver, etc.). */
  notes: string[];
}
