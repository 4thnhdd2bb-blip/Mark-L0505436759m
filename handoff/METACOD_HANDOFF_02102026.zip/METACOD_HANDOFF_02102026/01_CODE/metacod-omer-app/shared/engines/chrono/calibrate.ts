/**
 * @metacod/engine — module `chrono`
 * calibrate.ts — fit the healthy REFERENCE profile from a cohort of recordings.
 *
 * The chrono-index thresholds (rmssdHealthy, logLfhfCenter, flowmotion shape,
 * kratDevTol, plvHealthy) are cohort-dependent. Feed a set of recordings that
 * represent YOUR reference population and this produces a calibrated
 * `ChronoReference` (plus a transparent report of the distributions used).
 */
import { detectBeats, rrIntervals, periodRatio, phaseSync, hrv, flowmotion } from "./metrics";
import { DEFAULT_REFERENCE } from "./chronoIndex";
import type { ChronoInput, ChronoReference, Flowmotion } from "./types";

/** Percentile (0..1) of a numeric array via linear interpolation. */
function pct(xs: number[], p: number): number {
  if (!xs.length) return NaN;
  const s = [...xs].sort((a, b) => a - b);
  const idx = clampIdx(p * (s.length - 1), 0, s.length - 1);
  const lo = Math.floor(idx), hi = Math.ceil(idx);
  return s[lo] + (idx - lo) * (s[hi] - s[lo]);
}
function median(xs: number[]): number { return pct(xs, 0.5); }
function mean(xs: number[]): number { return xs.reduce((a, v) => a + v, 0) / (xs.length || 1); }
function clampIdx(v: number, lo: number, hi: number): number { return Math.max(lo, Math.min(hi, v)); }
function mode(xs: number[]): number {
  const c = new Map<number, number>();
  for (const x of xs) c.set(x, (c.get(x) ?? 0) + 1);
  return [...c.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? NaN;
}

export interface CalibrationReport {
  n: number;                 // recordings used
  reference: ChronoReference;
  distributions: {
    kratDev: { p50: number; p90: number; p95: number };
    plv: { p10: number; p25: number; p50: number };
    rmssd: { p10: number; p25: number; p50: number };
    logLfhf: { p25: number; p50: number; p75: number };
    kMode: number;
  };
  notes: string[];
}

/**
 * Calibrate from healthy/reference recordings.
 * Rules (transparent, tweak to taste):
 *   k            = modal integer lock across the cohort
 *   kratDevTol   = 95th-percentile kratnost deviation among healthy (tolerance)
 *   plvHealthy   = 25th-percentile PLV (lower bound of healthy coupling)
 *   rmssdHealthy = 25th-percentile RMSSD (lower bound of healthy range)
 *   logLfhfCtr   = median log(LF/HF)
 *   flowmotion   = mean healthy band distribution
 */
export function calibrateReference(
  recordings: ChronoInput[],
  opts?: { minBeats?: number },
): CalibrationReport {
  const minBeats = opts?.minBeats ?? 20;
  const kratDev: number[] = [], plv: number[] = [], rmssd: number[] = [];
  const logLfhf: number[] = [], ks: number[] = [];
  const fmAcc: Flowmotion = { endothelial: 0, neurogenic: 0, myogenic: 0, respiratory: 0, cardiac: 0 };
  let fmN = 0, used = 0;
  const notes: string[] = [];

  for (const rec of recordings) {
    let beats = rec.beats;
    if (!beats || beats.length < minBeats) {
      if (rec.ecg) beats = detectBeats(rec.ecg, rec.fs, false);
      else if (rec.ppg) beats = detectBeats(rec.ppg, rec.fs, true);
    }
    if (!beats || beats.length < minBeats || !rec.resp) { notes.push("skipped a recording (insufficient beats/resp)"); continue; }

    const rr = rrIntervals(beats);
    const pr = periodRatio(rr, rec.resp, rec.fs);
    const ps = phaseSync(beats, rec.resp, rec.fs);
    const h = hrv(rr);

    kratDev.push(pr.deviation); plv.push(ps.plv); rmssd.push(h.rmssd); ks.push(pr.k);
    if (Number.isFinite(h.lfhf) && h.lfhf > 0) logLfhf.push(Math.log(h.lfhf));

    if (rec.ppg && (beats[beats.length - 1] - beats[0]) >= 100) {
      const fm = flowmotion(rec.ppg, rec.fs);
      (Object.keys(fmAcc) as (keyof Flowmotion)[]).forEach((k) => (fmAcc[k] += fm[k]));
      fmN++;
    }
    used++;
  }

  if (!used) throw new Error("calibrate: no usable recordings");

  const flowmotionRef: Flowmotion = fmN
    ? (Object.fromEntries((Object.keys(fmAcc) as (keyof Flowmotion)[]).map((k) => [k, fmAcc[k] / fmN])) as unknown as Flowmotion)
    : DEFAULT_REFERENCE.flowmotion;

  const reference: ChronoReference = {
    k: Math.round(mode(ks)) || DEFAULT_REFERENCE.k,
    kratDevTol: Math.max(0.05, pct(kratDev, 0.95)),
    plvHealthy: clamp01(pct(plv, 0.25)),
    rmssdHealthy: Math.max(5, pct(rmssd, 0.25)),
    logLfhfCenter: logLfhf.length ? median(logLfhf) : DEFAULT_REFERENCE.logLfhfCenter,
    flowmotion: flowmotionRef,
  };

  notes.push(`calibrated on ${used} recordings (${fmN} with usable PPG)`);

  return {
    n: used,
    reference,
    distributions: {
      kratDev: { p50: median(kratDev), p90: pct(kratDev, 0.9), p95: pct(kratDev, 0.95) },
      plv: { p10: pct(plv, 0.1), p25: pct(plv, 0.25), p50: median(plv) },
      rmssd: { p10: pct(rmssd, 0.1), p25: pct(rmssd, 0.25), p50: median(rmssd) },
      logLfhf: { p25: pct(logLfhf, 0.25), p50: median(logLfhf), p75: pct(logLfhf, 0.75) },
      kMode: Math.round(mode(ks)),
    },
    notes,
  };
}

function clamp01(v: number): number { return Math.max(0, Math.min(1, v)); }

/** Serialize a calibrated reference for storage / config. */
export function referenceToJSON(ref: ChronoReference): string {
  return JSON.stringify(ref, null, 2);
}
