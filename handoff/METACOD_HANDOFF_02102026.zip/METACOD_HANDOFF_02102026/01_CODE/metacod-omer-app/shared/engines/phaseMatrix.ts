// METACOD-Omer · shared/engines/phaseMatrix.ts
// ⭐ Физиологическая фазовая матрица: фаза принадлежит ПРОЦЕССУ, не пациенту.
// Между предполагаемой фазой и препаратом — измеряемый физиологический уровень.
// Движок даёт математику (ведущий процесс, системный вектор, детектор конфликтов,
// уровни ответа, SBI); саму матрицу заполняет модель по данным пациента.

import type {
  ProcessRow, OrganState, DrugVector, TherapeuticConflict, PhaseMatrix,
} from '../types';

/** Стоп-состояния (Safety Gate уровня 3) — не «побочка для компенсации». */
export const SAFETY_GATES: string[] = [
  'неукротимая рвота', 'сильная абдоминальная боль', 'подозрение на кишечную обструкцию',
  'панкреатит', 'значимая дегидратация/ОПП', 'желудочно-кишечное кровотечение',
  'нарушение сознания', 'гемодинамическая нестабильность',
];

/** Вес процесса = активность × (1 + вес риска). Чем выше — тем ведущее. */
export function scoreProcess(p: ProcessRow): number {
  const riskW = Math.min(2, (p.risk?.length ?? 0)) * 0.75;
  return p.activity * (1 + riskW);
}

/** Ведущий процесс = максимум активность×риск. */
export function leadingProcess(processes: ProcessRow[]): ProcessRow | null {
  if (!processes.length) return null;
  return processes.reduce((a, b) => (scoreProcess(b) > scoreProcess(a) ? b : a));
}

/** Нормализованные «направления патологии» процесса — из измеряемого состояния. */
export function pathologyDirections(s: OrganState): string[] {
  const d: string[] = [];
  if (s.motility === 'low') d.push('моторика↓');
  if (s.motility === 'high') d.push('моторика↑');
  if (s.fluid === 'low') d.push('дегидратация');
  if (s.fluid === 'high') d.push('отёк');
  if (s.metabolism === 'catabolic') d.push('катаболизм');
  if (s.perfusion === 'low') d.push('перфузия↓');
  if (s.inflammation !== 'none') d.push('воспаление');
  if (s.organFunction === 'low') d.push('гипофункция');
  if (s.cellDamage === 'structural') d.push('структурное повреждение');
  return d;
}

const ROOTS: Record<string, string> = {
  'моторика↓': 'мотор', 'моторика↑': 'мотор', 'дегидратация': 'дегидрат', 'отёк': 'отёк',
  'катаболизм': 'катаболизм', 'перфузия↓': 'перфуз', 'воспаление': 'воспал',
  'гипофункция': 'гипофункц', 'структурное повреждение': 'структур',
};

/** Совпадает ли побочный вектор препарата с направлением патологии процесса. */
function drugAggravates(dir: string, drug: DrugVector): boolean {
  const root = ROOTS[dir] ?? dir.toLowerCase();
  return (drug.side ?? []).some((s) => s.toLowerCase().includes(root));
}

/** Уровень ответа: 3 если есть стоп-состояние среди рисков; 2 если активность/риск значимы; иначе 1. */
export function classifyLevel(p: ProcessRow): 1 | 2 | 3 {
  const hitsGate = (p.risk ?? []).some((r) => SAFETY_GATES.some((g) => r.toLowerCase().includes(g.split('/')[0].split(' ')[0].toLowerCase())));
  if (hitsGate) return 3;
  if (p.activity >= 2 || (p.risk?.length ?? 0) > 0) return 2;
  return 1;
}

const LEVEL_RESPONSE: Record<1 | 2 | 3, string> = {
  1: 'продолжить + наблюдать',
  2: 'скорректировать дозу/титрацию + компенсатор побочного эффекта + усилить мониторинг',
  3: 'SAFETY GATE: удержать/снизить/отменить препарат по клиническим рекомендациям и тяжести',
};

/** Детектор терапевтических конфликтов: побочный вектор препарата ∥ направление патологии. */
export function detectConflicts(processes: ProcessRow[], drugs: DrugVector[]): TherapeuticConflict[] {
  const out: TherapeuticConflict[] = [];
  for (const p of processes) {
    const dirs = pathologyDirections(p.state);
    for (const drug of drugs) {
      for (const dir of dirs) {
        if (drugAggravates(dir, drug)) {
          const level = classifyLevel(p);
          out.push({
            process: p.process, drug: drug.name, direction: dir, level,
            response: LEVEL_RESPONSE[level],
            safetyGate: level === 3 ? SAFETY_GATES : undefined,
          });
        }
      }
    }
  }
  return out;
}

/** Системный результирующий вектор (текст) + движущие процессы (вес = активность×риск×|влияние|). */
export function systemicIntegral(processes: ProcessRow[]): { vector: string; drivers: string[] } {
  const weighted = processes
    .map((p) => ({ p, w: scoreProcess(p) * Math.abs(p.systemicInfluence) }))
    .filter((x) => x.w > 0)
    .sort((a, b) => b.w - a.w);
  const pull = processes.reduce((s, p) => s + p.systemicInfluence * scoreProcess(p), 0);
  const dir = pull < 0 ? 'дестабилизация/истощение (гиповолемия · катаболизм · стаз)'
    : pull > 0 ? 'поддержка/анаболизм' : 'нейтральный баланс';
  return { vector: dir, drivers: weighted.slice(0, 3).map((x) => x.p.process) };
}

/** SBI процесса = интенсивность × длительность × частота рецидивов × (1 − полнота восстановления). */
export function processSBI(
  p: ProcessRow,
  opts: { durationWeeks?: number; recurrences?: number; recovery?: number } = {},
): number {
  const inflW = p.state.inflammation === 'systemic' ? 1.5 : p.state.inflammation === 'local' ? 1.2 : 1;
  const intensity = p.activity * inflW;                 // 0..~4.5
  const duration = Math.max(0.5, opts.durationWeeks ?? 1);
  const recur = 1 + 0.5 * (opts.recurrences ?? 0);
  const recovery = Math.min(1, Math.max(0, opts.recovery ?? 0)); // 0..1
  return +(intensity * duration * recur * (1 - recovery)).toFixed(2);
}

export function systemicSBI(processes: ProcessRow[]): number {
  return +processes.reduce((s, p) => s + (p.sbi ?? processSBI(p)), 0).toFixed(2);
}

/** Собрать матрицу: ведущий процесс + системный вектор + конфликты + план + суммарный SBI. */
export function assembleMatrix(processes: ProcessRow[], drugs: DrugVector[] = []): PhaseMatrix {
  const active = processes.filter((p) => p.activity >= 1).slice(0, 6);
  const lead = leadingProcess(active);
  const integral = systemicIntegral(active);
  const conflicts = detectConflicts(active, drugs);
  const local = active
    .filter((p) => p.activity >= 2)
    .map((p) => `${p.organ}: ${p.target} (${p.vector}); избегать: ${p.antiVector}`);
  return {
    processes: active.map((p) => ({ ...p, sbi: p.sbi ?? processSBI(p) })),
    systemicVector: integral.vector,
    leadingProcess: lead?.process ?? '—',
    conflicts,
    plan: {
      systemic: `Стабилизация (нейтральная поддержка, не «толкать» ни в одну сторону); драйверы: ${integral.drivers.join(', ') || '—'}`,
      local,
    },
    systemicSBI: systemicSBI(active),
  };
}
