// METACOD-Omer · shared/engines/report.ts
// Сборка заключения по ЭТАЛОННОМУ СТАНДАРТУ (5 частей) + страж на конвенциональный слой.

import type { AnalysisResult, Hypothesis, WorkupPlan } from '../types';
import { guardConventional } from './guard';
import { LABELS, applyMarket, type Lang } from './releaseLayer';

export interface ConclusionInput {
  logic: string;
  hypotheses: Hypothesis[];
  cannotMiss: string[];
  workup: WorkupPlan;
  redFlags: string[];
  summary: string;
}

/** Собрать конвенциональный вывод и прогнать через страж (grep стоп-слов = 0). */
export function buildConventional(input: ConclusionInput): AnalysisResult['conventional'] {
  const guard = guardConventional(input);
  return { ...input, guardClean: guard.clean };
}

/**
 * Рендер в Markdown (наружу).
 * @param lang язык подачи (§Е Мастер-Стандарта v4). По умолчанию 'ru' —
 *             вывод байт-в-байт как раньше (обратная совместимость).
 *             'en' — рыночная подача (без бренда/бейджа/validated:false, 0 кириллицы);
 *             'he' — RTL, бренд+validated:false, локация «תל אביב, ישראל».
 */
export function renderMarkdown(c: AnalysisResult['conventional'], lang: Lang = 'ru'): string {
  const T = LABELS[lang] ?? LABELS.ru;
  const L: string[] = [];
  L.push(T.title);
  L.push(T.s1 + c.logic + '\n');
  L.push(T.s2);
  for (const h of c.hypotheses) L.push(`**${h.rank}. ${h.root}**${T.hypExplains}${h.explains}${T.hypConfirm}${h.confirm.join(', ')}.`);
  L.push(T.cannotMiss + c.cannotMiss.join('; ') + '\n');
  L.push(T.s3);
  L.push(T.step1 + c.workup.step1_history.join('; '));
  L.push(T.step2 + c.workup.step2_labs.join('; '));
  L.push(T.step3 + c.workup.step3_imaging.join('; '));
  L.push(T.step4 + c.workup.step4_referrals.join('; ') + '\n');
  L.push(T.s4 + c.redFlags.map((r) => '• ' + r).join('\n') + '\n');
  L.push(T.s5 + c.summary);
  if (T.footer) L.push(T.footer);
  // §Е3: рыночная подача (EN — вычистить остатки бренда METACOD/validated:false из тела)
  return applyMarket(L.join('\n'), lang);
}
