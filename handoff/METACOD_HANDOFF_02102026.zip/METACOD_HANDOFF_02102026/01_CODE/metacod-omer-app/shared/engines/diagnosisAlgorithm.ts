// METACOD-Omer · shared/engines/diagnosisAlgorithm.ts
// СЛОЙ АЛГОРИТМА ДИАГНОЗА — объединяет все Excel-таблицы (Gel-Zol мембраны + Общая таблица
// лечения + база 658 + фазовые переходы) с архитектурой кабинета в ОДНУ трассируемую цепочку.
//
// Порядок: первичное → вторичное.
//   Жалоба → МЕМБРАНА (направление, безопасность) → ЭНЕРГИЯ (мишень) → ФАЗА (момент)
//          → ЛЕКАРСТВА (658 + JCZ) → EBM/подпись.
// Мантра: «направление раньше мишени · мембрана раньше лекарства · кровь раньше дозы».
//
// Слой ВНУТРЕННИЙ (L1): отдаётся только проф. Литваку, наружу не выходит (страж).
// validated:false · препараты/классы — векторы, не дозы · дозы/красные флаги/финал — за врачом.

import type {
  PatientInput, Energy, Membrane, SolGel,
  DiagnosisTrace, DiagnosisStep, TreatmentRow, JczPick, ControlPointStatus, SubstitutionNote,
} from '../types';
import { solGelOfMembrane, treatmentVector } from './solGel';
import { assessTransition } from './phaseTransition';
import { supplementPlan, libraryFor } from './membraneLibrary';
import { assessCompartments } from './compartments';
import canon from '../data/diagnosis_algorithm_canon.json';
import index658 from '../data/drug_index_658.json';
import { внеПодбора } from './gelSolClasses';

// ── типы данных канона (узкие, локальные) ───────────────────────────
interface CanonTreatmentRow {
  energy: string; organ: string; membrane: string; phase: string; vector: string;
  magnet: string; color: string; drugs658: string; jcz: string; hardStop: string;
}
interface Drug658 { n: string; mnn: string; cls: string; atc: string; fda: string; q: string[]; shift: string; ind: string; dose: string; }

const TREATMENT = (canon as any)['общая_таблица_лечения'] as CanonTreatmentRow[];
const HARD_STOP = (canon as any)['hard_stop'] as string[];
const COLOR = (canon as any)['цвет_энергии'] as Record<string, string>;
const DB658 = ((index658 as any)['препараты'] ?? []) as Drug658[];

/** Осушающие препараты — искусственно «сушат/охлаждают» периферию (точка инверсии истинной мембраны). */
const DRYING = /SGLT-?2|дапаглифлозин|эмпаглифлозин|канаглифлозин|петлев|фуросемид|торасемид|энтресто|entresto|сакубитрил/i;
/** Классы, запрещённые в глубоком катаболизме (M-D2). */
const BANNED_IN_MD2 = /метформин|берберин|SGLT-?2|глифлозин|GLP-?1|лираглутид|дулаглутид|семаглутид|NAC|ацетилцистеин/i;

// ── направление лечения из мембраны (гель/золь → катаболик/анаболик/антифиброз) ──
export function directionOfMembrane(m: Membrane): { direction: string; sol: SolGel; note: string } {
  const sol = solGelOfMembrane(m);
  if (m === 'M-S') return { direction: 'антифиброз', sol, note: 'структурный гель → размягчить + стоп-пролиферация (3 столпа)' };
  const v = treatmentVector(m);
  if (m.startsWith('M-D')) return { direction: 'анаболик', sol, note: v.note };
  if (m.startsWith('M-A')) return { direction: 'контролируемый катаболик', sol, note: v.note };
  return { direction: 'баланс', sol, note: v.note };
}

// ── фильтр 658: «гасит: [энергия]» ──────────────────────────────────
/**
 * ⚠ ДЕФЕКТ, найденный на разборе 74ж: выдача шла в ФАЙЛОВОМ порядке, а файл отсортирован
 * по алфавиту. Для энергии Холод первыми выходили варфарин, андексанет альфа и альфузосин,
 * а левотироксин — где-то в середине. Фильтр по энергии сам по себе НЕ является подборщиком:
 * у него нет клинического контекста.
 *
 * Порядок теперь задают три вещи, в порядке убывания веса:
 *   1) препараты, НАЗВАННЫЕ в подобранной строке Общей таблицы (`prefer`) — это курированный
 *      клинический ответ для этой энергии, он сильнее сырого фильтра;
 *   2) совпадение с картиной пациента (`hint`) по названию, классу и показанию;
 *   3) понижение узкоспециальных классов (антидоты, хелаторы, ферментозамещение, инотропы,
 *      орфанные siRNA) — они гасят ту же энергию, но к амбулаторному разбору отношения не имеют;
 *      понижение снимается, если класс совпал с картиной.
 * Ничьи разрешаются по алфавиту — выдача остаётся воспроизводимой.
 */
export interface Quench658Opts { limit?: number; hint?: string; prefer?: string }

const NARROW_CLASS =
  /antidote|antitoxin|reversal|chelator|chelat|хелат|антидот|антитоксин|enzyme replacement|ферментозамещ|siRNA|инотроп|vasopressor|вазопрессор|radiopharm|антивеном|immune fab|Fab\b|stabilizer|HDAC|porphyria|Pompe|specialty/i;

function norm(s: unknown): string { return String(s ?? '').toLowerCase(); }

export function quench658(energy: Energy, limitOrOpts: number | Quench658Opts = 12): Drug658[] {
  const o: Quench658Opts = typeof limitOrOpts === 'number' ? { limit: limitOrOpts } : limitOrOpts;
  const limit = o.limit ?? 12;
  const hint = norm(o.hint);
  const prefer = norm(o.prefer);

  // ⛔⛔⛔ 22.09.2026, вечер. ЭТОТ ПУТЬ ШЁЛ МИМО ГРАНИЦЫ ПОДБОРА.
  // Утром граница «полоса 4 не подбирается» была поставлена в drugSelect.ts
  // и объявлена перенесённой. Здесь идёт ВТОРОЙ путь — по индексу 658, по
  // полю q, — и он её не знал: quench658('Ветер') возвращал 17 позиций
  // онкологии и системной иммуносупрессии из 40, включая CAR-T
  // (аксикабтаген), 5-фторурацил и алектиниб. Измерено прогоном.
  // ⛔ Исключённое не пропадает молча — см. quench658ЗаСпециалистом().
  const hits = DB658.filter((d) => Array.isArray(d.q) && d.q.includes(energy)
    && !внеПодбора((d as any).atc, d.cls, d.n));
  // слова длиной >4 — чтобы «при», «для», «его» не давали ложных совпадений
  const words = (src: string) => src.split(/[^a-zа-яё0-9-]+/i).filter((w) => w.length > 4);
  const hintWords = words(hint);
  const preferWords = words(prefer);

  const score = (d: Drug658): number => {
    const text = norm(`${d.n} ${(d as any).mnn} ${d.cls} ${(d as any).ind}`);
    let s = 0;
    if (preferWords.some((w) => text.includes(w))) s += 100;   // назван в строке Общей таблицы
    if (hintWords.some((w) => text.includes(w))) s += 25;      // совпал с картиной пациента
    const narrow = NARROW_CLASS.test(`${d.cls} ${(d as any).ind}`);
    if (narrow && s === 0) s -= 40;                            // узкоспециальный и ни с чем не совпал
    s += curationBonus(energy, d.n);                           // v3.8: курация врача по механизму
    return s;
  };

  return hits
    .map((d) => ({ d, s: score(d) }))
    .sort((a, b) => b.s - a.s || a.d.n.localeCompare(b.d.n, 'ru'))
    .slice(0, limit)
    .map((x) => x.d);
}
/**
 * ⛔ Что подбор по индексу 658 НЕ вернул по этой энергии и почему.
 * Не для назначения: ось описывает вещество и ничего не разрешает.
 */
export function quench658ЗаСпециалистом(energy: Energy): Array<Drug658 & { стоп: string }> {
  return DB658
    .filter((d) => Array.isArray(d.q) && d.q.includes(energy)
      && внеПодбора((d as any).atc, d.cls, d.n))
    .map((d) => ({
      ...d,
      стоп: 'назначение за онкологом, ревматологом или центром; ось описывает '
        + 'вещество и НЕ разрешает применение',
    }));
}

export const DRUGBASE_658_COUNT = DB658.length;

/* ── КУРАЦИЯ БЛОКА ПО ПРИНЦИПУ ДЕЙСТВИЯ (канон v3.8) ─────────────────────
 * Задание врача 16.09.2026: «искать по принципу действия и эффекту».
 * 55 позиций «гасит Холод» лежали одним списком — тиреоидные гормоны рядом с
 * варфарином, антидотами и хелаторами, и алфавитная верхушка давала мусор.
 * Теперь порядок задаёт МЕХАНИЗМ: ядро термогенеза → кислородная ёмкость →
 * перфузия (реанимация) → формальные → ⛔ опасные в этом блоке.
 * Курация лежит в каноне, а не в коде: врач правит её без пересборки.
 */
const CURATION = ((canon as any)['курация_блока_холод'] ?? {}) as Record<string, any>;
const CURATION_GROUPS = ((CURATION['группы'] ?? []) as Array<Record<string, string>>);
// ⚠ Вес группы 1 выше штрафа за «узкий класс» (−40) намеренно: МСТ и специальные смеси
// помечены в базе как specialty и без этого падали ниже группы 2, хотя врач отнёс их к ядру.
const CURATION_WEIGHT = [100, 30, -10, -60, -120];   // по порядку групп канона

/**
 * Сверка имени с курированным списком. Имена в базе и в каноне пишутся по-разному —
 * «Витамин B12 (метилкобаламин)» против «Витамин B12 метилкобаламин», «Кетоновый эфир (BHB)»
 * против «Кетоновый эфир BHB». Поэтому сравниваются НОРМАЛИЗОВАННЫЕ ключи без скобок и
 * пунктуации, по совпадению начала: иначе курация тихо не срабатывает на трети позиций,
 * и это было бы неотличимо от «врач их не включил».
 */
function ключ(x: string): string {
  return norm(x).replace(/[()«»,.:;]/g, ' ').replace(/\s+/g, ' ').trim();
}

function curationBonus(energy: Energy, name: string): number {
  if ((energy as string) !== 'Холод') return 0;
  const n = ключ(name);
  for (let i = 0; i < CURATION_GROUPS.length; i++) {
    const позиции = String(CURATION_GROUPS[i]['позиции'] ?? '').split(/\s*·\s*/);
    if (позиции.some((x) => {
      const k = ключ(x);
      if (k.length < 4) return false;
      const короткий = k.length <= n.length ? k : n;
      const длинный = k.length <= n.length ? n : k;
      return длинный.startsWith(короткий.slice(0, Math.min(короткий.length, 14)));
    })) return CURATION_WEIGHT[i] ?? 0;
  }
  return 0;
}

export const COLD_CURATION = CURATION;
export const COLD_CURATION_RULE: string = String(CURATION['правило_выбора'] ?? '');
export const PROTOCOL_SUPPLEMENT_CARDS =
  (((canon as any)['карточки_добавок_протокола'] ?? {})['карточки'] ?? []) as Array<Record<string, string>>;

// ── клинические под-типы строк (для дивергентных энергий) ───────────
// ключ = слово из подписи строки Общей таблицы · значение = что ищем в жалобе/картине
const SUBTYPE_KEYS: Array<[RegExp, RegExp]> = [
  [/деление|онко|пролиф/i, /онко|пролифер|опухол|(?<![а-яёa-z])рак(?![а-яёa-z])|полицит|jak2|эритроцит|миелопро|деление|ki-?67/i],
  [/нервы|аритмия|спазм/i, /аритми|спазм|тремор|вегетат|нейропат|(?<![а-яёa-z])нерв/i],
  [/клиренс|лимф|жёлч/i, /лимф|жёлч|желчег|клиренс|холестаз/i],
  [/обмен|метс|сд2|ожирение/i, /ожирен|мет[сc](?![а-яёa-z])|метаболич.*синдр|сд ?2|диабет|инсулинорез|(?<![а-яёa-z])ир(?![а-яёa-z])|стеатоз|hba1c|глюкоз|сладк/i],
  [/вода|отёк|хсн|нефроз/i, /отёк|отек|(?<![а-яёa-z])хсн(?![а-яёa-z])|нефроз|асцит|задержк.*жидк|перегруз.*объ/i],
  [/воспаление|инфекция/i, /воспал|инфекц|(?<![а-яёa-z])остр|лихорад|срб|соэ/i],
  [/фиброз|склероз/i, /фиброз|склероз|\bipf\b|цирроз|жёстк|минерализ|кальциноз|гиперпаратире|птг/i],
  [/атрофия|аутоиммун/i, /атроф|аутоиммун|сикка|шёгрен|иммуномод/i],
  [/застой|гипотиреоз|хбп|ишемия/i, /гипотиреоз|(?<![а-яёa-z])хбп(?![а-яёa-z])|ишем|застой|брадикард|зябк|мёрзн|мерзн|гипофункц/i],
  [/кахексия|саркопения/i, /кахекси|саркопен|потер[а-яё]*\s*вес|истощ|похудани|фаз[а-яё]*\s*угол|бцм|bcm/i],
];

/**
 * Подбор строки Общей таблицы лечения.
 * Порядок веса: (1) клинический под-тип из жалобы/картины (hint), (2) точный подтип мембраны в строке,
 * (3) тяжесть (M-D2/3 ↔ тяжёлые строки), (4) полюс золь/гель (тайбрейк).
 * Это устраняет промах «ожирение→отёк» и «гипотиреоз-застой→кахексия».
 */
export function matchTreatmentRow(energy: Energy, membrane?: Membrane, hint = ''): CanonTreatmentRow | undefined {
  // ПОДТВЕРЖДЁННЫЙ глубокий катаболизм (M-D2/M-D3): безопасный вектор — ВСЕГДА
  // анаболик/нутритивно, независимо от энергии-ярлыка (катаболик/диуретик там запрещён).
  // Энергия по-прежнему называет орган-мишень (шаг 2), но лекарственный вектор берём из мембраны.
  if (membrane === 'M-D2' || membrane === 'M-D3') {
    const safe = TREATMENT.find((r) => /кахекси|саркопен/i.test(r.energy) && /M-D2/.test(r.membrane));
    if (safe) return safe;
  }
  const byEnergy = TREATMENT.filter((r) => r.energy.startsWith(energy));
  if (byEnergy.length === 0) return undefined;
  if (byEnergy.length === 1) return byEnergy[0];
  const mem = membrane ?? 'M-0';
  const h = (hint + ' ' + mem).toLowerCase();
  const wantSol = mem === 'M-0' ? 'баланс' : solGelOfMembrane(mem);
  const severeMem = /M-D2|M-D3/.test(mem);
  const scored = byEnergy.map((r) => {
    const label = (r.energy + ' ' + r.membrane + ' ' + r.vector).toLowerCase();
    let s = 0;
    // (1) клинический под-тип: строка описывает под-тип, который виден в картине
    for (const [rowKey, hintRe] of SUBTYPE_KEYS) {
      if (rowKey.test(r.energy) && hintRe.test(h)) { s += 4; break; }
    }
    // (2) точный подтип мембраны прямо в строке (M-A2 / M-D2 / M-S …)
    if (mem !== 'M-0' && label.includes(mem.toLowerCase())) s += 5;
    // (3) тяжесть: тяжёлая мембрана ↔ тяжёлая строка
    const severeRow = /кахекси|саркопен|вода|отёк/.test(label);
    if (severeMem && severeRow) s += 2;
    if (!severeMem && !severeRow) s += 1;
    // (4) полюс (тайбрейк)
    const rowSol = /золь|m-d/.test(label) ? 'золь' : /гель|m-a|m-s/.test(label) ? 'гель' : 'баланс';
    if (wantSol !== 'баланс' && rowSol === wantSol) s += 1;
    return { r, s };
  }).sort((a, b) => b.s - a.s);
  return scored[0].r;
}

// ── JCZ-лестница из строки таблицы ("Государь: X · Министр: Y · …") ──
export function parseJcz(jcz: string): JczPick[] {
  if (!jcz) return [];
  return jcz.split('·').map((part) => {
    const m = part.split(':');
    const role = (m[0] ?? '').trim();
    const item = (m.slice(1).join(':') ?? '').trim();
    return { role: role as JczPick['role'], item };
  }).filter((x) => x.role && x.item);
}

// ── HARD-STOP: проверка запретов текущей ситуации ───────────────────
const clean = (s: string) => s.replace(/^[⛔\s]+/, '').trim();

export function checkHardStops(membrane: Membrane, row: CanonTreatmentRow | undefined, currentDrugs: string[]): string[] {
  const fired: string[] = [];
  // Жёсткий запрет катаболиков — ТОЛЬКО при подтверждённом глубоком катаболизме (M-D2/M-D3),
  // не при лёгком M-D1 (там осторожность идёт через контрольную точку «истинная мембрана»).
  if (membrane === 'M-D2' || membrane === 'M-D3') {
    fired.push(`${membrane} (глубокий катаболизм): метформин/берберин/SGLT-2/GLP-1/NAC ЗАПРЕЩЕНЫ — только анаболизм/нутритивно; цель закрывать ЗАМЕНОЙ (§2J.1), не вычёркивать`);
    const bad = (currentDrugs ?? []).filter((d) => BANNED_IN_MD2.test(d));
    if (bad.length) fired.push('в текущей терапии запрещённое при ' + membrane + ': ' + bad.join(', '));
  }
  if (row && row.hardStop && row.hardStop !== '—') fired.push(clean(row.hardStop));
  return Array.from(new Set(fired.map(clean))).filter(Boolean);
}

// ── §2J.1 ЗАМЕНЫ ПРИ ЗАПРЕТЕ: запрет не отменяет цель ───────────────
// Канон: если нужный ход попал под HARD-STOP — цель закрывается ЗАМЕНОЙ,
// а не вычёркивается. Таблица — из canon['замены_при_запрете'].
const SUBS = ((canon as any)['замены_при_запрете'] ?? []) as Array<Record<string, string>>;
const ANTICOAG = /апиксабан|ривароксабан|дабигатран|варфарин|эноксапарин|клексан|эликвис|ксарелто/i;

type SubGate = 'M-D' | 'антикоагулянт' | 'лаборатория';
const SUB_MATCH: Array<{ drug: RegExp; key: RegExp; gate: SubGate }> = [
  { drug: /\bNAC\b|ацетилцистеин/i, key: /NAC/i, gate: 'M-D' },
  { drug: /GLP-?1|семаглутид|лираглутид|дулаглутид|ozempic|оземпик/i, key: /GLP-1/i, gate: 'M-D' },
  { drug: /SGLT-?2|глифлозин|форсига|джардинс|петлев|фуросемид|торасемид/i, key: /SGLT-2/i, gate: 'M-D' },
  { drug: /метформин/i, key: /метформин/i, gate: 'M-D' },
  { drug: /серрапептаз|наттокиназ|системн[а-яё]* энзим/i, key: /энзим/i, gate: 'антикоагулянт' },
  { drug: /НПВС|ибупрофен|диклофенак|напроксен|кеторолак|нимесулид/i, key: /НПВС/i, gate: 'антикоагулянт' },
];

export function substitutions(membrane: Membrane, currentDrugs: string[]): SubstitutionNote[] {
  const drugs = currentDrugs ?? [];
  const onAnticoag = drugs.some((d) => ANTICOAG.test(d));
  const isMD = /^M-D/.test(membrane);
  const out: SubstitutionNote[] = [];
  for (const m of SUB_MATCH) {
    const hit = drugs.filter((d) => m.drug.test(d));
    if (!hit.length) continue;
    if (m.gate === 'M-D' && !isMD) continue;
    if (m.gate === 'антикоагулянт' && !onAnticoag) continue;
    const row = SUBS.find((s) => m.key.test(s['запрещено'] ?? ''));
    if (!row) continue;
    out.push({
      banned: hit.join(', '),
      when: row['при'] ?? '—',
      replacement: row['замена'] ?? '—',
      reason: row['причина'] ?? '—',
      caveat: row['оговорка'] && row['оговорка'] !== '—' ? row['оговорка'] : undefined,
    });
  }
  return out;
}

// Полная таблица замен (для экрана и разбора вручную) + правило уровней.
export const SUBSTITUTION_TABLE: SubstitutionNote[] = SUBS.map((s) => ({
  banned: s['запрещено'] ?? '—',
  when: s['при'] ?? '—',
  replacement: s['замена'] ?? '—',
  reason: s['причина'] ?? '—',
  caveat: s['оговорка'] && s['оговорка'] !== '—' ? s['оговорка'] : undefined,
}));

export const LEVEL_RULE: string =
  ((canon as any)['уровни_гель_золь'] ?? {})['правило'] ??
  'Вектор гель⇄золь задаётся на каждом уровне отдельно.';

export const CONFLICT_CASES = ((canon as any)['разрешение_противоречий'] ?? {})['кейсы'] ?? [];

// ── контрольные точки (3 точки инверсии/безопасности) ───────────────
function controlPoints(p: PatientInput, membrane: Membrane): ControlPointStatus[] {
  const drying = (p.currentDrugs ?? []).filter((d) => DRYING.test(d));
  const hasDevice = !!p.devices3D && Object.keys(p.devices3D).length > 0;
  return [
    {
      id: 'кровь',
      text: 'Приборная оценка (EIS/3D) → подтвердить КРОВЬЮ до старта медикамента',
      status: hasDevice ? 'внимание' : '—',
    },
    {
      id: 'истинная_мембрана',
      text: 'Истинная мембрана → поправка на осушающие (SGLT-2/петлевые/Энтресто) ПЕРЕД выбором вектора',
      status: drying.length
        ? 'внимание'
        : 'ok',
      note: drying.length ? ('осушающие в схеме: ' + drying.join(', ') + ' — не принять «сухого» за M-A и не добить в M-D') : undefined,
    },
    {
      id: 'ebm_ворота',
      text: 'EBM-ворота + подпись → энергослой не «якорит» дифдиагноз, данные и дозы',
      status: 'ok',
    },
  ];
}

// ── конфликт мембрана ⇄ энергия ─────────────────────────────────────
function conflictNote(energy: Energy, membrane: Membrane, row?: CanonTreatmentRow): string | undefined {
  if (!row) return undefined;
  const rowSol = /золь|m-d/i.test(row.membrane) ? 'золь' : /гель|m-a|m-s/i.test(row.membrane) ? 'гель' : 'баланс';
  const memSol = solGelOfMembrane(membrane);
  if (memSol !== 'баланс' && rowSol !== 'баланс' && memSol !== rowSol) {
    return `дивергенция ${energy}: таблица по умолчанию → ${rowSol}, истинная мембрана ${membrane} → ${memSol}. Правило: побеждает МЕМБРАНА + безопасность.`;
  }
  return undefined;
}

export interface AlgoContext {
  dominantEnergies: Energy[];
  membrane: Membrane;
  phase: string;
  hangingPoint: string;
}

/**
 * Собрать трассу алгоритма диагноза для конкретного пациента.
 * Берёт уже посчитанные L1-величины (мембрана, доминанты, фаза) из пайплайна —
 * чтобы слой был СОГЛАСОВАН с остальным разбором, а не считал заново.
 */
export function runDiagnosisAlgorithm(p: PatientInput, ctx: AlgoContext): DiagnosisTrace {
  const energy: Energy = ctx.dominantEnergies[0] ?? 'Тепло';
  const membrane = ctx.membrane;
  const dir = directionOfMembrane(membrane);
  const hint = (p.complaints ?? []).join(' · ');
  const row = matchTreatmentRow(energy, membrane, hint);
  const jcz = parseJcz(row?.jcz ?? '');
  const hardStops = checkHardStops(membrane, row, p.currentDrugs ?? []);
  const cps = controlPoints(p, membrane);
  const conflict = conflictNote(energy, membrane, row);
  const subs = substitutions(membrane, p.currentDrugs ?? []);
  // подборщик получает контекст: строка Общей таблицы сильнее сырого фильтра по энергии
  const drugs = quench658(energy, { limit: 10, hint, prefer: row?.drugs658 ?? '' });

  const complaint = (p.complaints && p.complaints[0]) ? p.complaints[0] : '—';
  const color = row?.color || COLOR[energy] || '—';
  const magnet = row?.magnet || `белый на ${energy}`;

  const steps: DiagnosisStep[] = [
    {
      n: 0, key: 'жалоба', name: 'ВХОД — ЖАЛОБА', layer: 'вход', decides: 'с чего начать',
      finding: `${(p.complaints ?? []).length} жалоб(ы); ведущая: «${complaint}». Все жалобы verbatim; «анализы в норме» жалобу не закрывает.`,
    },
    {
      n: 1, key: 'мембрана', name: 'МЕМБРАНА (гель/золь) + истинная поправка', layer: 'ПЕРВИЧНО · безопасность',
      decides: 'МОЖНО ЛИ и КУДА (строить↔разбирать)',
      finding: `${membrane} · ${dir.sol} → НАПРАВЛЕНИЕ: ${dir.direction}. ${dir.note}.` +
        (cps[1].status === 'внимание' ? ' ⚠ истинная мембрана: поправка на осушающие.' : ''),
    },
    {
      n: 2, key: 'энергия', name: 'ЭНЕРГИЯ (что/где) — внутри вектора', layer: 'ВТОРИЧНО · мишень',
      decides: 'ЧЕМ ИМЕННО и по какому органу',
      finding: `${energy}${ctx.dominantEnergies.length > 1 ? ' (+ ' + ctx.dominantEnergies.slice(1).join(', ') + ')' : ''}` +
        ` · орган: ${row?.organ ?? '—'} · магнит: ${magnet} · цвет (Ко): ${color}.`,
    },
    {
      n: 3, key: 'фаза', name: 'ФАЗА', layer: 'момент', decides: 'КОГДА и в каком ритме',
      finding: `${ctx.phase}${row?.phase && row.phase !== '—' ? ' · таблица: ' + row.phase : ''}. Точка зависания: ${ctx.hangingPoint}. На переходе меняется всё.`,
    },
    {
      n: 4, key: 'лекарства', name: 'ЛЕКАРСТВА — база 658 + JCZ', layer: 'исполнение',
      decides: 'КАКОЙ препарат и в какой роли',
      finding: `Вектор «${row?.vector ?? dir.direction}». Фильтр «гасит: ${energy}» по 658 → ${drugs.length ? drugs.map((d) => d.n).slice(0, 6).join(', ') : '—'}` +
        (jcz.length ? `. JCZ: ${jcz.map((j) => j.role + '→' + j.item).join(' · ')}` : '') + '.' +
        (subs.length ? ` ЗАМЕНЫ (§2J.1): ${subs.map((s) => s.banned + ' → ' + s.replacement).join(' · ')}.` : ''),
    },
    {
      n: 5, key: 'ebm', name: 'ВОРОТА — EBM + подпись врача', layer: 'поверх всего',
      decides: 'СКОЛЬКО и НЕ ПРОПУСТИЛИ ЛИ',
      finding: 'Рабочий диагноз, красные флаги и дозы — за EBM и подписывающим врачом. Энергослой не переопределяет дифдиагноз/данные/дозы.',
    },
  ];

  const treatmentRow: TreatmentRow | undefined = row
    ? {
        energy: row.energy, organ: row.organ, membrane: row.membrane, phase: row.phase,
        vector: row.vector, magnet: row.magnet, color: row.color, drugs658: row.drugs658,
        jcz: row.jcz, hardStop: row.hardStop,
      }
    : undefined;

  return {
    order: 'Жалоба → МЕМБРАНА (первично) → ЭНЕРГИЯ (вторично) → ФАЗА → 658+JCZ → EBM',
    mantra: (canon as any)['мантра'] ?? 'направление раньше мишени · мембрана раньше лекарства · кровь раньше дозы',
    direction: dir.direction,
    steps,
    controlPoints: cps,
    treatmentRow,
    jczLadder: jcz,
    hardStops,
    conflict,
    substitutions: subs,
    levelRule: LEVEL_RULE,
    compartments: (() => {
      const a = assessCompartments(p, { systemicMembrane: membrane, hint });
      return {
        background: a.background, cataBodywide: a.cataBodywide, safetyNote: a.safetyNote,
        conflicts: a.conflicts,
        list: a.compartments.map((c) => ({ level: c.level, target: c.target, membrane: c.membrane, pole: c.pole, vector: c.vector, leading: c.leading, why: c.why })),
        plans: a.plans.map((x) => ({ organ: x.organ, cellId: x.cell.id, relation: x.cell.relation, action: x.action, hardStop: x.cell.hardStop })),
        needsMoreData: a.needsMoreData,
      };
    })(),
    supplements: supplementPlan({ membrane, currentDrugs: p.currentDrugs ?? [], hint }),
    library: (() => {
      const b = libraryFor(membrane, hint);
      return b ? { membrane: b.membrane, name: b.name, vector: b.vector, goals: b.goals, monitoring: b.monitoring, hardStop: b.hardStop } : undefined;
    })(),
    transition: assessTransition(p, {
      membrane,
      energies: ctx.dominantEnergies,
      phase: ctx.phase,
      direction: dir.direction,
    }),
  };
}

export const ALGO_SOURCE = (canon as any)['версия'] ?? 'diagnosis_algorithm_canon';
export const HARD_STOP_LIST = HARD_STOP;
