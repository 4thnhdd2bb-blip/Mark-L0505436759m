// METACOD-Omer · shared/engines/differential.ts
// Дифференциальный диагноз: искать ОДНУ связывающую причину (бритва Оккама),
// ранжировать гипотезы, отдельно вести «параллельно НЕ ПРОПУСТИТЬ».

import type { Hypothesis } from '../types';

export interface Finding { name: string; value?: string | number; flag?: 'hi' | 'lo' | 'abn'; }

export interface DiffInput {
  findings: Finding[];
  candidates: Omit<Hypothesis, 'rank'>[]; // сырые гипотезы общего корня
  cannotMiss: string[];                    // опасные линии, вести параллельно
}

/** Ранжирование по объясняющей силе: сколько находок объясняет один корень. */
export function rankHypotheses(input: DiffInput): { ranked: Hypothesis[]; cannotMiss: string[] } {
  const scored = input.candidates.map((c) => {
    const explainsCount = input.findings.filter((f) =>
      c.explains.toLowerCase().includes(String(f.name).toLowerCase())
    ).length;
    return { c, score: explainsCount };
  });
  scored.sort((a, b) => b.score - a.score);
  const ranked: Hypothesis[] = scored.map((s, i) => ({ rank: i + 1, ...s.c }));
  return { ranked, cannotMiss: input.cannotMiss };
}

/** «Разветвитель» — анализ, отсекающий максимум гипотез за один шаг. */
export function pickSplitters(ranked: Hypothesis[]): string[] {
  const all = ranked.flatMap((h) => h.confirm);
  const freq = new Map<string, number>();
  for (const t of all) freq.set(t, (freq.get(t) ?? 0) + 1);
  return [...freq.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([t]) => t);
}
