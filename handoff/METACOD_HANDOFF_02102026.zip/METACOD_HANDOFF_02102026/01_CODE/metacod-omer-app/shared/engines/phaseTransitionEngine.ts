// METACOD-Omer · shared/engines/phaseTransitionEngine.ts
// ФАЗОВЫЕ ПЕРЕХОДЫ (динамическое лечение по дуге) + разрешение противоречий гель-золь ⇄ энергия.
// Источники (Drive): phase_transitions.json (границы · Ко-цикл · динамический 5-фазный протокол ·
// как_читать_зависание) + Общая таблица лечения (лист «Фазовые переходы») + Gel-Zol (Энергия↔Мембрана).
// Принцип: пациент ЗАВИСАЕТ на границе двух соседних фаз; лечение = ВЫВОД через границы к Норматонии.
// Слой L1 · validated:false · дозы/красные флаги/онко — за врачом.

import type { Energy, Membrane, SolGel } from '../types';
import { solGelOfMembrane } from './solGel';

// ── дуга фаз (процессная): CA→PCL-A→Эпикризис→PCL-B→Норматония ──
export type Phase = 'CA' | 'PCL-A' | 'Эпикризис' | 'PCL-B' | 'Норматония';
export const ARC: Phase[] = ['CA', 'PCL-A', 'Эпикризис', 'PCL-B', 'Норматония'];
const PHASE_ENERGY: Record<Phase, Energy> = {
  'CA': 'Холод', 'PCL-A': 'Влажность', 'Эпикризис': 'Ветер', 'PCL-B': 'Сухость', 'Норматония': 'Тепло',
};
// порядок энергий на дуге (для соседства/зависания)
const ENERGY_ORDER: Energy[] = ['Холод', 'Влажность', 'Ветер', 'Сухость', 'Тепло'];

// ── динамический 5-фазный протокол (что делаем В фазе) ──
interface PhaseProtocol { energy: Energy; solgel: string; membrane: string; goal: string; means: string; gate: string; }
const PROTO: Record<Phase, PhaseProtocol> = {
  'CA':          { energy: 'Холод',    solgel: 'застой-старт',   membrane: 'формируется M-A/M-D', goal: 'снять холод/конфликт, подготовить трансформацию', means: 'согреть Ян (moxa/метаболич. опора), тиамин при истощении; НЕ форсировать', gate: 'теплоощущение↑, острота стресса↓ · ТТГ/электролиты/глюкоза' },
  'PCL-A':       { energy: 'Влажность', solgel: 'застойный гель', membrane: 'M-A',               goal: 'восстановление без задержки жидкости; дренаж избытка', means: 'мягкий дренаж (SP9, диуретик малой дозой), магний, омега-3; не перекормить', gate: 'отёк/вес↓, воспаление контролируется · вес/BNP/креатинин/K' },
  'Эпикризис':   { energy: 'Ветер',    solgel: 'нестабильность', membrane: 'переход',            goal: 'безопасно пройти пик/криз, стабилизировать Ветер', means: 'магний; по органу антиаритмик/спазмолитик; минимум новых вмешательств', gate: 'ритм/спазм стабильны · ЭКГ/ВСР, K/Mg' },
  'PCL-B':       { energy: 'Сухость',  solgel: 'окно анаболиков', membrane: 'M-A (строить)/M-S', goal: 'восстановить субстрат/структуру, антифиброз, управляемо пройти сухость', means: 'анаболики (белок/лейцин, B12/железо; инсулин/тестостерон по показанию), увлажнение (омега-3); при M-S — 3 столпа; НЕ катаболики', gate: 'субстрат восполнен: ферритин 50–70/B12/альбумин · масса/сила↑' },
  'Норматония':  { energy: 'Тепло',    solgel: 'равновесие',     membrane: 'M-0',                goal: 'удержание, минимальная схема, вторичная профилактика', means: 'магний/омега-3/вит D поддерживающе; средиземноморье; деэскалация', gate: 'pH мочи осциллирует, симптомы ушли, анализы стабильны' },
};

// ── границы (манёвр вывода): магнит·цвет·лекарство + Ко-формула ──
export interface Border {
  code: string; from: Phase; to: Phase; energies: string;
  vector: string; koFormula: string;            // усилить входящую + ослабить её угнетатель
  magnet: string; color: string;                // магнит гасит уходящую · цвет = Ко входящей
  yangDrug: string; yinDrug: string;            // Ян-лекарство (гасить уходящую) · Инь-лекарство (ввести входящую)
  points: string; term: string; stuck: string;  // точки · срок · признак зависания
}
const BORDERS: Border[] = [
  { code: 'CA↔PCL-A', from: 'CA', to: 'PCL-A', energies: 'Холод ↔ Влажность',
    vector: 'согреть Ян → трансформировать Влажность → двигать вперёд', koFormula: 'усилить Влажность + ослабить Ветер (Ко: Ветер⊣Влажность)',
    magnet: 'белый гасит Холод', color: 'зелёный (Ветер — Ко входящей Влажности)',
    yangDrug: 'согреть: левотироксин (при гипотиреозе), D3, CoQ10, тиамин', yinDrug: 'двигать: прокинетики/дренаж (SP9, тиазид/петлевой низко), магний',
    points: 'GV4/CV4/KI7 прижигание + SP9 дренаж', term: '1–3 нед', stuck: 'то зябкость/застой, то отёк/слизь; нет тепла трансформировать жидкость' },
  { code: 'PCL-A↔Эпикризис', from: 'PCL-A', to: 'Эпикризис', energies: 'Влажность ↔ Ветер',
    vector: 'дренировать Влажность + успокоить Ветер → пройти Эпикризис', koFormula: 'усилить Ветер + ослабить Сухость (Ко: Сухость⊣Ветер)',
    magnet: 'белый гасит Влажность (GLP-1/метформин по механизму)', color: 'коричневый (Сухость)',
    yangDrug: 'гасить Влажность: дренаж/диуретик, GLP-1/метформин', yinDrug: 'граница: магний, антиаритмик/спазмолитик, гемостатики/вяжущие; β-блок ТОЛЬКО при Ветре-сердца (осторожно, охлаждает)',
    points: 'SP9 дренаж + LR3/GB34 (Ветер) + Mg', term: '1–4 нед', stuck: 'то отёк/тяжесть, то спазм/аритмия/тремор; сырость подкармливает Ветер' },
  { code: 'Эпикризис↔PCL-B', from: 'Эпикризис', to: 'PCL-B', energies: 'Ветер ↔ Сухость',
    vector: 'стабилизировать Ветер + увлажнить/размягчить, войти в окно анаболиков', koFormula: 'усилить Сухость + ослабить Тепло (Ко: Тепло⊣Сухость)',
    magnet: 'белый гасит Ветер (β-блок/БКК/Mg)', color: 'красный (Тепло)',
    yangDrug: 'гасить Ветер: β-блок/БКК/магний/габапентиноид', yinDrug: 'согреть/размягчить: вазодилат./трофик, омега-3, увлажнение (LU9/KI6)',
    points: 'Mg + LU9/KI6 увлажнить', term: 'дни–2 нед', stuck: 'то шторм/аритмия, то сухость/консолидация' },
  { code: 'PCL-B↔Норматония', from: 'PCL-B', to: 'Норматония', energies: 'Сухость ↔ Тепло',
    vector: 'антифиброз/увлажнить + согреть-наполнить субстрат → закрыть цикл к M-0', koFormula: 'усилить Тепло + ослабить Холод (Ко: Холод⊣Тепло)',
    magnet: 'белый гасит Сухость (антифиброз/увлажнение)', color: 'чёрный (Холод)',
    yangDrug: 'гасить Сухость: антифиброз (омега-3), увлажнение, пластический пул (коллаген/глицин/пролин)', yinDrug: 'согреть-наполнить: B12/железо/фолат/креатин, вит D3; при показании базальный инсулин/тестостерон',
    points: 'KI3/KI7/BL23/GV4 прижигание + ST36 (Ян-корень)', term: '6–12 нед до входа; полное 3–6 мес', stuck: 'то сухость/атрофия, то воспаление; Ян-корень не поднят (заякорен непройденным CA-Холодом)' },
];

// ── дивергенции гель-золь ⇄ энергия (Gel-Zol · Энергия↔Мембрана) ──
interface Divergence { defaultPole: SolGel; defaultNote: string; divergent: string; risk: string; }
const DIVERGENCE: Partial<Record<Energy, Divergence>> = {
  'Тепло':    { defaultPole: 'золь', defaultNote: 'острое воспаление/экссудация (M-D)', divergent: 'хронизация → M-S фиброз (ГЕЛЬ)', risk: 'лечить остро, пропустить исход в фиброз' },
  'Влажность':{ defaultPole: 'гель', defaultNote: 'обмен: МетС/СД2/ожирение (M-A2)',   divergent: 'острый отёк/вода → золь/дренаж (M-D) — ПРОТИВОПОЛОЖНО', risk: 'дать катаболик на отёчный золь' },
  'Сухость':  { defaultPole: 'гель', defaultNote: 'фиброз/склероз (M-S)',              divergent: 'атрофия → M-D (ЗОЛЬ) — ПРОТИВОПОЛОЖНО', risk: 'размягчать там, где надо питать' },
  'Холод':    { defaultPole: 'гель', defaultNote: 'застой (гипотиреоз/ХБП/ишемия)',    divergent: 'кахексия → M-D2 (ЗОЛЬ) — ПРОТИВОПОЛОЖНО + HARD-STOP', risk: 'катаболик в M-D2 = запрещён, опасно' },
  'Ветер':    { defaultPole: 'гель', defaultNote: 'деление/пролиферация (M-A/онко)',   divergent: 'Ветер-1 невыключенный = драйвер M-S фиброза', risk: 'антипролиферацию без учёта фиброза' },
  'Жар':      { defaultPole: 'гель', defaultNote: 'метаболич./эндокрин./↑АД (M-A)',    divergent: '—', risk: '—' },
};

// ── типы вывода ──
export interface PhaseTransitionStep { phase: Phase; energy: Energy; solgel: string; membrane: string; goal: string; means: string; gate: string; current: boolean; }
export interface EnergyContradiction { energy: Energy; membranePole: SolGel; energyDefaultPole: SolGel; divergent: string; verdict: string; }
export interface PhaseTransitionPlan {
  currentPhase: Phase;
  hangingBorder: string;
  collapsed: boolean;               // «схлопнутая» дуга (несоседние доминанты)
  collapseNote?: string;
  road: PhaseTransitionStep[];      // фазы от текущей до Норматонии
  maneuvers: Border[];              // границы-манёвры на пути
  contradictions: EnergyContradiction[];
  mantra: string;
}

function phaseFromEnergy(e: Energy): Phase { return (Object.keys(PHASE_ENERGY) as Phase[]).find((p) => PHASE_ENERGY[p] === e) ?? 'CA'; }

/** Определить границу зависания и «схлопнутость» по доминантам/фазе. */
function locateHanging(dominant: Energy[], phase?: Phase): { border: string; from: Phase; collapsed: boolean; note?: string } {
  const idx = dominant.map((e) => ENERGY_ORDER.indexOf(e)).filter((i) => i >= 0).sort((a, b) => a - b);
  if (idx.length >= 2) {
    const adjacent = idx[idx.length - 1] - idx[0] === 1;
    if (adjacent) {
      const from = phaseFromEnergy(ENERGY_ORDER[idx[0]]);
      return { border: `${ENERGY_ORDER[idx[0]]}↔${ENERGY_ORDER[idx[1]]}`, from, collapsed: false };
    }
    return {
      border: `${ENERGY_ORDER[idx[0]]}↔${ENERGY_ORDER[idx[idx.length - 1]]} (дальняя)`,
      from: phaseFromEnergy(ENERGY_ORDER[idx[0]]), collapsed: true,
      note: 'несоседние доминанты → дуга «схлопнута»: средние фазы (Влажность/Ветер) подавлены (β-блок/возраст/дефицит); завис на дальней границе, заякорен непройденным CA-Холодом (Ян-дефицит) — сначала поднять Ян-корень.',
    };
  }
  const from = phase ?? 'CA';
  return { border: `${PHASE_ENERGY[from]}↔${PHASE_ENERGY[ARC[Math.min(ARC.indexOf(from) + 1, 4)]]}`, from, collapsed: false };
}

/** Разрешение противоречий гель-золь ⇄ энергия для доминант пациента. */
export function contradictions(dominant: Energy[], membrane: Membrane): EnergyContradiction[] {
  const memPole = solGelOfMembrane(membrane);
  const out: EnergyContradiction[] = [];
  for (const e of dominant) {
    const d = DIVERGENCE[e];
    if (!d) continue;
    if (memPole !== 'баланс' && memPole !== d.defaultPole) {
      out.push({
        energy: e, membranePole: memPole, energyDefaultPole: d.defaultPole, divergent: d.divergent,
        verdict: `Противоречие: ярлык «${e}» по умолчанию → ${d.defaultPole} (${d.defaultNote}), но истинная мембрана ${membrane} → ${memPole}. РАЗРЕШЕНИЕ: побеждает МЕМБРАНА + безопасность → направление ${memPole === 'золь' ? 'анаболик (питать/строить)' : 'катаболик/разгелить'}; энергия «${e}» лишь называет орган-мишень. ${d.risk !== '—' ? 'Риск при диагнозе «по энергии»: ' + d.risk + '.' : ''} На переходе Влажность/Сухость/Холод дренируются/увлажняются МЯГКО, не инвертируя вектор.`,
      });
    }
  }
  return out;
}

/** Построить план фазовых переходов: дорога от зависания к Норматонии + манёвры + противоречия. */
export function phaseTransitionPlan(ctx: { dominantEnergies: Energy[]; membrane: Membrane; phase?: Phase }): PhaseTransitionPlan {
  const hang = locateHanging(ctx.dominantEnergies, ctx.phase);
  const startIdx = Math.max(0, ARC.indexOf(hang.from));
  const road: PhaseTransitionStep[] = ARC.slice(startIdx).map((phase, i) => {
    const pr = PROTO[phase];
    return { phase, energy: pr.energy, solgel: pr.solgel, membrane: pr.membrane, goal: pr.goal, means: pr.means, gate: pr.gate, current: i === 0 };
  });
  const roadPhases = new Set(road.map((s) => s.phase));
  const maneuvers = BORDERS.filter((b) => roadPhases.has(b.from) && roadPhases.has(b.to));
  return {
    currentPhase: hang.from,
    hangingBorder: hang.border,
    collapsed: hang.collapsed,
    collapseNote: hang.note,
    road,
    maneuvers,
    contradictions: contradictions(ctx.dominantEnergies, ctx.membrane),
    mantra: 'фаза — не срез, а дорога · на границе меняется ВСЁ (мембрана→золь/гель→препараты→дозы→время) · вести к Норматонии, не компенсировать сегодня',
  };
}

export const PHASE_TRANSITION_SOURCE = 'phase_transitions.json (границы · Ко-цикл · 5-фазный протокол) + Общая таблица (Фазовые переходы) + Gel-Zol (Энергия↔Мембрана)';
