// METACOD-Omer · shared/engines/membraneLibrary.ts
// §2M — БИБЛИОТЕКА ЛЕЧЕНИЯ ПО МЕМБРАНЕ + НУТРИЦЕВТИКА КАК ЧАСТЬ СХЕМЫ + ИНДЕКС ГРУЗА.
//
//   1) libraryFor(membrane, hint) — готовый блок программы: молекулярная мишень, препараты 658
//      с дозами-ориентирами, биомаркёр-цели, каденс мониторинга, HARD-STOP, орган-варианты.
//   2) supplementPlan(ctx) — ДЕТЕРМИНИРОВАННЫЕ правила нутрицевтики: добавки перестают быть
//      «приложением к лечению» и становятся частью схемы (CoQ10 на статине, белок при кахексии
//      с потолком при ХБП, B12 на метформине, пластический пул при M-S, редокс без NAC…).
//   3) burdenIndex(input) — индекс груза незавершённых программ (глава «Долголетие»).
//      Research-grade: считается только по ДОСТУПНЫМ компонентам, недостающие — в запрос.
//
// Слой ВНУТРЕННИЙ (L1). validated:false. Дозы — ОРИЕНТИР; титрация, красные флаги и онкология —
// за подписывающим врачом.

import type { Membrane } from '../types';
import canon from '../data/diagnosis_algorithm_canon.json';

const LIB = (((canon as any)['библиотека_по_мембране'] ?? {})['блоки'] ?? []) as Array<Record<string, any>>;
const BURDEN = ((canon as any)['индекс_груза'] ?? {}) as Record<string, any>;

// ── 1. БЛОК ПРОГРАММЫ ПО МЕМБРАНЕ ───────────────────────────────────
export interface LibraryDrug { target: string; drug: string; mechanism: string; }
export interface LibraryBlock {
  membrane: string;
  name: string;
  program: string;
  vector: string;
  subphases: string[];
  drugs: LibraryDrug[];
  supplements: string;
  goals: string;
  monitoring: string;
  hardStop: string;
  organVariants: string;
}

function toBlock(r: Record<string, any>): LibraryBlock {
  return {
    membrane: r['мембрана'], name: r['имя'], program: r['программа'], vector: r['вектор'],
    subphases: (r['подфазы'] ?? []) as string[],
    drugs: ((r['препараты'] ?? []) as Array<Record<string, string>>)
      .map((x) => ({ target: x['мишень'], drug: x['препарат'], mechanism: x['механизм'] })),
    supplements: r['добавки'] ?? '', goals: r['цели'] ?? '', monitoring: r['мониторинг'] ?? '',
    hardStop: r['hardStop'] ?? '', organVariants: r['орган_варианты'] ?? '',
  };
}

/**
 * Блок библиотеки по мембране. Для M-A2 нужен под-тип: метаболический ⇄ «крови»
 * (один полюс — разные вкусы, §2K правило 6), поэтому hint читается на эритроцитоз.
 */
export function libraryFor(membrane: Membrane, hint = ''): LibraryBlock | undefined {
  const h = (hint || '').toLowerCase();
  const key =
    membrane === 'M-A2'
      ? (/эритроцитоз|гипервязк|полицитем|\bhct\b|гематокрит/.test(h) ? 'M-A2-кровь' : 'M-A2-обмен')
      : membrane === 'M-A3' ? 'M-A3'
      : membrane === 'M-A1' ? 'M-A1'
      : membrane === 'M-D3' ? 'M-D2'   // M-D3 ведётся по блоку красной зоны, строже
      : membrane;
  const row = LIB.find((r) => r['мембрана'] === key);
  return row ? toBlock(row) : undefined;
}

export const LIBRARY_BLOCKS: LibraryBlock[] = LIB.map(toBlock);
export const LIBRARY_ORDER: string[] = (((canon as any)['библиотека_по_мембране'] ?? {})['порядок_применения'] ?? []) as string[];

// ── 2. НУТРИЦЕВТИКА КАК ЧАСТЬ СХЕМЫ ─────────────────────────────────
export interface SupplementItem {
  item: string;
  reason: string;
  step: string;
  dose?: string;
  caution?: string;
}
export interface SupplementCtx {
  membrane: Membrane;
  currentDrugs?: string[];
  egfr?: number;            // мл/мин/1.73 — потолок белка при ХБП
  cata?: boolean;           // подтверждённый глубокий катаболизм (см. §2L mdSubtype)
  hint?: string;            // жалобы/картина (эритроцитоз, MDA↑, ФП…)
}

const STATIN_HIGH = /аторвастатин\s*(40|80)|розувастатин\s*(20|40)|atorva\s*(40|80)|rosuva\s*(20|40)/i;
const STATIN_ANY = /статин|аторвастатин|розувастатин|симвастатин|правастатин|питавастатин/i;
const ANTICOAG = /апиксабан|ривароксабан|эдоксабан|дабигатран|варфарин|эноксапарин|клексан/i;
const METFORMIN = /метформин/i;
const GLP1 = /GLP-?1|семаглутид|лираглутид|дулаглутид|тирзепатид|ozempic|оземпик/i;
const AF = /фибрилляц|трепетан|(?<![а-яёa-z])фп(?![а-яёa-z])|аритми|icd|икд/i;

/**
 * Детерминированные правила. Каждая выдача несёт ПРИЧИНУ — строка без причины в план не попадает
 * (§2L, гигиена вывода). Дозы — ориентир.
 */
export function supplementPlan(ctx: SupplementCtx): SupplementItem[] {
  const drugs = ctx.currentDrugs ?? [];
  const text = ((ctx.hint ?? '') + ' ' + drugs.join(' ')).toLowerCase();
  const out: SupplementItem[] = [];
  const md = /^M-D/.test(ctx.membrane);
  const deepCata = ctx.cata === true || ctx.membrane === 'M-D2' || ctx.membrane === 'M-D3';
  const onAnticoag = drugs.some((d) => ANTICOAG.test(d));
  const ckd = ctx.egfr !== undefined && ctx.egfr < 45;

  // статин → CoQ10 (защита мышцы), при высокой дозе обязателен
  if (drugs.some((d) => STATIN_ANY.test(d))) {
    const high = drugs.some((d) => STATIN_HIGH.test(d));
    out.push({
      item: 'CoQ10 (убихинол)', dose: '200 мг с едой',
      reason: high ? 'высокая доза статина — защита мышцы обязательна' : 'статин в схеме — защита мышцы',
      step: 'сопровождение терапии',
    });
  }

  // метформин → B12
  if (drugs.some((d) => METFORMIN.test(d))) {
    out.push({ item: 'B12', dose: '1000 мкг (в/м при мальабсорбции) + фолат', reason: 'метформин снижает B12', step: 'сопровождение терапии' });
  }

  // глубокий катаболизм → белок с потолком при ХБП
  if (deepCata) {
    out.push(ckd
      ? { item: 'белок + лейцин/HMB', dose: '≈1.0 г/кг равномерно 25–30 г на приём · лейцин 3 г · HMB 3 г',
          reason: 'катаболизм требует 1.2–1.6 г/кг, но ХБП ограничивает — компромисс по дозе, анаболический стимул через лейцин/HMB и силовые',
          step: 'анаболизм (главный ход)', caution: 'вести с нефрологом' }
      : { item: 'белок + лейцин', dose: '1.2–1.6 г/кг + лейцин 3 г с едой',
          reason: 'подтверждённый катаболизм: мышца строится субстратом, а не препаратом',
          step: 'анаболизм (главный ход)' });
    out.push({ item: 'силовая нагрузка', dose: '2–3 раза в неделю', reason: 'анаболический стимул — «главный препарат» при саркопении', step: 'анаболизм (главный ход)' });
  }

  // GLP-1 в схеме → защита мышцы обязательна (страховка от переката, §2K)
  if (drugs.some((d) => GLP1.test(d)) && !deepCata) {
    out.push({ item: 'белок + креатин + силовая', dose: 'белок 1.2–1.6 г/кг · креатин 3–5 г · силовая 2–3×/нед',
      reason: 'GLP-1 снижает и мышечную массу — страховка от переката M-A2 → M-D2', step: 'страховка от переката' });
  }

  // M-S → пластический пул и стоп-ПОЛ; энзимы только без антикоагулянта
  if (ctx.membrane === 'M-S') {
    out.push({ item: 'пластический пул', dose: 'коллаген I+III 15–20 г · глицин 3–5 г · L-пролин 1 г + витамин C 500 ×2 · гиалуроновая 200 мг',
      reason: 'материал для ЗДОРОВОЙ ткани — иначе консолидация идёт рубцом', step: 'столп 2 — пластический пул' });
    out.push({ item: 'стоп-ПОЛ', dose: 'омега-3 EPA/DHA 1–2 г · CoQ10 · таурин',
      reason: 'антиферроптоз, защита мембран', step: 'столп 3 — редокс',
      caution: onAnticoag ? 'омега-3 умеренно: в схеме антикоагулянт' : undefined });
    if (onAnticoag) {
      out.push({ item: '⛔ системные энзимы (серрапептаза/наттокиназа/бромелайн)', reason: 'антикоагулянт в схеме — энзимный лизис противопоказан (кровоточивость); антифиброз ведётся ARNi + АМКР + пластическим пулом',
        step: 'вето безопасности' });
    }
  }

  // редокс при глубоком катаболизме — БЕЗ NAC
  if (deepCata && /mda|окислен|редокс|перекисн/.test(text)) {
    out.push({ item: 'редокс без NAC', dose: 'глутатион липосомальный · α-липоевая 600 мг · селенометионин · токоферолы',
      reason: 'редокс закрыть надо (MDA↑), но NAC при M-D2/M-D3 под HARD-STOP', step: 'редокс', caution: 'NAC — только явным решением врача' });
  }

  // ритм/ФП → магний и контроль электролитов
  if (AF.test(text)) {
    out.push({ item: 'магний глицинат', dose: '300–400 мг вечером', reason: 'демпфер Ветра, профилактика электролитного триггера ФП', step: 'ритм',
      caution: 'контроль K и Mg, особенно с АМКР' });
  }

  // M-A2 «крови» → разжижать, не строить
  if (ctx.membrane === 'M-A2' && /эритроцитоз|гипервязк|полицитем|гематокрит/.test(text)) {
    out.push({ item: 'гидратация + омега-3', dose: 'адекватный объём жидкости · омега-3 EPA/DHA',
      reason: 'кровь в гель-сдвиге: добавки работают на разгеливание, а не на наполнение', step: 'реология' });
    out.push({ item: '⛔ железо и «тоники»', reason: 'высокий Hct — железо сгустит и без того густую кровь', step: 'вето безопасности' });
  }

  // M-D без глубокого катаболизма → субстрат
  if (md && !deepCata) {
    out.push({ item: 'субстрат', dose: 'B12 1000 мкг + фолат · D3 до 40–50 нг/мл + K2 · магний глицинат · железо ПОСЛЕ исключения ЖКТ-источника',
      reason: 'M-D: без материала переход не достраивается', step: 'наполнение' });
    out.push({ item: 'митохондрия', dose: 'CoQ10 100–200 мг · L-карнитин 1–2 г · креатин 3–5 г · α-липоевая 600 мг',
      reason: 'зажечь клетку, чтобы фаза пошла', step: 'наполнение' });
  }

  // M-0 — формула удержания
  if (ctx.membrane === 'M-0') {
    out.push({ item: 'формула M-0', dose: 'омега-3 + магний + D3', reason: 'удержание равновесия, не перелечивать', step: 'удержание' });
  }

  // дедуп по названию
  const seen = new Set<string>();
  return out.filter((x) => (seen.has(x.item) ? false : (seen.add(x.item), true)));
}

// ── 3. ИНДЕКС ГРУЗА (глава «Долголетие») ────────────────────────────
export interface BurdenInput {
  phaseAngle?: number;        // PA50
  muscle?: 'норма' | 'снижение' | 'саркопения';
  crpChronic?: number;        // мг/л, вне острого
  fibrosis?: 'низкий' | 'промежуточный' | 'высокий';
  deficits?: number;          // сколько из B12/ферритин/D ниже цели (0..3)
  ltlPercentile?: number;     // перцентиль к возрасту
  epiAgeDelta?: number;       // эпигенетический минус паспортный, годы
}
export interface BurdenComponent { id: string; score: number; why: string; }
export interface BurdenResult {
  index: number | null;       // 0..100, null если нет ни одного компонента
  band: 'низкий' | 'умеренный' | 'высокий' | 'очень высокий' | 'не определён';
  coverage: string;           // «4 из 7»
  provisional: boolean;       // покрытие < 3 компонентов
  components: BurdenComponent[];
  needsMoreData: string[];
  note: string;
}

const ALL_COMPONENTS: Array<[string, string]> = [
  ['фазовый_угол', 'фазовый угол PA50 (BIA)'],
  ['мышца_сила', 'мышечная масса и сила'],
  ['воспаление', 'СРБ-хроника'],
  ['фиброз', 'эластометрия / FIB-4'],
  ['дефициты', 'B12 / ферритин / витамин D'],
  ['ltl', 'длина теломер (перцентиль к возрасту)'],
  ['эпивозраст', 'эпигенетический возраст'],
];

const band = (v: number): BurdenResult['band'] =>
  v < 25 ? 'низкий' : v < 50 ? 'умеренный' : v < 75 ? 'высокий' : 'очень высокий';

export function burdenIndex(i: BurdenInput): BurdenResult {
  const c: BurdenComponent[] = [];

  if (i.phaseAngle !== undefined) {
    const v = i.phaseAngle >= 6 ? 0 : i.phaseAngle >= 5 ? 30 : i.phaseAngle >= 4.5 ? 55 : 90;
    c.push({ id: 'фазовый_угол', score: v, why: `PA50 ${i.phaseAngle}` });
  }
  if (i.muscle !== undefined) {
    const v = i.muscle === 'норма' ? 0 : i.muscle === 'снижение' ? 40 : 80;
    c.push({ id: 'мышца_сила', score: v, why: `мышца: ${i.muscle}` });
  }
  if (i.crpChronic !== undefined) {
    const v = i.crpChronic < 1 ? 0 : i.crpChronic <= 3 ? 35 : i.crpChronic <= 10 ? 65 : 90;
    c.push({ id: 'воспаление', score: v, why: `СРБ ${i.crpChronic} мг/л (хроника)` });
  }
  if (i.fibrosis !== undefined) {
    const v = i.fibrosis === 'низкий' ? 0 : i.fibrosis === 'промежуточный' ? 50 : 90;
    c.push({ id: 'фиброз', score: v, why: `фиброз: ${i.fibrosis}` });
  }
  if (i.deficits !== undefined) {
    const v = i.deficits <= 0 ? 0 : i.deficits === 1 ? 35 : 70;
    c.push({ id: 'дефициты', score: v, why: `дефицитов ниже цели: ${i.deficits}` });
  }
  if (i.ltlPercentile !== undefined) {
    const v = i.ltlPercentile >= 50 ? 0 : i.ltlPercentile >= 25 ? 40 : 80;
    c.push({ id: 'ltl', score: v, why: `LTL ${i.ltlPercentile}-й перцентиль` });
  }
  if (i.epiAgeDelta !== undefined) {
    const v = i.epiAgeDelta <= 0 ? 0 : i.epiAgeDelta <= 3 ? 35 : i.epiAgeDelta <= 7 ? 65 : 90;
    c.push({ id: 'эпивозраст', score: v, why: `эпивозраст ${i.epiAgeDelta > 0 ? '+' : ''}${i.epiAgeDelta} лет` });
  }

  const have = new Set(c.map((x) => x.id));
  const need = ALL_COMPONENTS.filter(([id]) => !have.has(id)).map(([, label]) => label);

  if (c.length === 0) {
    return { index: null, band: 'не определён', coverage: `0 из ${ALL_COMPONENTS.length}`, provisional: true,
      components: [], needsMoreData: need,
      note: 'ни один компонент не доступен — индекс не считается (нули не подставляются)' };
  }
  const idx = Math.round(c.reduce((s, x) => s + x.score, 0) / c.length);
  const provisional = c.length < 3;
  return {
    index: idx, band: band(idx), coverage: `${c.length} из ${ALL_COMPONENTS.length}`, provisional,
    components: c, needsMoreData: need,
    note: (provisional ? 'покрытие меньше 3 компонентов — индекс ориентировочный. ' : '') +
      'research-grade, validated:false: рамка охватывает регуляторно-обратимую часть старения и не охватывает необратимое повреждение; не диагноз и не прогноз.',
  };
}

export const BURDEN_CHANNELS = ((BURDEN['каналы'] ?? []) as Array<Record<string, string>>)
  .map((r) => ({ hallmark: r['холлмарк'], unfinished: r['незавершённая_программа'], lock: r['тип_люка'] }));
export const BURDEN_RULE: string = BURDEN['тезис'] ?? '';
export const BURDEN_LIMITS: string = BURDEN['границы'] ?? '';
export const TELOMERE_RULE = (BURDEN['теломерный_канал'] ?? {}) as Record<string, any>;
