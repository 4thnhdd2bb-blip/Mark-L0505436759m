// METACOD-Omer · shared/engines/guard.ts
// СТРАЖ двух слоёв — ПРИНУДИТЕЛЬНЫЙ (enforce), не только детект.
// Гарантия: наружу (conventional) НЕ выходит ни одного внутреннего слова.
// Механика: scan → redact → verify (двойная проверка). Bias к безопасности.
//
// ВАЖНО (почему тут не используется \b): в JavaScript \b и \w — ASCII-только,
// даже с флагом /u. Для кириллицы \b НЕ срабатывает (буква считается «не-словом»),
// поэтому /гель\b/, /\bЦарь\b/ и т.п. молча пропускали слова. Ниже границы слова
// заданы явными lookaround'ами с кириллице-осведомлённым классом WCH.

/** Класс «буква слова» с латиницей, цифрами и кириллицей. */
const WCH = 'A-Za-z0-9_\\u0400-\\u04FF';
/** Левая и правая границы слова (кириллице-осведомлённые). */
const BL = `(?<![${WCH}])`;
const BR = `(?![${WCH}])`;
const b = (core: string) => new RegExp(`${BL}(?:${core})${BR}`, 'giu');
const raw = (core: string) => new RegExp(core, 'giu');

/** Внутренние термины (никогда наружу). */
const INTERNAL_PATTERNS: RegExp[] = [
  raw(`энерги[${WCH}]*`),
  b('инь'), b('ян'), b(`ян-дефицит[${WCH}]*`),
  raw(`холод[${WCH}]*`), raw(`сухост[${WCH}]*`), raw(`сухость[${WCH}]*`),
  raw(`влажност[${WCH}]*`), raw(`влажн[оаы][${WCH}]*`),
  new RegExp(`${BL}ветер(?!ан)[${WCH}]*`, 'giu'),
  b('жар'), b('жара'), raw('жар-'), raw(`жар[${WCH}]*(?=\\b|$)`),
  b('тепло'), raw('тепло-'), raw(`теплоощущ[${WCH}]*`),
  b(`зол[ья][${WCH}]*`), raw(`золь[${WCH}]*`), raw('золь-гель'),
  b(`гел[ья][${WCH}]*`), raw(`гель`),
  raw(`мембран[${WCH}]*`), raw(`бислой[${WCH}]*`),
  b('M-?A[0-9]?'), b('M-?D[0-9]?'), b('M-?S'), b('M-?0'),
  raw('CA[-\\s]?фаз[а-яё]*'), new RegExp(`${BL}CA(?=.{0,3}(фаз|Холод|холод))`, 'giu'),
  b('PCL[-\\s]?[AB]?'),
  raw(`эпикризис[${WCH}]*`), raw(`норматони[${WCH}]*`),
  raw('Ревичи'), raw(`Хамер[${WCH}]*`), raw(`Загускин[${WCH}]*`), raw('Пак\\s*Дже\\s*Ву'),
  b('JCZ'), b('Царь'), b('Министр'), b('Помощник'), b('Посол'),
  // §2P — слой ЗАТВОРА МЕМБРАНЫ (v2.2). Наружу не выходит ни слова.
  raw(`затвор[${WCH}]*`), raw(`Вэй-?Ци`), raw(`чакр[${WCH}]*`), raw(`Су\\s*Джок`),
  raw(`противоподчин[${WCH}]*`), raw(`подчинител[${WCH}]*`), raw(`цикл[${WCH}]*\\s*Ко(?![${WCH}])`),
  raw(`белы[йм]\\s*магнит[${WCH}]*`), raw(`чёрны[йм]\\s*магнит[${WCH}]*`),
  new RegExp(`${BL}магнит(?!но-резонанс|ной резонанс|ного резонанс|ном резонанс)[${WCH}]*`, 'giu'),
  raw(`меридиан[${WCH}]*`), raw(`прижиг[${WCH}]*`), b(`мокс[${WCH}]*`),
  raw(`моксибаст[${WCH}]*`), raw(`иглоук[${WCH}]*`), raw(`точк[аи]\\s*канон[${WCH}]*`),
  b('MWI'), b('GTM'), b('Слой-?0'),
  // §2V — ГЕН-СЛОЙ (v4.1). Самый исследовательский слой: наружу не выходит ни строкой.
  // ⚠ ПРАВИЛО СЛОВ-КОЛЛИЗИЙ соблюдено буквально. Голые «M1», «C7» и «полюс» НЕ запрещены:
  //   M1 — категория метастазов TNM, C7 — седьмой шейный позвонок, «полюс почки» —
  //   нормальная анатомия. Запрещены только связки, по которым узнаётся внутренний слой.
  raw(`ген-?модул[${WCH}]*`), raw(`модул[ья][${WCH}]*\\s*M[1-9]`), raw(`M[1-9]\\s*[↑↓]?\\s*[/·]\\s*M[1-9]`),
  raw(`M[1-9]\\s*\\((?=mTORC|AMPK|аутофаг|ЭР|воспал|митохондр|фиброз|механотранс|липид|SREBP|YAP|PIEZO)`),
  raw(`(?:анаболическ|катаболическ|фазов|патологическ)[${WCH}]*\\s+полюс[${WCH}]*`),
  raw(`полюс[${WCH}]*\\s+(?:процесса|ткани|золь|гель|M-[AD])`),
  b('mTORC1'), b('mTOR'), b('TFEB'), b('SREBP2?'), b('SCAP'), b('INSIG'), b('XBP1s?'),
  b('IRE1'), b('PERK'), b('ATF4'), b('PIEZO1'), b('YAP'), b('TAZ'), b('FOXO[0-9]?'),
  b('RPTOR'), b('RHEB'), b('SLC38A9'), b('RRAGA'), b('Ragulator'), b('Laurdan'),
  raw(`анаплероз[${WCH}]*`), raw(`тригептаноин[${WCH}]*`), raw('триheptanoin'),
  raw('GLP-?1\\s*[↔<]?[-–—]?>?\\s*C7'), raw(`C7\\s*/\\s*тригептаноин`),
  raw(`архетип[${WCH}]*\\s*(?:механизм|A[0-9])`), b('A[0-9]{2}(?=\\s*·)'),
  raw(`десинхроноз[${WCH}]*`), raw(`кроссволк[${WCH}]*`),
];

/** Легальные клинические слова, которые НЕ трогаем (коллизии подстрок). */
const WHITELIST = [
  'кальян', 'ветеран', 'пожар', 'жаропониж', 'жаропонижа',
  'тепловой удар', 'помощь', 'вспомогат', 'посольств',
  // МРТ — легальный клинический термин, а «магнит» теперь внутреннее слово (§2P).
  'магнитно-резонанс', 'магнитной резонанс', 'магнитного резонанс', 'мрт',
  // ⛔⛔⛔ НАЙДЕНО 30.09.2026 НА ВЫХОДЯЩЕМ ДОКУМЕНТЕ. Шаблон `M-?D[0-9]?` ловит
  // «MD» — врачебную степень в подписи «Dr Mark Litvak, MD» — и принимает её за
  // катаболическую мембрану M-D. То есть Страж останавливал КАЖДЫЙ документ,
  // подписанный врачом его собственным званием.
  //
  // ⭐ Это ровно то «правило слов-коллизий», которое уже применено к M1 (метастазы
  // TNM), C7 (позвонок) и «полюсу» (анатомия почки). Ослаблять шаблон нельзя:
  // «M-D» с дефисом — настоящее внутреннее слово. Разрешается только КОНТЕКСТ
  // подписи, и разрешается узко.
  //
  // ⛔ ПОЧЕМУ ЭТО БЫЛО ОПАСНО. Сторож, который срабатывает на каждом документе,
  // перестаёт читаться: его срабатывания начинают считать шумом. Ложная тревога
  // убивает сторожа вернее, чем пропуск.
  'litvak, md', 'litvak,md',
];

const REDACTION = '[—]';

export interface GuardResult { clean: boolean; hits: string[]; }

function isWhitelisted(full: string, index: number): boolean {
  const a = Math.max(0, index - 14);
  const around = full.slice(a, index + 14).toLowerCase();
  return WHITELIST.some((w) => around.includes(w));
}

/** Скан: список найденных внутренних слов (для аудита). */
export function guardCheck(text: string): GuardResult {
  const hits: string[] = [];
  for (const re of INTERNAL_PATTERNS) {
    re.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = re.exec(text))) {
      if (m[0] && !isWhitelisted(text, m.index)) hits.push(m[0]);
      if (m.index === re.lastIndex) re.lastIndex++;
    }
  }
  return { clean: hits.length === 0, hits: Array.from(new Set(hits.map((h) => h.toLowerCase()))) };
}

/** Принудительно вырезать все внутренние слова из строки. */
export function redact(text: string): string {
  let out = text;
  for (const re of INTERNAL_PATTERNS) {
    out = out.replace(re, (match, ...args) => {
      const index = args[args.length - 2] as number;
      const whole = args[args.length - 1] as string;
      if (!match) return match;
      return isWhitelisted(whole, index) ? match : REDACTION;
    });
  }
  return out;
}

/** Рекурсивно очистить объект (все строковые поля). */
export function enforceClean<T>(obj: T): { obj: T; redactedCount: number } {
  let count = 0;
  const walk = (v: any): any => {
    if (typeof v === 'string') {
      const before = v;
      const after = redact(v);
      if (after !== before) count++;
      return after;
    }
    if (Array.isArray(v)) return v.map(walk);
    if (v && typeof v === 'object') {
      const o: any = {};
      for (const k of Object.keys(v)) o[k] = walk(v[k]);
      return o;
    }
    return v;
  };
  return { obj: walk(obj), redactedCount: count };
}

/**
 * ГЛАВНАЯ функция для сервера: гарантирует чистый conventional наружу.
 * 1) enforce (вырезать) → 2) verify → 3) при остатке — ещё проходы (до 5) →
 * 4) если всё ещё грязно, схлопнуть остаточные хиты в [—] построчно.
 * Возвращает ГАРАНТИРОВАННО чистый объект.
 */
export function enforceConventional<T>(conv: T): { clean: boolean; obj: T; redactedCount: number; residualHits: string[] } {
  let { obj, redactedCount } = enforceClean(conv);
  let scan = guardCheck(JSON.stringify(obj));
  let pass = 0;
  while (!scan.clean && pass < 5) {
    const again = enforceClean(obj);
    obj = again.obj; redactedCount += again.redactedCount;
    scan = guardCheck(JSON.stringify(obj));
    pass++;
  }
  return { clean: scan.clean, obj, redactedCount, residualHits: scan.hits };
}

/** Только проверка объекта (для тестов/аудита). */
export function guardConventional(obj: unknown): GuardResult {
  return guardCheck(JSON.stringify(obj));
}
