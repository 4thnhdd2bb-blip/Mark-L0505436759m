// ═══════════════════════════════════════════════════════════════════
// §4N — ФИЛЬТР ВЫХОДА. ЕДИНСТВЕННОЕ МЕСТО, ГДЕ ПРОХОДИТ ГРАНИЦА
// «МЕДИЦИНА / ОБРАЗ ЖИЗНИ».
//
// Источник — документ врача «METACOD — ФИЛЬТР ВЫХОДА (Output Gate)»,
// целиком: семь шагов, whitelist из восьми категорий, списки запрещённой
// лексики, коды эскалации ESC_*, лимит в два действия, fail-closed,
// журнал с полем engineSource и приёмочные тесты T1–T10.
//
// Слова врача 20.09.2026: «все наши запреты, все наши разрешения
// остаются у нас». Поэтому фильтр живёт В КАБИНЕТЕ, рядом со стражем,
// а не в чужом gateway. Сайт получает уже безопасное.
//
// ⭐ ПРИНЦИП (дословно из документа): «Не «мы не собираем медданные»
// (собираем) и не «мы написали дисклеймер» (недостаточно). Защита в том,
// что ни одно утверждение медицинского класса физически не может попасть
// в интерфейс — его отсекает код, а не дисциплина копирайтера.»
//
// ⛔ FAIL-CLOSED: если правило не может решить — строка НЕ выводится.
// Молчание безопаснее догадки.
//
// Имена с префиксом og* — по правилу префиксов в shared/index.ts.
// ═══════════════════════════════════════════════════════════════════

'use strict';

import { guardCheck } from './guard';
import { computeRedFlags, universalSet } from './redFlags';
import { suppCheck } from './supplements';
import type { ВходФлагов, РезультатФлагов } from './redFlags';

/**
 * ⭐ «ask» добавлено 20.09.2026 по правилу врача: «перед тем, как ты
 * назначаешь, должно спроситься, беременная или нет». Это не отказ и не
 * эскалация: это недостающий ответ, без которого решение не принимается.
 */
export type Решение = 'pass' | 'escalate' | 'drop' | 'ask';
export type Категория = 'sleep' | 'movement' | 'nutrition' | 'breathing'
  | 'recovery' | 'daily_rhythm' | 'hydration' | 'supplement_otc';

/** Восемь разрешённых категорий. Всё остальное — DROP. */
export const БЕЛЫЙ_СПИСОК: Категория[] = [
  'sleep', 'movement', 'nutrition', 'breathing',
  'recovery', 'daily_rhythm', 'hydration', 'supplement_otc',
];

export const МАКСИМУМ_ДЕЙСТВИЙ = 2;

export interface Действие {
  /** Стабильный код действия — сайт переводит его сам (i18n plan_actions). */
  action: string;
  category: string;
  /** Готовый текст наружу, если движок его даёт. Проходит проверку лексики. */
  detail?: string;
  /** Внутренняя причина — ДЛЯ АУДИТА, наружу не идёт никогда. */
  reason_internal?: string;
  /** Можно ли сформулировать без ссылки на болезнь. false → эскалация. */
  disease_independent?: boolean;
  /** Какой слой движка породил строку — для журнала. */
  engineSource?: string;
}

export interface КонтекстФильтра extends ВходФлагов {
  /** Готовый результат флагов. Не задан — посчитаем сами из тех же данных. */
  флаги?: РезультатФлагов;
  /** Лабораторные значения для защитных правил (ферритин и т.п.). */
  labs?: Record<string, number>;
}

export interface ЗаписьЖурнала {
  itemId: string;
  decision: Решение;
  rule: string;
  category: string;
  escalationCode: string | null;
  engineSource: string;
}

export interface РезультатФильтра {
  наружу: Array<{ action: string; category: string; detail?: string }>;
  эскалации: Array<{ code: string; текст: { ru: string; en: string; he: string } }>;
  /** ⭐ Вопросы, на которые нужен ответ ДО выдачи. Пустой массив — вопросов нет. */
  вопросы: Array<{ code: string; текст: { ru: string; en: string; he: string } }>;
  кризис: boolean;
  планРазрешён: boolean;
  журнал: ЗаписьЖурнала[];
  /** Сколько строк движка не прошло — метрика здоровья фильтра. */
  отсеяно: number;
}

// ─── СПИСКИ ЗАПРЕЩЁННОЙ ЛЕКСИКИ (§3 документа врача) ────────────────
// Внутренний слой METACOD ловится СТРАЖЕМ (guard.ts) — второй копии
// списка здесь нет намеренно: два списка разойдутся, и никто не заметит.

/** §3.2 — медицинские утверждения. */
const МЕДИЦИНСКИЕ = [
  'диагноз', 'диагностир', 'лечить', 'вылечить', 'терапия', 'назначить',
  'доза', 'препарат', 'рецепт', 'снизить риск заболевания', 'предотвратить болезнь',
  'нормализовать показатель', 'токсины', 'очищение организма',
  'diagnose', 'treat', 'cure', 'prescribe', 'dose', 'prescription',
];

/** §3.2 — «дефицит» и «воспаление» запрещены только как СОСТОЯНИЕ ПАЦИЕНТА. */
const МЕД_КОНТЕКСТНЫЕ = [
  /дефицит[а-яё]*\s+(?:у\s+вас|ваш)/i,
  /у\s+вас\s+(?:дефицит|воспален)/i,
  /ваш[её]?\s+воспален/i,
  /(?:ваш|у вас)[^.]{0,30}анеми/i,
];

/** §3.4 — ложные гарантии. */
const ГАРАНТИИ = [
  'гарантированно', 'доказано', 'клинически подтверждено', 'вылечит', 'навсегда', '100%',
  'guaranteed', 'proven', 'clinically proven', 'permanently',
];

/** Причинный язык: разрешено «связано с», запрещено «вызывает/лечит/нормализует». */
const ПРИЧИННЫЕ = [
  'вызывает', 'излечивает', 'нормализует', 'устраняет причину',
  'caused by', 'improves', 'treats', 'normalizes', 'fixes',
];

/** §3.3 — названия болезней как МИШЕНЬ рекомендации. */
const БОЛЕЗНИ = [
  'диабет', 'гипертон', 'хбп', 'хсн', 'ибс', 'астма', 'хобл', 'цирроз', 'анеми',
  'гипотиреоз', 'гипертиреоз', 'депресси', 'остеопороз', 'артрит', 'подагр',
  'diabetes', 'hypertension', 'ckd', 'copd', 'asthma', 'depression', 'arthritis',
];

/** Rx-препараты и глаголы управления лекарством — §3.2 и ШАГ 2. */
const RX = [
  'метформин', 'берберин(?=\\s*\\d)', 'левотироксин', 'варфарин', 'статин', 'аторвастатин',
  'семаглутид', 'оземпик', 'тирзепатид', 'инсулин', 'преднизолон', 'амлодипин',
  'metformin', 'levothyroxine', 'warfarin', 'statin', 'semaglutide', 'insulin',
];
const RX_ГЛАГОЛЫ = [
  'отменит', 'отмени', 'снизьте дозу', 'снизить дозу', 'увеличьте дозу',
  'увеличить дозу', 'заменить препарат', 'замените препарат',
  'stop taking', 'reduce the dose', 'increase the dose', 'switch medication',
];

/**
 * ⚠ КИРИЛЛИЦА. В JavaScript \w и \b работают только по ASCII даже с /u —
 * ровно об эту грабли предупреждает и сам документ врача. Поэтому никаких
 * \b: используется поиск подстроки по приведённому к нижнему регистру тексту.
 */
function содержит(текст: string, слова: string[]): string | null {
  const t = String(текст || '').toLowerCase();
  for (const с of слова) {
    if (с.indexOf('(?=') >= 0) {
      if (new RegExp(с, 'i').test(t)) return с;
    } else if (t.indexOf(с.toLowerCase()) >= 0) return с;
  }
  return null;
}

// ─── КОДЫ ЭСКАЛАЦИИ (§4 документа, дословно, три языка) ─────────────

export const ЭСКАЛАЦИИ: Record<string, { ru: string; en: string; he: string }> = {
  ESC_GENERAL: {
    ru: 'Это стоит обсудить с вашим врачом.',
    en: 'This one is worth discussing with your doctor.',
    he: 'את זה כדאי לדון עם הרופא שלך.',
  },
  ESC_MEDS: {
    ru: 'Ваши препараты могут взаимодействовать с добавками — уточните у врача или фармацевта перед началом приёма.',
    en: 'Your current medication may interact with supplements — check with your doctor or pharmacist before adding anything.',
    he: 'התרופות שלך עלולות להשפיע על תוספים — כדאי להתייעץ עם רופא או רוקח לפני הוספת משהו.',
  },
  ESC_CONDITION: {
    ru: 'С учётом того, что вы сообщили о здоровье, оставим это общим — врач сможет подобрать точнее.',
    en: "Because of what you told us about your health, we'll keep this general — your doctor can tailor it.",
    he: 'בהתאם למה שסיפרת על מצבך, נשאיר את זה כללי — הרופא שלך יוכל להתאים.',
  },
  ESC_PREGNANCY: {
    ru: 'При беременности и кормлении добавки — только через врача или акушерку.',
    en: 'During pregnancy or breastfeeding, supplements should come from your doctor or midwife.',
    he: 'בהיריון או בהנקה — תוספים רק דרך הרופא או המיילדת.',
  },
  ESC_URGENT: {
    ru: 'Обратитесь к врачу, прежде чем продолжать. При сильных или внезапных симптомах — экстренная помощь.',
    en: 'Please see a doctor before continuing. If symptoms are severe or sudden, seek emergency care now.',
    he: 'כדאי לפנות לרופא לפני שממשיכים. אם התסמינים חזקים או פתאומיים — פנה למיון עכשיו.',
  },
  /**
   * ⭐⭐ ВОПРОС, А НЕ ОТКАЗ. Задаётся ДО выдачи, нейтрально, без объяснения
   * медицинской причины — ровно как остальные строки эскалации.
   */
  ASK_PREGNANCY: {
    ru: 'Прежде чем что-то предлагать: возможна ли сейчас беременность? От ответа зависит, что мы можем посоветовать.',
    en: 'Before we suggest anything: could you be pregnant right now? The answer changes what we can offer.',
    he: 'לפני שנציע משהו: יש אפשרות שאת בהיריון כרגע? התשובה משנה את מה שנוכל להציע.',
  },
  ESC_CRISIS: {
    ru: 'Если у вас есть мысли причинить себе вред, не оставайтесь с этим один на один. В Израиле: ער"ן 1201, круглосуточно. При непосредственной опасности — 101.',
    en: "If you're having thoughts of harming yourself, you don't have to handle it alone. In Israel: ER\"AN 1201, available 24/7. If you're in immediate danger, call 101.",
    he: 'אם יש לך מחשבות לפגוע בעצמך, אינך צריך להתמודד לבד. בישראל: ער"ן 1201, זמין 24/7. אם אתה בסכנה מיידית — חייג 101.',
  },
};

/**
 * ⛔ ПРАВИЛО ЭСКАЛАЦИИ: причина НЕ называется.
 * Нельзя «из-за вашего диабета…», «при вашей ХБП…» — только «с учётом того,
 * что вы сообщили». Текст берётся из таблицы выше и никогда не собирается
 * из данных пациента.
 */
export function ogEscalation(код: string): { code: string; текст: { ru: string; en: string; he: string } } {
  return { code: код, текст: ЭСКАЛАЦИИ[код] || ЭСКАЛАЦИИ.ESC_GENERAL };
}

/**
 * ⭐⭐ ОДНА СТРОКА ЧЕРЕЗ ФИЛЬТР. Семь шагов в порядке из документа.
 * Возвращает решение и правило, по которому оно принято, — для журнала.
 */
export function ogItem(item: Действие, ctx: КонтекстФильтра): {
  decision: Решение; rule: string; escalationCode: string | null;
} {
  const флаги = ctx.флаги ?? computeRedFlags(ctx);

  // ШАГ 0 — КРИЗИС-ГЕЙТ. Весь вывод заменяется кризисным экраном.
  if (флаги.кризис) return { decision: 'drop', rule: 'step0_crisis', escalationCode: 'ESC_CRISIS' };

  // ШАГ 1 — КАТЕГОРИЯ (whitelist).
  if (БЕЛЫЙ_СПИСОК.indexOf(item.category as Категория) < 0) {
    return { decision: 'drop', rule: 'step1_category', escalationCode: null };
  }

  const текст = [item.action, item.detail].filter(Boolean).join(' · ');

  // ШАГ 2 — RX-ЗАПРЕТ. Только DROP, никогда escalate: не намекаем.
  if (содержит(текст, RX) || содержит(текст, RX_ГЛАГОЛЫ)) {
    return { decision: 'drop', rule: 'step2_rx', escalationCode: null };
  }
  // болезнь как МИШЕНЬ действия — туда же
  if (содержит(текст, БОЛЕЗНИ)) {
    return { decision: 'drop', rule: 'step2_disease_target', escalationCode: null };
  }

  // ШАГ 3 — ТЕСТ НЕЗАВИСИМОСТИ ОТ БОЛЕЗНИ.
  // ⛔ fail-closed: поле не задано → считаем, что независимость НЕ доказана.
  if (item.disease_independent !== true) {
    return { decision: 'escalate', rule: 'step3_disease_dependent', escalationCode: 'ESC_CONDITION' };
  }

  // ШАГ 4 — ФЛАГИ БЕЗОПАСНОСТИ.
  if (!флаги.планРазрешён) {
    return { decision: 'drop', rule: 'step4_hard_stop', escalationCode: 'ESC_URGENT' };
  }
  if (флаги.толькоУниверсальный && universalSet().indexOf(item.action) < 0) {
    return { decision: 'drop', rule: 'step4_soft_stop', escalationCode: null };
  }
  if (item.category === 'supplement_otc') {
    if (ctx.pregnancy === true || ctx.lactation === true) {
      return { decision: 'escalate', rule: 'step4_pregnancy', escalationCode: 'ESC_PREGNANCY' };
    }
    if (флаги.добавкиЗапрещены) {
      return { decision: 'escalate', rule: 'step4_flagE', escalationCode: 'ESC_MEDS' };
    }
    // ⭐ §4O БЕЛЫЙ СПИСОК ДОБАВОК. Добавки, которой нет в списке, наружу нет —
    // даже если движок её предложил. И у каждой свои противопоказания:
    // мембрана подбирает вещество, но ни одна мембрана не отменяет риск
    // кровотечения на гинкго или абортивное действие ашваганды.
    const s = suppCheck(item.action, ctx as any);
    if (s.решение === 'drop') return { decision: 'drop', rule: 'step4_supp_not_allowed', escalationCode: null };
    // ⭐⭐ ВОПРОС О БЕРЕМЕННОСТИ ИДЁТ ПЕРЕД НАЗНАЧЕНИЕМ.
    // Пока нет ответа — позиция не выдаётся, но и не отбрасывается навсегда:
    // ответ «нет» её вернёт. Это принципиально иное поведение, чем отказ.
    if (s.решение === 'ask') {
      return { decision: 'ask', rule: 'step4_pregnancy_unknown', escalationCode: 'ASK_PREGNANCY' };
    }
    if (s.решение === 'escalate') {
      return { decision: 'escalate', rule: 'step4_supp_caution', escalationCode: s.эскалация || 'ESC_CONDITION' };
    }
  }
  // Защитный учёт болезней (спецификация облака §3.2): ограничение не объясняется.
  const защита = защитныеПравила(item, ctx);
  if (защита) return { decision: 'escalate', rule: защита, escalationCode: 'ESC_CONDITION' };

  // ШАГ 5 — ЛЕКСИКА. Страж + медицинские + гарантии + причинные.
  if (!guardCheck(текст).clean) {
    return { decision: 'drop', rule: 'step5_lexicon_guard', escalationCode: null };
  }
  if (содержит(текст, МЕДИЦИНСКИЕ) || МЕД_КОНТЕКСТНЫЕ.some((r) => r.test(текст))) {
    return { decision: 'drop', rule: 'step5_lexicon_medical', escalationCode: null };
  }
  if (содержит(текст, ГАРАНТИИ)) {
    return { decision: 'drop', rule: 'step5_lexicon_guarantee', escalationCode: null };
  }
  if (содержит(текст, ПРИЧИННЫЕ)) {
    return { decision: 'drop', rule: 'step5_lexicon_causal', escalationCode: null };
  }

  return { decision: 'pass', rule: 'pass', escalationCode: null };
}

/**
 * Защитный учёт болезней — НЕ наступательный (спецификация облака §3.2).
 * Диагнозы нужны, чтобы не дать вредного совета, а не чтобы лечить.
 */
function защитныеПравила(item: Действие, ctx: КонтекстФильтра): string | null {
  const диагнозы = (ctx.diagnoses ?? []).join(' ').toLowerCase();
  const текст = [item.action, item.detail].filter(Boolean).join(' ').toLowerCase();
  const препараты = (ctx.medications ?? []).join(' ').toLowerCase();

  // ХБП → не высокий белок
  if (/хбп|ckd|почечн|нефропат/.test(диагнозы) && /белок|протеин|protein/.test(текст)) {
    return 'guard_ckd_protein';
  }
  // ХСН / ХБП → не наращивать воду
  if (/хсн|сердечная недостаточность|хбп|ckd/.test(диагнозы) && item.category === 'hydration') {
    return 'guard_fluid_restriction';
  }
  // низкий ферритин → не интервальное голодание
  if (typeof (ctx.labs || {}).ферритин === 'number' && (ctx.labs as any).ферритин < 30
    && /голодан|fasting|окно питания|интервальн/.test(текст)) {
    return 'guard_low_ferritin_fasting';
  }
  if (typeof (ctx.labs || {}).ferritin === 'number' && (ctx.labs as any).ferritin < 30
    && /голодан|fasting|окно питания|интервальн/.test(текст)) {
    return 'guard_low_ferritin_fasting';
  }
  // тяжёлая астма/ХОБЛ в обострении → дыхательные практики через врача
  if (/хобл|астма.*обостр|обостр.*астма/.test(диагнозы) && item.category === 'breathing') {
    return 'guard_airway';
  }
  // GLP-1 → сам по себе не запрет, но добавки только через врача
  if (/glp-?1|оземпик|ozempic|семаглутид|тирзепатид|mounjaro/.test(препараты)
    && item.category === 'supplement_otc') {
    return 'guard_glp1_supplements';
  }
  return null;
}

/**
 * ⭐⭐⭐ ВЕСЬ ПЛАН ЧЕРЕЗ ФИЛЬТР. Это точка, которую зовёт кабинет
 * перед тем, как отдать что-либо сайту.
 */
export function ogFilterPlan(план: Действие[], ctx: КонтекстФильтра): РезультатФильтра {
  const флаги = ctx.флаги ?? computeRedFlags(ctx);
  const журнал: ЗаписьЖурнала[] = [];
  const наружу: Array<{ action: string; category: string; detail?: string }> = [];
  const эскалации: Array<{ code: string; текст: { ru: string; en: string; he: string } }> = [];
  const вопросы: Array<{ code: string; текст: { ru: string; en: string; he: string } }> = [];
  const виденыЭск = new Set<string>();
  const виденыВопр = new Set<string>();

  // ⛔ КРИЗИС — всё заменяется одним экраном. Ничего другого не показывается.
  if (флаги.кризис) {
    for (const it of план) {
      журнал.push({
        itemId: it.action, decision: 'drop', rule: 'step0_crisis',
        category: it.category, escalationCode: 'ESC_CRISIS',
        engineSource: it.engineSource || 'unknown',
      });
    }
    return {
      наружу: [], эскалации: [ogEscalation('ESC_CRISIS')], вопросы: [], кризис: true,
      планРазрешён: false, журнал, отсеяно: план.length,
    };
  }

  for (const it of план) {
    const r = ogItem(it, { ...ctx, флаги });
    журнал.push({
      itemId: it.action, decision: r.decision, rule: r.rule,
      category: it.category, escalationCode: r.escalationCode,
      engineSource: it.engineSource || 'unknown',
    });
    if (r.decision === 'pass') {
      if (наружу.length < МАКСИМУМ_ДЕЙСТВИЙ) наружу.push({ action: it.action, category: it.category, detail: it.detail });
    } else if (r.decision === 'ask' && r.escalationCode) {
      if (!виденыВопр.has(r.escalationCode)) {
        виденыВопр.add(r.escalationCode);
        вопросы.push(ogEscalation(r.escalationCode));
      }
    } else if (r.decision === 'escalate' && r.escalationCode) {
      if (!виденыЭск.has(r.escalationCode)) {
        виденыЭск.add(r.escalationCode);
        эскалации.push(ogEscalation(r.escalationCode));
      }
    }
  }

  // Жёсткий стоп: плана нет, но человеку говорится, что делать.
  if (!флаги.планРазрешён && !виденыЭск.has('ESC_URGENT')) {
    эскалации.unshift(ogEscalation('ESC_URGENT'));
  }

  return {
    наружу, эскалации, вопросы, кризис: false,
    планРазрешён: флаги.планРазрешён,
    журнал,
    отсеяно: журнал.filter((z) => z.decision !== 'pass').length,
  };
}

/**
 * ⚠ ФИЛЬТР ПРИМЕНЯЕТСЯ И К СВОБОДНОМУ ТЕКСТУ (§8 документа врача:
 * «если где-то появится генерация текста моделью, фильтр должен
 * применяться и к ней — иначе весь контур обходится одним полем»).
 */
export function ogFreeText(текст: string): { ok: boolean; причина: string | null } {
  if (!guardCheck(текст).clean) return { ok: false, причина: 'внутренний слой' };
  const м = содержит(текст, МЕДИЦИНСКИЕ);
  if (м) return { ok: false, причина: `медицинское утверждение: «${м}»` };
  const г = содержит(текст, ГАРАНТИИ);
  if (г) return { ok: false, причина: `ложная гарантия: «${г}»` };
  const п = содержит(текст, ПРИЧИННЫЕ);
  if (п) return { ok: false, причина: `причинный язык: «${п}»` };
  const б = содержит(текст, БОЛЕЗНИ);
  if (б) return { ok: false, причина: `название болезни: «${б}»` };
  const rx = содержит(текст, RX) || содержит(текст, RX_ГЛАГОЛЫ);
  if (rx) return { ok: false, причина: `лекарство или доза: «${rx}»` };
  return { ok: true, причина: null };
}

/** Метрика здоровья фильтра (§7 документа): доля DROP по лексике → к нулю. */
export function ogLexiconLeakRate(журнал: ЗаписьЖурнала[]): number {
  if (!журнал.length) return 0;
  return журнал.filter((z) => z.rule.indexOf('step5_lexicon') === 0).length / журнал.length;
}

export function ogSummary(): string {
  return [
    'ФИЛЬТР ВЫХОДА (§4N) — граница «медицина / образ жизни»',
    `  разрешено категорий: ${БЕЛЫЙ_СПИСОК.length} · наружу максимум ${МАКСИМУМ_ДЕЙСТВИЙ} действия`,
    '  семь шагов: кризис → категория → Rx → независимость от болезни → флаги → лексика → объём',
    '  ⛔ fail-closed: не смог решить — не выводим',
    '  ⛔ причина эскалации НЕ называется («с учётом того, что вы сообщили»)',
  ].join('\n');
}
