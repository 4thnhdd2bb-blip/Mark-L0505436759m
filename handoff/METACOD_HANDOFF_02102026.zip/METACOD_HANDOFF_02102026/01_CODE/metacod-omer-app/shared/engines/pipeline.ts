// METACOD-Omer · shared/engines/pipeline.ts
// ОРКЕСТРАТОР 13-шагового разбора (активатор «анализ»).
// Возвращает два слоя: internalL1 (Литваку) + conventional (наружу через страж).

import type { PatientInput, AnalysisResult, Energy, SymptomBreakdown } from '../types';
import { typeMembrane } from './membraneEngine';
import { solGelOfMembrane } from './solGel';
import { buildPhaseJourney } from './phaseEngine';
import { runDiagnosisAlgorithm } from './diagnosisAlgorithm';
import { buildConventional, ConclusionInput } from './report';
import { enforceRegulation } from './protocol';
import { chronoBuildLayer } from './chronoLayer';
import dxOrgans from '../data/dx_organs.json';

/** Правила подбора признак → энергия/орган (Часть IV Главной книги). */
const LAB_ENERGY: Record<string, { energy: Energy; organ: string }> = {
  креатинин: { energy: 'Холод', organ: 'Почки' },
  ттг: { energy: 'Холод', organ: 'Тройной обогреватель' },
  сахар: { energy: 'Влажность', organ: 'Поджелудочная' },
  глюкоза: { energy: 'Влажность', organ: 'Поджелудочная' },
  срб: { energy: 'Жар', organ: 'воспаление' },
  алт: { energy: 'Тепло', organ: 'Печень' },
};

function organByEnergy(energy: Energy): string {
  const row = (dxOrgans as unknown as [string, string, string][]).find((r) => r[1] === energy);
  return row ? row[0] : '—';
}

/**
 * Главная функция кабинета. Внимание: клиническую интерпретацию 3D
 * даёт разбирающий (см. ARCHITECTURE.md, §1 «каждый параметр»);
 * здесь — детерминированный каркас пайплайна.
 */
export function runAnalysis(p: PatientInput): AnalysisResult {
  // Шаг 2–3: энергии (упрощённо — из доминант, задаваемых интерпретатором 3D/жалоб)
  const dominant: Energy[] = deriveDominant(p);

  // Шаг 5: орган×энергия → карта симптомов
  const organMap: SymptomBreakdown[] = p.complaints.map((s) => ({
    symptom: s,
    organ: organByEnergy(dominant[0] ?? 'Тепло'),
    energy: dominant,
    solGel: 'золь',
    membrane: null,
    differential: [],
    confirmTest: 'по правилу подбора (см. §5)',
  }));

  // Шаг 6: мембрана до подтипа
  const mem = typeMembrane({
    urinePHplateau: p.devices3D?.urinePH4 ? (avg(p.devices3D.urinePH4) < 6 ? 'закисленное' : 'щелочное') : undefined,
    phaseAngle: p.devices3D?.phaseAngle,
    hsCRP: num(p.labs['hsCRP'] ?? p.labs['СРБ']),
    ferritin: num(p.labs['ферритин'] ?? p.labs['ferritin']),
    tgHdl: ratio(p.labs['ТГ'], p.labs['ЛПВП']),
  });

  // Шаг 8–9: золь/гель + фазовая дорога (лечение меняется по фазам)
  const solGel = solGelOfMembrane(mem.membrane);
  const journey = buildPhaseJourney(dominant);

  const phase = journey.steps.find((s) => s.membrane === mem.membrane)?.phase ?? 'CA';
  const hangingPoint = journey.hanging.boundary + (journey.hanging.collapsed ? ' (дуга схлопнута)' : '');

  // §2H: трасса алгоритма диагноза (мембрана-первой), объединяющая Excel-таблицы с разбором.
  const diagnosisTrace = runDiagnosisAlgorithm(p, {
    dominantEnergies: dominant,
    membrane: mem.membrane,
    phase,
    hangingPoint,
  });

  const internalL1: AnalysisResult['internalL1'] = {
    dominantEnergies: dominant,
    membrane: mem.membrane,
    solGelVector: solGel,
    phase,
    hangingPoint,
    organMap,
    phaseJourney: journey.steps,
    diagnosisTrace,
    // ⭐ §4K хроно-слой. АДДИТИВНЫЙ: нет биосигнала → статус «нет данных»,
    // разбор при этом идёт ровно как раньше. Гейт выпуска слой не закрывает.
    хроноСлой: chronoBuildLayer(p.chrono as any),
  };

  // Шаг 11–13: конвенциональный вывод.
  //
  // ⛔⛔ РЕМОНТ 28.09.2026. Здесь стоял КАРКАС с текстом «заполняется разбором
  // конкретного случая» и «итог по эталонному стандарту». Формально он был помечен
  // как каркас, и гейт выпуска его заваливал. Но живой прогон показал, чем это
  // опасно: структура с правильными именами полей и деловым текстом ЧИТАЕТСЯ КАК
  // РАЗБОР. Пустой разбор, помеченный как разбор, опаснее отказа — отказ видно,
  // а каркас выглядит результатом.
  //
  // Теперь запасной путь ГОВОРИТ ПРЯМО, что разбора нет. Текст написан так, чтобы
  // он оставался верным даже если утечёт мимо всех гейтов.
  //
  // ⭐ «Не пропустить» остаётся: эти три линии не зависят от разбора и опаснее
  // всего именно тогда, когда разбор не состоялся.
  const conclusion: ConclusionInput = {
    logic: '⛔ РАЗБОР НЕ ВЫПОЛНЕН. Это запасной путь: модель недоступна, и клинического '
      + 'разбора не проводилось. Ни одна строка ниже не является заключением. '
      + 'Обратитесь к лечащему врачу.',
    hypotheses: [],
    cannotMiss: ['тромбоз/ТЭЛА', 'воспаление/миоперикардит', 'ишемия'],
    workup: { step1_history: [], step2_labs: [], step3_imaging: [], step4_referrals: [] },
    redFlags: [],
    summary: '⛔ Заключения нет. Выполнена только техническая разметка внутреннего слоя; '
      + 'она не заменяет разбор и наружу не выходит. validated:false.',
  };

  // §2S: регламент разбора применяется ВСЕГДА, на выходе пайплайна — не по запросу.
  // Каркас без клинического наполнения гейт обязан завалить: это норма, а не сбой.
  return enforceRegulation(p, { internalL1, conventional: buildConventional(conclusion) });
}

// ── helpers ──────────────────────────────────────────────
function num(v: unknown): number | undefined { const n = Number(v); return isNaN(n) ? undefined : n; }
function ratio(a: unknown, b: unknown): number | undefined { const x = Number(a), y = Number(b); return x && y ? x / y : undefined; }
function avg(a: number[]): number { return a.reduce((s, x) => s + x, 0) / a.length; }

/** Доминантные энергии: из явно заданных 3D-осей или из лаб-правил. Интерпретатор уточняет. */
function deriveDominant(p: PatientInput): Energy[] {
  const acc = new Set<Energy>();
  for (const k of Object.keys(p.labs)) {
    const rule = LAB_ENERGY[k.toLowerCase()];
    if (rule) acc.add(rule.energy);
  }
  if (p.devices3D?.acidBase?.ipH && p.devices3D.acidBase.ipH < 7.29) acc.add('Жар'); // ацидоз/оксидатив
  return acc.size ? [...acc] : ['Тепло'];
}
