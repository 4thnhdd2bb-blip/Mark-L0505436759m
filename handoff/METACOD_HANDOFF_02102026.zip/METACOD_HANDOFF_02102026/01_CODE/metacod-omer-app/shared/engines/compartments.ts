// METACOD-Omer · shared/engines/compartments.ts
// §2N — ДВУХУРОВНЕВАЯ МЕМБРАНА: СИСТЕМА × ОРГАН (слой компартментов).
//
// Мембрана перестаёт быть скаляром. Читается на двух уровнях:
//   СИСТЕМА (всё тело) → ФОН: общий вектор + HARD-STOP + безопасность;
//   ОРГАН (компартмент) → ТОЧКА приложения: чем лечить конкретную ткань.
//
// ПРАВИЛО ЛИТВАКА при конфликте уровней: система задаёт фон и безопасность, орган лечится
// ТОЧЕЧНО ВНУТРИ этого фона. Нельзя системным вектором сломать орган и нельзя органным —
// сорвать систему.
//
// ИНВАРИАНТ БЕЗОПАСНОСТИ: если ЛЮБОЙ компартмент = M-D2/M-D3, катаболики запрещены ВСЕМУ телу,
// даже когда ведущая системная мембрана M-A или M-S (случай Efi: сердце M-S, периферия M-D).
//
// Слой ВНУТРЕННИЙ (L1). validated:false. Дозы — ориентир; финал, красные флаги и онкология —
// за подписывающим врачом.

import type { PatientInput, Membrane, SolGel } from '../types';
import canon from '../data/diagnosis_algorithm_canon.json';
import { solGelOfMembrane } from './solGel';

const TWO = ((canon as any)['двухуровневая_мембрана'] ?? {}) as Record<string, any>;
const MATRIX = ((TWO['матрица'] ?? []) as Array<Record<string, string>>);

export type Pole = 'M-A' | 'M-D' | 'M-S' | 'M-0';
export type Level = 'организм' | 'орган' | 'кость' | 'очаг' | 'клетка' | 'барьер';

export interface CompartmentMembrane {
  level: Level;
  target?: string;                 // 'сердце', 'мышца', 'β-клетка', 'бедренная кость'…
  membrane: Membrane;
  pole: Pole;
  solGel: SolGel;
  vector: string;
  leading: boolean;                // ведущий компартмент (даёт заголовок разбора)
  why: string;                     // по каким данным
}

export interface MatrixCell {
  id: string; organ: Pole; system: Pole;
  relation: 'согласие' | 'конфликт';
  scenario: string; background: string; organTreatment: string; hardStop: string;
  hardStopSource?: string;   // 'Excel Matrica9' | 'производное (в Excel HARD-STOP пуст)'
}

export interface CompartmentPlan {
  organ: string;
  cell: MatrixCell;
  action: string;                  // что делаем с органом ВНУТРИ фона
}

export interface CompartmentAssessment {
  systemic: CompartmentMembrane;              // фон
  compartments: CompartmentMembrane[];        // включая системный (первым)
  background: string;                         // фон-вектор словами
  plans: CompartmentPlan[];                   // орган точечно внутри фона
  conflicts: string[];                        // где уровни разошлись
  cataBodywide: boolean;                      // инвариант: катаболики запрещены всему телу
  safetyNote?: string;
  needsMoreData: string[];
}

// ── полюс мембраны ──────────────────────────────────────────────────
export function poleOf(m: Membrane): Pole {
  if (m === 'M-S') return 'M-S';
  if (m.startsWith('M-D')) return 'M-D';
  if (m.startsWith('M-A')) return 'M-A';
  return 'M-0';
}

const vectorOfPole = (p: Pole): string =>
  p === 'M-D' ? 'анаболик / наполнять' :
  p === 'M-A' ? 'контролируемый катаболик / гасить' :
  p === 'M-S' ? 'антифиброз' : 'удержание баланса';

// ── клетка матрицы ──────────────────────────────────────────────────
export function matrixCell(organ: Pole, system: Pole): MatrixCell | undefined {
  const o = organ === 'M-0' ? 'M-A' : organ;      // M-0 органа читается по фону, берём ближайшую клетку
  const s = system === 'M-0' ? 'M-A' : system;
  const r = MATRIX.find((x) => x['орган'] === o && x['система'] === s);
  if (!r) return undefined;
  return {
    id: r['id'], organ: o as Pole, system: s as Pole,
    relation: (r['отношение'] === 'согласие' ? 'согласие' : 'конфликт'),
    scenario: r['сценарий'], background: r['фон'], organTreatment: r['орган_лечение'], hardStop: r['hardStop'],
    hardStopSource: r['источник_hardStop'],
  };
}
export const MATRIX_CELLS: MatrixCell[] = MATRIX.map((r) => ({
  id: r['id'], organ: r['орган'] as Pole, system: r['система'] as Pole,
  relation: (r['отношение'] === 'согласие' ? 'согласие' : 'конфликт'),
  scenario: r['сценарий'], background: r['фон'], organTreatment: r['орган_лечение'], hardStop: r['hardStop'],
  hardStopSource: r['источник_hardStop'],
}));

// ── распознавание органных компартментов по данным ──────────────────
const num = (v: unknown): number | undefined => {
  if (typeof v === 'number') return v;
  if (typeof v === 'string') { const m = v.replace(',', '.').match(/-?\d+(\.\d+)?/); if (m) return parseFloat(m[0]); }
  return undefined;
};
const lab = (p: PatientInput, re: RegExp): number | undefined => {
  for (const k of Object.keys(p.labs ?? {})) if (re.test(k)) { const n = num((p.labs as any)[k]); if (n !== undefined) return n; }
  return undefined;
};

interface OrganRule { re: RegExp; level: Level; target: string; membrane: Membrane; vector: string; why: string; }

const ORGAN_RULES: OrganRule[] = [
  // ── барьерные компартменты (добавлены разбором 23ж/СД1: слизистой в матрице не было вовсе) ──
  { re: /ротоглотк|глотк|стоматит|афт|налёт|налет|экссудат|глоссит|кандидоз|фарингит|тонзилл|поражени[а-яё]*\s*слизист|язв[а-яё]*\s*слизист/i,
    level: 'барьер', target: 'слизистая рта и глотки', membrane: 'M-A1',
    vector: 'МЕСТНО разгелить застой: санация + этиотропное ПО МАЗКУ; барьер восстановить, не подавлять. ⛔ топический стероид до мазка — при грибковой составляющей усилит очаг',
    why: 'стоячее накопление на слизистой — локальный гель на фоне утраченной барьерной защиты' },
  { re: /ипп|омепраз|пантопраз|эзомепраз|рабепраз|лансопраз|кислотосупресс|h2-?блокатор|ранитидин|фамотидин/i,
    level: 'барьер', target: 'кислотный барьер желудка', membrane: 'M-D1',
    vector: 'СНЯТЬ ятрогенное осушение барьера СТУПЕНЧАТО (рикошет 2–4 нед); проверить, нужна ли кислотосупрессия вообще (pH-импедансометрия вне терапии)',
    why: 'кислота — часть антимикробной защиты верхних отделов; при подавлении барьер в дефиците, а видимая мишень («кислотность») лечится дальше' },
  { re: /щитовидн|тиреоид|гипотиреоз|ттг|левотироксин|хашимото|аит/i,
    level: 'орган', target: 'щитовидная железа', membrane: 'M-D1',
    vector: 'КОРЕНЬ: оптимизировать тиреоид (левотироксин, у пожилых старт малой дозой и медленная титрация по свТ4) — защита уйдёт сама. ⛔ до старта исключить надпочечниковую недостаточность',
    why: 'Холод-двигатель: тиреоидная ось задаёт общий обмен, остальные компартменты вторичны к ней' },
  { re: /болезн[а-яё]*\s*почек|почечн[а-яё]*\s*недостаточн|хбп|скф|егфр|egfr|нефропат/i,
    level: 'орган', target: 'почки', membrane: 'M-S',
    vector: 'ренопротекция по СКФ; ⛔ НПВС регулярно, ⛔ дозы по СКФ без пересчёта',
    why: 'известная болезнь почек — фильтр для всей схемы' },
  { re: /сд ?2|сахарн[а-яё]* диабет|диабет 2|hba1c|инсулинорезист/i, level: 'орган', target: 'β-клетка', membrane: 'M-S',
    vector: 'ЩАДИТЬ: инкретины защищают; ⛔ сульфонилмочевина/глиниды', why: 'СД2: островок идёт M-S→M-D, его нельзя подстёгивать' },
  { re: /саркопени|потер[а-яё]*\s*вес|кахекси|мышечн[а-яё]* масс|фазовый угол|pa50/i, level: 'орган', target: 'мышца', membrane: 'M-D2',
    vector: 'НАПОЛНЯТЬ: белок + лейцин + силовая + креатин', why: 'признаки истощения мышечного компартмента' },
  { re: /хсн|фв \d|сердечн[а-яё]* недостаточност|фиброз миокард|рубец|постинфаркт/i, level: 'орган', target: 'сердце', membrane: 'M-S',
    vector: 'антифиброз: ARNi + АМКР', why: 'фиброз/рубец миокарда' },
  { re: /стеатоз|масг|mash|жиров[а-яё]* гепатоз|fib-?4/i, level: 'орган', target: 'печень', membrane: 'M-A2',
    vector: 'разгрузить: резметиром по показанию / пиоглитазон осторожно', why: 'метаболическое накопление в печени' },
  { re: /нейропат|онемен|жжение стоп|парестез/i, level: 'клетка', target: 'нерв', membrane: 'M-D1',
    vector: 'субстрат: α-липоевая + B12 + бенфотиамин', why: 'нейропатия — дефицитный компартмент нерва' },
  { re: /хбп|скф|егфр|egfr|нефропат/i, level: 'орган', target: 'почки', membrane: 'M-S',
    vector: 'ренопротекция: RAAS + финеренон, дозы по СКФ', why: 'хроническая болезнь почек — склеротический компонент' },
  { re: /эритроцитоз|гипервязк|полицитем|гематокрит|\bhct\b/i, level: 'орган', target: 'кровь', membrane: 'M-A2',
    vector: 'РАЗГЕЛИТЬ: гидратация, омега-3, флеботомия по решению; ⛔ железо', why: 'кровь в гель-сдвиге' },
  { re: /микседем|плотн[а-яё]*\s*(и|ые)?\s*(холодн[а-яё]*\s*)?отёк|гипотиреоз/i, level: 'орган', target: 'ткань (микседема)', membrane: 'M-A1',
    vector: 'НЕ бить местно: убрать системную причину (тиреоид) — защита уйдёт сама', why: 'локальный гель как защита Холода' },
  { re: /гиперкальциеми|резорбц|птг|остеопороз|перелом/i, level: 'кость', target: 'кость', membrane: 'M-D3',
    vector: 'АРЕСТ резорбции (бисфосфонат/кальцитонин), НЕ кальций', why: 'минерал уходит в раствор — резорбтивный золь' },
  { re: /крон|вzк|язвенн[а-яё]* колит|активн[а-яё]* воспален[а-яё]* кишк/i, level: 'очаг', target: 'кишка', membrane: 'M-A3',
    vector: 'гасить воспаление базисом ВЗК — это источник мальабсорбции', why: 'активный очаг воспаления' },
];

// ── сборка двухуровневой оценки ─────────────────────────────────────
export function assessCompartments(
  p: PatientInput,
  ctx: { systemicMembrane: Membrane; hint?: string },
): CompartmentAssessment {
  // ⚠ текущая схема ВХОДИТ в распознавание: ятрогенный компартмент (снятый барьер, осушение)
  // иначе не виден вовсе — найдено на разборе 23ж/СД1.
  const text = ((p.complaints ?? []).join(' · ') + ' ' + (p.currentDrugs ?? []).join(' · ') + ' ' +
    (ctx.hint ?? '') + ' ' + Object.keys(p.labs ?? {}).join(' ')).toLowerCase();

  const sysPole = poleOf(ctx.systemicMembrane);
  const systemic: CompartmentMembrane = {
    level: 'организм', membrane: ctx.systemicMembrane, pole: sysPole,
    solGel: solGelOfMembrane(ctx.systemicMembrane), vector: vectorOfPole(sysPole),
    leading: true, why: 'системная мембрана разбора — задаёт фон и безопасность',
  };

  const organs: CompartmentMembrane[] = [];
  for (const r of ORGAN_RULES) {
    if (!r.re.test(text)) continue;
    if (organs.some((o) => o.target === r.target)) continue;
    organs.push({
      level: r.level, target: r.target, membrane: r.membrane, pole: poleOf(r.membrane),
      solGel: solGelOfMembrane(r.membrane), vector: r.vector, leading: false, why: r.why,
    });
  }

  // мышца при подтверждённом глубоком катаболизме тела — не дублировать
  const compartments = [systemic, ...organs];

  const plans: CompartmentPlan[] = [];
  const conflicts: string[] = [];
  for (const o of organs) {
    const cell = matrixCell(o.pole, sysPole);
    if (!cell) continue;
    plans.push({ organ: o.target ?? o.level, cell, action: cell.organTreatment });
    if (cell.relation === 'конфликт') {
      conflicts.push(
        `${o.target}: орган ${o.pole} ⇄ тело ${sysPole} (клетка ${cell.id}) — фон остаётся системным, орган лечится точечно внутри него`,
      );
    }
  }

  // ИНВАРИАНТ: любой компартмент M-D2/M-D3 → катаболики запрещены всему телу
  const deep = compartments.find((c) => c.membrane === 'M-D2' || c.membrane === 'M-D3');
  const cataBodywide = !!deep;
  const safetyNote = deep
    ? `компартмент «${deep.target ?? deep.level}» = ${deep.membrane}: катаболики ЗАПРЕЩЕНЫ ВСЕМУ ТЕЛУ, даже при системной ${ctx.systemicMembrane}; локальная разгрузка — только местная, не системным катаболиком`
    : undefined;

  const need: string[] = [];
  if (organs.length === 0) need.push('данные по органам-мишеням (функция, визуализация, орган-специфичные маркёры) — локальные мембраны не определены');
  if (!/фазовый угол|pa50|биоимпеданс/.test(text)) need.push('фазовый угол PA50 (BIA) — уточнить системный полюс');

  const cellSys = matrixCell(sysPole, sysPole);
  return {
    systemic, compartments,
    background: `${vectorOfPole(sysPole)}${cellSys ? ' · фон: ' + cellSys.background : ''}`,
    plans, conflicts, cataBodywide, safetyNote, needsMoreData: need,
  };
}

export const TWO_LEVEL_RULE: string = ((TWO['принцип'] ?? {})['конфликт'] ?? '');
export const TWO_LEVEL_SAFETY: string = TWO['инвариант_безопасности'] ?? '';
export const TWO_LEVEL_ORDER: string[] = (TWO['порядок'] ?? []) as string[];
export const DIAGONAL_RULE: string = TWO['правило_диагонали'] ?? '';
export const MATRIX_VERIFICATION = (TWO['сверка'] ?? {}) as Record<string, string>;
export const TWO_LEVEL_DISEASES = ((TWO['разобранные_болезни'] ?? []) as Array<Record<string, string>>)
  .map((r) => ({ disease: r['болезнь'], system: r['система'], organ: r['орган'], solution: r['решение'] }));
