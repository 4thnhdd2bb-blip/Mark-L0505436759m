// METACOD-Omer · shared/engines/consistency.ts
// §2L — ПОРОГ M-D и СОГЛАСОВАННОСТЬ ВЫВОДА.
//
// Два дешёвых, но критичных слоя:
//   1) mdSubtype() — подтип M-D по ЯВНОМУ порогу. Именно порог, а не drug-логика, включает
//      жёсткий запрет катаболиков. Нет данных → консервативно как M-D2 + запрос данных.
//   2) checkFlagTest() — каждый красный флаг обязан иметь подтверждающий тест в шагах 3–4.
//      Флаг без теста = дефект вывода (у Efi был флаг кровотечения без FIT).
//   + dedupeSteps() — гигиена: слияние дублей по каноническому ключу, запрет строк без основания.
//
// Слой ВНУТРЕННИЙ (L1). validated:false. Дозы/красные флаги/онко — за подписывающим врачом.

import canon from '../data/diagnosis_algorithm_canon.json';

const MD = ((canon as any)['порог_md'] ?? {}) as Record<string, any>;
const FLAG_TEST = ((canon as any)['флаг_тест'] ?? {}) as Record<string, any>;
const FLAG_MAP = ((FLAG_TEST['карта'] ?? []) as Array<Record<string, any>>);

// ── 1. ПОРОГ M-D1 / M-D2 / M-D3 ─────────────────────────────────────
export interface MdInput {
  phaseAngle?: number;     // фазовый угол PA50
  albumin?: number;        // г/л
  weightLossPct?: number;  // % за 6 мес
  sarcopenia?: boolean;    // подтверждённая саркопения / BCM↓
}
export interface MdVerdict {
  subtype: 'M-D1' | 'M-D2' | 'M-D3';
  cata: boolean;           // true → катаболики запрещены, калораж не резать
  why: string[];
  assumed: boolean;        // true = порог не посчитан, взята безопасная сторона
  needsMoreData: string[];
}

export function mdSubtype(i: MdInput): MdVerdict {
  const why: string[] = [];
  const have = [i.phaseAngle, i.albumin, i.weightLossPct, i.sarcopenia].filter((v) => v !== undefined && v !== null).length;

  if (have === 0) {
    return {
      subtype: 'M-D2',
      cata: true,
      why: ['порог не посчитан — взята безопасная сторона (как при M-D2)'],
      assumed: true,
      needsMoreData: (MD['нет_данных']?.['запросить'] ?? ['фазовый угол PA50', 'альбумин', 'динамика веса за 6 мес']) as string[],
    };
  }

  let hits = 0;
  if (i.phaseAngle !== undefined && i.phaseAngle < 5.0) { hits++; why.push(`фазовый угол ${i.phaseAngle} < 5.0`); }
  if (i.weightLossPct !== undefined && i.weightLossPct >= 5) { hits++; why.push(`потеря веса ${i.weightLossPct}% ≥ 5% за 6 мес`); }
  if (i.sarcopenia) { hits++; why.push('подтверждённая саркопения / BCM↓'); }
  if (i.albumin !== undefined && i.albumin < 35) { hits++; why.push(`альбумин ${i.albumin} ниже нормы`); }

  const severe = i.albumin !== undefined && i.albumin < 30;
  if (hits >= 2 && severe) return { subtype: 'M-D3', cata: true, why: [...why, 'альбумин < 30 — явная кахексия'], assumed: false, needsMoreData: [] };
  if (hits >= 2) return { subtype: 'M-D2', cata: true, why, assumed: false, needsMoreData: [] };
  if (hits === 1) {
    // один признак — порог не набран, но и не чист: остаёмся осторожны и просим второй маркёр
    return {
      subtype: 'M-D1', cata: false,
      why: [...why, 'набран один критерий из двух — порог M-D2 не подтверждён'],
      assumed: false,
      needsMoreData: (['фазовый угол PA50', 'альбумин', 'динамика веса за 6 мес'] as string[])
        .filter((n) => (/PA50/.test(n) && i.phaseAngle === undefined) || (/альбумин/.test(n) && i.albumin === undefined) || (/веса/.test(n) && i.weightLossPct === undefined)),
    };
  }
  return { subtype: 'M-D1', cata: false, why: ['критерии M-D2 не набраны'], assumed: false, needsMoreData: [] };
}

export const MD_THRESHOLD_RULE: string = MD['правило'] ?? '';

// ── 2. СОГЛАСОВАННОСТЬ «ФЛАГ → ТЕСТ» ────────────────────────────────
export interface FlagTestGap { flag: string; missing: string[]; }

/**
 * Для каждого красного флага ищет в шагах 3–4 хотя бы один требуемый тест.
 * Возвращает пробелы. Пустой массив = вывод согласован.
 */
export function checkFlagTest(redFlags: string[], stepsLabsAndImaging: string[]): FlagTestGap[] {
  const haystack = (stepsLabsAndImaging ?? []).join(' · ').toLowerCase();
  const gaps: FlagTestGap[] = [];
  for (const flag of redFlags ?? []) {
    const f = flag.toLowerCase();
    for (const row of FLAG_MAP) {
      const trigger = new RegExp(String(row['триггер'] ?? ''), 'i');
      if (!trigger.test(f)) continue;
      const tests = (row['тесты'] ?? []) as string[];
      const covered = tests.some((t) => {
        const key = t.toLowerCase().split(/[\/(+,]/)[0].trim();
        return key.length > 2 && haystack.includes(key);
      });
      if (!covered) gaps.push({ flag, missing: tests });
      break;
    }
  }
  return gaps;
}

export const FLAG_TEST_RULE: string = FLAG_TEST['правило'] ?? '';
export const FLAG_TEST_MAP = FLAG_MAP.map((r) => ({ flag: r['флаг'], trigger: r['триггер'], tests: r['тесты'] }));

// ── 3. ГИГИЕНА ВЫВОДА: дедуп + основание ────────────────────────────
export interface StepItem { text: string; basis?: string[]; key?: string; }

const CANON_KEYS: Array<[RegExp, string]> = [
  [/фгдс|гастроскоп|колоноскоп|эндоскоп/i, 'ФГДС+колоноскопия'],
  [/эхокг|эхо-?кг|эхокардиограф/i, 'ЭхоКГ'],
  [/экг|холтер|электрокардиограф/i, 'ЭКГ'],   // без \b: в JS он не работает с кириллицей
  [/moca|мока|когниц.*baseline/i, 'MoCA'],
  [/nt-?probnp|бнп/i, 'NT-proBNP'],
  [/b12|ммa|гомоцистеин/i, 'B12-панель'],
  [/ферритин|железо-?статус|трансферрин/i, 'железо-статус'],
  [/кетон|гидроксибутират/i, 'кетоны'],
  [/липидограмм|лпнп|apob|lp\(a\)/i, 'липиды'],
  [/c-?пептид|homa/i, 'C-пептид/HOMA'],
  [/pa50|фазовый угол|биоимпеданс/i, 'PA50'],
  [/калий|электролит|магни|натри|(^|[\s(,])k[\s,)]/i, 'электролиты'],
];

export function canonicalKey(text: string): string {
  for (const [re, key] of CANON_KEYS) if (re.test(text)) return key;
  return text.trim().toLowerCase().replace(/\s+/g, ' ').slice(0, 48);
}

/**
 * Слияние дублей (ЭКГ×3, ЭхоКГ×4) + отбрасывание строк без основания.
 * requireBasis=true выбрасывает шаблоны, не подтверждённые входными данными
 * (образец дефекта: «после пластики/протеза…» у пациента без операции).
 */
export function dedupeSteps(items: StepItem[], requireBasis = false): StepItem[] {
  const out = new Map<string, StepItem>();
  const dropped: StepItem[] = [];
  for (const it of items ?? []) {
    if (requireBasis && (!it.basis || it.basis.length === 0)) { dropped.push(it); continue; }
    const key = it.key || canonicalKey(it.text);
    const prev = out.get(key);
    if (!prev) { out.set(key, { ...it, key }); continue; }
    const merged = new Set([...(prev.basis ?? []), ...(it.basis ?? [])]);
    const longer = it.text.length > prev.text.length ? it.text : prev.text;
    out.set(key, { text: longer, basis: Array.from(merged), key });
  }
  return Array.from(out.values());
}

export function droppedWithoutBasis(items: StepItem[]): StepItem[] {
  return (items ?? []).filter((it) => !it.basis || it.basis.length === 0);
}
