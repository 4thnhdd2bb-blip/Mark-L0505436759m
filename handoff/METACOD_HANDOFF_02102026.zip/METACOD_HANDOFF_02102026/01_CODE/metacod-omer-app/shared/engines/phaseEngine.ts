// METACOD-Omer · shared/engines/phaseEngine.ts
// ФАЗОВЫЙ ДВИЖОК: дуга фаз, точка зависания, и ГЛАВНОЕ —
// лечение МЕНЯЕТСЯ по фазам (сшивка фаза×мембрана). Источник: phase_transitions.json.

import type { Energy, Phase, Membrane, PhaseStep, DrugPick } from '../types';
import phaseData from '../data/phase_transitions.json';

export const ARC: { phase: Phase; energy: Energy }[] = [
  { phase: 'CA', energy: 'Холод' },
  { phase: 'PCL-A', energy: 'Влажность' },
  { phase: 'Эпикризис', energy: 'Ветер' },
  { phase: 'PCL-B', energy: 'Сухость' },
  { phase: 'Норматония', energy: 'Тепло' },
];

/** Соответствие фаза → мембрана (Хамер-вектор из монографии). */
export function membraneOfPhase(p: Phase): Membrane | 'переход' {
  switch (p) {
    case 'CA': return 'M-D1';        // катаболизм, активный конфликт
    case 'PCL-A': return 'M-A1';     // анаболизм, экссудация
    case 'Эпикризис': return 'переход';
    case 'PCL-B': return 'M-S';      // консолидация/сухость (M-S/M-A)
    case 'Норматония': return 'M-0';
  }
}

/**
 * Точка зависания: две соседние доминирующие энергии = живая граница.
 * Если доминируют НЕсоседние — дуга «схлопнута», завис на дальней границе.
 */
export function hangingPoint(dominant: Energy[]): { boundary: string; collapsed: boolean; note: string } {
  const order: Energy[] = ['Холод', 'Влажность', 'Ветер', 'Сухость', 'Тепло'];
  const idx = dominant.map((e) => order.indexOf(e)).filter((i) => i >= 0).sort((a, b) => a - b);
  if (idx.length < 2) return { boundary: 'CA↔PCL-A', collapsed: false, note: 'недостаточно доминант — уточнить' };
  const adjacent = idx[idx.length - 1] - idx[0] === 1;
  if (adjacent) {
    return { boundary: `${order[idx[0]]}↔${order[idx[1]]}`, collapsed: false, note: 'соседние энергии — граница зависания прямая' };
  }
  return {
    boundary: `${order[idx[0]]}↔${order[idx[idx.length - 1]]} (дальняя)`,
    collapsed: true,
    note: 'несоседние доминанты → дуга схлопнута; завис на дальней границе, заякорен ранней фазой',
  };
}

const PHASE_VECTOR: Record<Phase, { vector: string; gate: string; changesTo: string; drugs: DrugPick[] }> = {
  'CA': {
    vector: 'анаболический сдвиг: запечатать бислой + согреть-наполнить + субстрат; снять конфликт',
    gate: 'pH мочи↑, фазовый угол↑, MDA↓, K⁺ норм, теплее/бодрее',
    changesTo: 'M-D → M-A: окно анаболиков (PCL-A), фокус «строить субстрат»',
    drugs: [
      { name: 'B12 в/м', jcz: 'Царь', why: 'субстрат/нейро' },
      { name: 'железо (в/в при мальабсорбции)', jcz: 'Министр' },
      { name: 'ацетил-L-карнитин', why: 'термогенез' },
      { name: 'Co-Q10/α-липоевая/тиамин', jcz: 'Помощник' },
    ],
  },
  'PCL-A': {
    vector: 'контролируемый катаболический сдвиг: дренаж избытка, не перекормить анаболизмом',
    gate: 'нет отёка, вес/BNP/креатинин стабильны, воспаление контролируется',
    changesTo: 'вход в короткий Ветер (Эпикризис): стабилизация ритма/спазма',
    drugs: [
      { name: 'мягкий дренаж (низкодоз. диуретик по показанию)', jcz: 'Министр' },
      { name: 'магний', jcz: 'Помощник' },
      { name: 'омега-3', jcz: 'Посол' },
    ],
  },
  'Эпикризис': {
    vector: 'мягкое вегетативное демпфирование, минимум новых вмешательств',
    gate: 'ритм/спазм стабильны, K/Mg норм, ЭКГ спокойна',
    changesTo: 'консолидация (PCL-B): увлажнить + пластический пул + антифиброз',
    drugs: [
      { name: 'магний глицинат/L-треонат', jcz: 'Помощник' },
      { name: 'по органу — антиаритмик/спазмолитик (за кардиологом)', jcz: 'Министр' },
    ],
  },
  'PCL-B': {
    vector: 'увлажнить + пластический пул (коллаген/глицин/пролин) + антифиброз (омега-3); при M-S — 3 столпа',
    gate: 'субстрат восполнен: ферритин>50–70, B12 норма, альбумин норма; масса/сила↑',
    changesTo: 'M-0: удержание, минимальная схема',
    drugs: [
      { name: 'белок+коллаген+лейцин', jcz: 'Министр' },
      { name: 'омега-3 (антифиброз)', jcz: 'Посол' },
      { name: 'вит D3+K2; при показании энзимы (M-S)', jcz: 'Помощник' },
    ],
  },
  'Норматония': {
    vector: 'удержание, минимальная схема, вторичная профилактика',
    gate: 'pH мочи осциллирует, симптомы ушли, анализы стабильны',
    changesTo: '—',
    drugs: [
      { name: 'магний/омега-3/вит D3 поддерживающе', jcz: 'Помощник' },
    ],
  },
};

/** Построить дорогу по фазам: на каждой фазе своя мембрана → свой набор лечения. */
export function buildPhaseJourney(dominant: Energy[]): { hanging: ReturnType<typeof hangingPoint>; steps: PhaseStep[] } {
  const hanging = hangingPoint(dominant);
  const steps: PhaseStep[] = ARC.map(({ phase }) => {
    const v = PHASE_VECTOR[phase];
    return {
      phase,
      membrane: membraneOfPhase(phase),
      vector: v.vector,
      drugs: v.drugs,
      gate: v.gate,
      changesTo: v.changesTo,
      prognosis: (phaseData as any)?.['сроки_переходов']?.[phase] ?? undefined,
    };
  });
  return { hanging, steps };
}

export const PHASE_SOURCE = (phaseData as any)?.['версия'] ?? 'phase_transitions';
