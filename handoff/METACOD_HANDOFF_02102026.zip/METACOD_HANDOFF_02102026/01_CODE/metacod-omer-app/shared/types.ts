// METACOD-Omer · shared/types.ts
// Единые типы кабинета (client + server). Dr. Mark Litvak, MD · validated:false

export type Energy =
  | 'Холод' | 'Влажность' | 'Ветер' | 'Сухость' | 'Тепло' | 'Жар';

export type Phase = 'CA' | 'PCL-A' | 'Эпикризис' | 'PCL-B' | 'Норматония';

export type Membrane =
  | 'M-0'
  | 'M-A1' | 'M-A2' | 'M-A3'
  | 'M-S'
  | 'M-D1' | 'M-D2' | 'M-D3';

export type SolGel = 'золь' | 'гель' | 'баланс';

/** Вход — 3 источника (жалобы / анализы / приборы 3D). */
export interface PatientInput {
  id?: string;
  name?: string;
  age?: number;
  sex?: 'м' | 'ж';
  complaints: string[];              // жалобы, симптом за симптомом
  labs: Record<string, number | string>; // анализы (маркёр -> значение)
  /**
   * ⭐ Р-ХРОНО-1, подписано врачом 19.09.2026. Измеренные ЧСС и ЧД, если врач
   * их ввёл руками. Это ПЕРВЫЙ источник автономного якоря: измеренное число
   * старше выведенного из биосигнала. Не заданы — якорь возьмёт их из хроно-слоя,
   * и только если тот реально посчитан. Нет ни того, ни другого — «нет данных»,
   * и число НЕ выдумывается.
   */
  hr?: number;                       // ЧСС, ударов в минуту
  rr?: number;                       // ЧД, дыханий в минуту
  devices3D?: Device3D;              // EIS / HRV / органные импедансы
  currentDrugs?: string[];           // текущая терапия пациента
  /**
   * ⭐⭐ УЖЕ ПОСТАВЛЕННЫЕ БОЛЕЗНИ БОЛЬНОГО — ЕГО КОМОРБИДНОСТЬ.
   *
   * ⛔⛔ ЗАЧЕМ ПОЛЕ ЗАВЕДЕНО 30.09.2026. Библиотека из 1200 разобранных врачом
   * сочетаний отвечает только на СОЧЕТАНИЕ болезней. До этого дня у больного не
   * было места, куда их вписать: в разбор входили жалобы, анализы и препараты, а
   * диагнозы порождались гипотезами. Подключить библиотеку к пути и не завести
   * это поле значило бы повторить Р-ПРОГОН-1 — слой на пути, до которого не
   * доходит ни один настоящий больной.
   *
   * ⛔ Здесь то, что врач УЖЕ ЗНАЕТ о больном, а не то, что предполагает движок.
   * Гипотезы разбора сюда НЕ попадают.
   */
  diagnoses?: string[];              // поставленные диагнозы (коморбидность)
  /**
   * ⭐ §4Z. Признаки выдачи приказа при нейродегенерации — то, что врач ЗНАЕТ.
   *
   * ⛔⛔ ЗАЧЕМ ПОЛЕ ЗАВЕДЕНО 01.10.2026. Движок §4Z стоял на пути (раздел
   * обогащения), но в PatientInput не было места для его входа, и `cabinetApi`
   * ничего ему не передавал. В живом разборе §4Z ВСЕГДА отвечал «признаки не
   * поданы», а гейт антиамилоида звался с пустым входом. Это Р-ПРОГОН-1 в
   * миниатюре: слой на пути, до которого не доходит ни один больной.
   * Ничего не обязательно; пусто — движок честно говорит «ступень не определена».
   */
  нейро?: ВходНейро;
  goal?: string;                     // цель разбора
  /**
   * ⭐ §4K Биосигнальный блок для хроно-слоя (перенесён 19.09.2026).
   * Опционален: нет блока → хроно-слой не создаётся, разбор идёт как раньше.
   * Тип лежит в engines/chrono/types.ts, здесь — структурно, чтобы не тянуть
   * зависимость движка в общие типы клиента.
   */
  chrono?: {
    fs: number;              // частота дискретизации, Гц
    ecg?: number[];
    ppg?: number[];
    resp?: number[];         // дыхание — обязательно для метрик связности
    beats?: number[];        // R-пики в СЕКУНДАХ, если их даёт сам прибор
    reference?: Record<string, unknown>;
    weights?: Record<string, unknown>;
  };
}

/** §4Z. Вход нейродегенерации: ступень, противовес, гейт антиамилоида. */
export interface ВходНейро {
  'когнитивный_дефицит'?: boolean;
  'MCI_или_SCD'?: boolean;
  CDR?: number;
  'p_tau_217_повышен'?: boolean;
  'метаболический_риск'?: boolean;
  'катаболик_назначается'?: boolean;
  'белок_г_на_кг'?: number;
  'силовые_раз_в_неделю'?: number;
  'BIA_контроль_есть'?: boolean;
  'анти_Тепло_контур_работает'?: boolean;
  'месяцев_на_контуре'?: number;
  'стадия_ранняя_или_MCI'?: boolean;
  'амилоид_подтверждён'?: boolean;
}

/** Приборный слой (EIS/3D/HRV) — ориентир, НЕ диагноз. */
export interface Device3D {
  acidBase?: { ipH?: number; iHCO3?: number; iPCO2?: number; iSBE?: number };
  ionogram?: Record<string, number>;
  oxidative?: Record<string, number>;
  neurotransmitters?: Record<string, number>;
  hormones?: Record<string, number>;
  organImpedance?: Record<string, { iR?: number; iC?: number; atpase?: number; tPO2?: number }>;
  hrv?: Record<string, number>;
  vascular?: Record<string, number>;
  phaseAngle?: number;               // фазовый угол BIA
  urinePH4?: number[];               // 4-точечный pH мочи
}

export interface SymptomBreakdown {
  symptom: string;
  organ: string;
  energy: Energy | Energy[];
  solGel: SolGel;
  membrane: Membrane | null;
  differential: string[];
  confirmTest: string;
}

export interface Hypothesis {
  rank: number;
  root: string;                      // общий корень
  explains: string;                  // «что объясняет сразу»
  confirm: string[];                 // чем подтвердить
}

export interface PhaseStep {
  phase: Phase;
  membrane: Membrane | 'переход';
  vector: string;                    // вектор лечения этой фазы
  drugs: DrugPick[];                 // препараты фазы (по энергии/вектору)
  gate: string;                      // ворота перехода (биомаркеры)
  changesTo?: string;                // что меняется на переходе
  prognosis?: string;
}

export interface DrugPick {
  name: string;
  energy?: string;
  solGel?: string;
  jcz?: 'Царь' | 'Министр' | 'Помощник' | 'Посол';
  brand?: string;
  why?: string;
}

/* ============================================================
   ⭐ ФИЗИОЛОГИЧЕСКАЯ ФАЗОВАЯ МАТРИЦА (фаза принадлежит ПРОЦЕССУ, не пациенту).
   Между предполагаемой фазой и препаратом — измеряемый физиологический уровень.
   ============================================================ */

export type Activity = 0 | 1 | 2 | 3;   // 0 наблюдение · 1 слабый · 2 умеренный · 3 выраженный
export type Trend = 'low' | 'normal' | 'high';

/** 8 осей объективизируемого функционального состояния ткани (§1 модуля). */
export interface OrganState {
  perfusion: Trend;                 // перфузия
  vascularTone: Trend;              // сосудистый тонус (low=вазодилатация, high=вазоконстрикция)
  fluid: Trend;                     // интерстиций: low=дегидратация · high=задержка/отёк
  inflammation: 'none' | 'local' | 'systemic';
  metabolism: 'anabolic' | 'stable' | 'catabolic';
  organFunction: Trend;             // гипер/норма/гипо
  motility?: Trend;                 // ЖКТ
  cellDamage: 'none' | 'reversible' | 'structural';
}

/** Препарат как физиологический ВЕКТОР: основная мишень + побочные векторы. */
export interface DrugVector {
  name: string;
  brand?: string;
  main: string[];                   // основные (полезные) физиологические эффекты
  side: string[];                   // побочные физиологические векторы
  gates?: string[];                 // HARD-STOP/условия
}

/** Строка матрицы — один патологический процесс. */
export interface ProcessRow {
  process: string;                  // патологический процесс/болезнь
  organ: string;
  energy?: Energy | Energy[];
  membrane?: Membrane | 'переход';
  solGel?: SolGel;
  phase: Phase;                     // предполагаемая фаза (внутренняя гипотеза)
  activity: Activity;
  state: OrganState;                // измеряемое функциональное состояние
  markers: string[];                // объективное подтверждение
  risk: string[];                   // red flags процесса
  target: string;                   // терапевтическая мишень
  vector: string;                   // нужное воздействие
  antiVector: string;               // противопоказанное + гейты
  systemicInfluence: -1 | 0 | 1;    // влияние на автономно-метаболический фон
  hangingPoint?: string;
  sbi?: number;                     // нагрузка процесса (Stress Burden Index)
}

/** Терапевтический конфликт: побочный вектор препарата совпадает с направлением патологии. */
export interface TherapeuticConflict {
  process: string;
  drug: string;
  direction: string;                // общее направление (напр. «↓моторика»)
  level: 1 | 2 | 3;                 // 1 наблюдать · 2 доза+компенсатор+мониторинг · 3 Safety Gate
  response: string;                 // рекомендованное действие
  safetyGate?: string[];            // стоп-состояния (для level 3 / проверки)
}

export interface PhaseMatrix {
  processes: ProcessRow[];          // активность ≥1 + объективное подтверждение; 3–6 ведущих
  systemicVector: string;           // результирующий системный вектор
  leadingProcess: string;           // ведущий процесс (max активность×риск)
  conflicts: TherapeuticConflict[];
  plan: { systemic: string; local: string[] };  // системная стабилизация ⊕ органоспецифическая коррекция
  systemicSBI?: number;
}

/* ============================================================
   СЛОЙ АЛГОРИТМА ДИАГНОЗА (§2H) — трасса первичное→вторичное,
   объединяющая Excel-таблицы (Gel-Zol · Общая таблица · 658 · фазы) с разбором.
   ============================================================ */

export type JczRole = 'Государь' | 'Министр' | 'Помощник' | 'Посол';

export interface JczPick {
  role: JczRole;
  item: string;
}

/** Строка Общей таблицы лечения (энергия × орган × мембрана × фаза × магнит × цвет × 658 × JCZ). */
export interface TreatmentRow {
  energy: string;
  organ: string;
  membrane: string;
  phase: string;
  vector: string;
  magnet: string;                    // количество (магнит)
  color: string;                     // качество (цвет Ко-контролёра)
  drugs658: string;                  // препараты-векторы из базы 658
  jcz: string;                       // сырая JCZ-строка
  hardStop: string;
}

export interface DiagnosisStep {
  n: number;                         // 0..5
  key: string;
  name: string;
  layer: string;                     // «ПЕРВИЧНО · безопасность» и т.д.
  decides: string;                   // что решает шаг
  finding: string;                   // вывод шага для ЭТОГО пациента
}

export interface ControlPointStatus {
  id: string;
  text: string;
  status: 'ok' | 'внимание' | '—';
  note?: string;
}

/** Трасса алгоритма диагноза для конкретного разбора. */
export interface DiagnosisTrace {
  order: string;                     // сводка порядка первичное→вторичное
  mantra: string;
  direction: string;                 // катаболик / анаболик / антифиброз / баланс
  steps: DiagnosisStep[];            // 6 стадий (0..5)
  controlPoints: ControlPointStatus[];
  treatmentRow?: TreatmentRow;       // подобранная строка Общей таблицы
  jczLadder: JczPick[];
  hardStops: string[];               // сработавшие HARD-STOP
  conflict?: string;                 // разрешение конфликта мембрана⇄энергия
  substitutions?: SubstitutionNote[]; // §2J.1 — чем закрыть цель, если ход под запретом
  levelRule?: string;                // §2J.1 — гель-золь задаётся на каждом уровне отдельно
  /** §2N — двухуровневая мембрана: система (фон) × орган (точечно) + инвариант безопасности. */
  compartments?: {
    background: string;
    cataBodywide: boolean;
    safetyNote?: string;
    conflicts: string[];
    list: Array<{ level: string; target?: string; membrane: string; pole: string; vector: string; leading: boolean; why: string }>;
    plans: Array<{ organ: string; cellId: string; relation: string; action: string; hardStop: string }>;
    needsMoreData: string[];
  };
  /** §2M — нутрицевтика как часть схемы (детерминированные правила библиотеки по мембране). */
  supplements?: Array<{ item: string; reason: string; step: string; dose?: string; caution?: string }>;
  /** §2M — блок библиотеки лечения по мембране (программа, препараты, цели, мониторинг). */
  library?: { membrane: string; name: string; vector: string; goals: string; monitoring: string; hardStop: string };
  /** §2K — слой фазового перехода: режим, тип люка, гейты can't-miss, страховка от переката. */
  transition?: {
    mode: 'течёт' | 'завис' | 'неизвестно';
    modeWhy: string;
    lock?: { id: string; name: string; firstMove: string; guard: string; heldBy: string[]; confidence: string };
    gates: Array<{ trigger: string; gate: string; rule: string }>;
    guards: Array<{ vector: string; overshoot: string; guard: string }>;
    causeProtection?: string;
    needsMoreData: string[];
  };
}

/** §2J.1 Замена при запрете: HARD-STOP убирает препарат, но НЕ отменяет цель. */
export interface SubstitutionNote {
  banned: string;        // что попало под запрет (из текущей схемы)
  when: string;          // при каком условии запрет действует
  replacement: string;   // чем закрыть ту же цель безопасно
  reason: string;        // почему запрещено
  caveat?: string;       // когда всё же допустимо (явным решением врача)
}

/* ============================================================
   §2S — РЕГЛАМЕНТ РАЗБОРА КАК ЧАСТЬ КАЖДОГО РЕЗУЛЬТАТА.
   Виды (View) объявлены здесь, а не импортированы из protocol.ts, чтобы не было
   кольца импортов; они структурно совместимы с BlockResult/ReleaseVerdict.
   ============================================================ */

export interface RegulationBlockView {
  n: number;
  блок: string;
  статус: string;                    // наполнен | ПУСТ | не требуется
  содержимое: string[];
  чегоНеХватает?: string;
}

/** ⭐ Р-ХРОНО-1, 19.09.2026: автономный якорь как он лёг в разбор. */
export interface AnchorRow {
  hr?: number;
  rr?: number;
  источник: 'измерено врачом' | 'биосигнал (хроно-слой)' | 'нет данных';
  индекс?: number;
  чтение: string;
  красныйФлаг: boolean;
  блокируетВыход: boolean;
  пояснение: string;
  расхождение?: string;
}

export interface RegulationView {
  версия: string;
  блоки: RegulationBlockView[];
  выпуск: {
    выпускать: boolean;
    заполнено: number;
    всего: number;
    пустые: Array<{ n: number; блок: string; чегоНеХватает: string }>;
    вердикт: string;
  };
  антиПаттерны: string[];
  параллельноНеПропустить: string;
}

/** Третья ось в результате разбора: затвор мембраны (§2P), уровень за уровнем. */
export interface GateAxisView {
  state: string;                     // открыт | закрыт | неясно
  primary: string;                   // ЗАТВОР | ФАЗА | нет данных
  levels: Array<{ level: string; action: string; why: string }>;
  vetoes: string[];
  acidBase: string;                  // кислая/щелочная → ход, со сверкой двух чтений
  conflict?: string;                 // уровни требуют противоположного — это норма
  misfit?: string;                   // «помогло и вернулось» НА ФОНЕ воздействия — не та ось
  экспозиция?: string;               // возврат ПОСЛЕ СНЯТИЯ — мала экспозиция, удвоить время
}

/**
 * §2V — ген-слой в результате разбора. Едет ВМЕСТЕ с честностью источника:
 * книга даёт 25 различных ответов, а выглядит как 164 разбора, и разбор обязан
 * нести эти цифры рядом, а не ссылаться на них.
 */
export interface GeneLayerView {
  полюс: {
    полюс?: 'ГЕЛЬ' | 'ЗОЛЬ';
    уровень: 'организм';
    основание: string;
    запретПереноса: string;          // системный полюс НЕ переносится на орган
    ждётПодписи?: string;
  };
  честностьИсточника: {
    вердикт: string;
    болезнейВДокументе: number;
    различныхОтветов: number;
    доказательство: Record<string, number>;
    проверенныеФункции: string[];
    следствие: string;
  };
}

/** Двухслойный результат разбора. */
/**
 * ⭐ §4K Хроно-слой в разборе. Аддитивный и без побочных эффектов:
 * гейт выпуска не закрывает, мембрану/затвор/фазу/цвет не меняет.
 */
export interface ChronoLayerRow {
  статус: 'посчитан' | 'нет данных' | 'недоступен';
  индекс?: number;                 // 0–100, выше = сильнее десинхроноз
  полоса?: 'coherent' | 'mild' | 'moderate' | 'marked';
  вердиктНаружу?: string;          // чистый клинический язык (видит страж)
  кратность?: { отношение: number; k: number; отклонение: number };
  связность?: { m: number; plv: number; lambda: number };
  всрКратко?: { sdnn: number; rmssd: number; lfhf: number };
  flowmotionПосчитан: boolean;
  заметки: string[];
  причина?: string;
  оговорки: string[];
}

export interface AnalysisResult {
  // внутренний L1 — только д-ру Литваку
  internalL1: {
    dominantEnergies: Energy[];
    membrane: Membrane;
    solGelVector: SolGel;
    phase: Phase;
    hangingPoint: string;            // точка зависания
    organMap: SymptomBreakdown[];
    phaseJourney: PhaseStep[];       // фазовое лечение (меняется по фазам)
    phaseMatrix?: PhaseMatrix;       // ⭐ матрица процессов + системный вектор + конфликты
    diagnosisTrace?: DiagnosisTrace; // §2H трасса алгоритма (мембрана→энергия→фаза→658+JCZ→EBM)
    gateAxis?: GateAxisView;         // §2P третья ось — затвор (ставится движком на КАЖДОМ разборе)
    регламент?: RegulationView;      // §2S гейт выпуска (ставится движком на КАЖДОМ разборе)
    диетаХроно?: string[];           // блок 10 регламента — что и КОГДА
    прогноз?: string[];              // блок 11 регламента — что и за сколько
    генСлой?: GeneLayerView;         // §2V ген-слой — навигатор, НЕ источник вектора
    хроноСлой?: ChronoLayerRow;      // §4K хроно-слой — РАННИЙ сигнал рядом, НЕ вместо осей
    якорь?: AnchorRow;               // ⭐ Р-ХРОНО-1 автономный якорь HR/RR: число, источник, стоп
  };
  // конвенционально — наружу (через страж)
  conventional: {
    logic: string;                   // клиническая логика (нарратив)
    hypotheses: Hypothesis[];        // ранжированные
    cannotMiss: string[];            // «не пропустить»
    workup: WorkupPlan;              // полное обследование по шагам
    redFlags: string[];
    summary: string;                 // итог коротко
    guardClean: boolean;             // прошёл ли страж
  };
}

export interface WorkupPlan {
  step1_history: string[];
  step2_labs: string[];
  step3_imaging: string[];
  step4_referrals: string[];
}
