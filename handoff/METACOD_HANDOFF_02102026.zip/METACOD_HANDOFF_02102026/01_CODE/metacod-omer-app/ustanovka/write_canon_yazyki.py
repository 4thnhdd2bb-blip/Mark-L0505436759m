# -*- coding: utf-8 -*-
"""ЯЗЫКИ ВХОДА. Заведено 29.09.2026 по распоряжению врача.

Слово врача: «Может, стоит сделать весь кабинет на английском, чтобы мы ничего
не пропускали. И на иврите, в зависимости от того, какой язык поступает».

⛔⛔ ЧТО НАЙДЕНО ПРОГОНОМ ДО ПОСТРОЙКИ. Проверено запуском, не рассуждением:

    «не хочу жить»                    → 🔴 КРИЗИС
    «I do not want to live anymore»   → ⛔ ПРОПУЩЕН, план ВЫДАЁТСЯ
    «אני לא רוצה לחיות»                → ⛔ ПРОПУЩЕН, план ВЫДАЁТСЯ

    «внезапно ослабла правая рука»    → ⛔ C_focal
    «sudden weakness in my right arm» → ⛔ ПРОПУЩЕН
    «my face is drooping»             → ⛔ ПРОПУЩЕН
    «חולשה פתאומית ביד ימין»            → ⛔ ПРОПУЩЕН

Мысли о смерти по-английски и инсульт на иврите проходят насквозь, и кабинет
говорит «ничего не узнано» и ВЫДАЁТ план. Экран пациента при этом предлагает
пять языков: ru · he · en · ar · fr.

═══ ПОЧЕМУ НЕ «ВЕСЬ КАБИНЕТ НА АНГЛИЙСКОМ» ═══

Разрез проходит не там. У кабинета три слоя, и язык в них значит разное:

  1. КАНОН И МЕТОД — гель, золь, затвор, шесть Ки, M-0…M-S. Это подписанный
     язык врача. «Золь» — не sol, «затвор» — не gate: перевод потребовал бы
     ПЕРЕПОДПИСАТЬ каждое правило в языке, где термины значат другое. И Страж
     стоит на русских стоп-словах: перевод канона удвоил бы поверхность утечки.
     ⛔ НЕ ПЕРЕВОДИТСЯ.

  2. ДВИЖКИ — 76 движков, 4107 проверок. Перевод — огромная переделка, и
     клинически она не даёт ничего: код не читает слов больного.
     ⛔ НЕ ПЕРЕВОДИТСЯ.

  3. ВХОД — место, где приходят СЛОВА БОЛЬНОГО. Вот здесь дыра, и здесь врач прав.
     ⭐ ВОТ ЧТО ДЕЛАЕТСЯ МНОГОЯЗЫЧНЫМ.

═══ И ГЛАВНОЕ, ЧЕГО НЕ РЕШИТ НИКАКОЙ СЛОВАРЬ ═══

СЛОВАРЬ НИКОГДА НЕ БУДЕТ ПОЛОН. Он не полон и по-русски: прогон десяти
настоящих больных показал, что «боль в левой подмышке» не ловится ничем.
Поэтому главная защита — НЕ БОЛЬШИЙ СЛОВАРЬ, А ЧЕСТНЫЙ ОТКАЗ:

  ⭐⭐⭐ ЯЗЫК, КОТОРОГО КАБИНЕТ НЕ РАЗБИРАЕТ, — ЭТО ОТКАЗ, А НЕ «ЧИСТО».

Сегодня иврит даёт «ничего не узнано» и план выходит. Должно давать «язык не
разобран» и план не выходить. Это тот же закон, что «пустая жалоба — не чисто»
и «нет входа — это вопрос, а не ответ».

═══ ЧТО ПОДПИСАНО, А ЧТО ПОСТРОЕНО ═══

Врач распорядился сделать вход многоязычным. Сами СЛОВА на трёх языках
построены движком и подписи не имеют — Р-ЯЗЫК-1. Опасности и их последствия
не менялись: это те же десять флагов и те же три пробела.

⛔ И СЛОВАРЬ НЕ ПЕРЕВЕДЁН, А НАПИСАН ЗАНОВО НА КАЖДОМ ЯЗЫКЕ. Перевод русского
списка дал бы русски думающий словарь в английской одежде: больной говорит не
«давление в груди», а "chest tightness"; не «жжёт за грудиной», а "heartburn
feeling". На иврите — третий набор идиом.

validated:false.
"""
import json
import collections
import shutil
import os

P = '/tmp/kab/app_new/shared/data/diagnosis_algorithm_canon.json'
c = json.load(open(P, encoding='utf-8'), object_pairs_hook=collections.OrderedDict)
K = 'первичный_фильтр_жалобы'
assert K in c, 'слоя триажа нет — сначала write_canon_triazh.py'
assert 'языки_входа' not in c[K], 'языки уже заведены'

n = 130
while os.path.exists(P + f'.bak_v{n}'):
    n += 1
shutil.copy(P, P + f'.bak_v{n}')

Я = collections.OrderedDict()
Я['источник'] = (
    'д-р Литвак, 29.09.2026: «Может, стоит сделать весь кабинет на английском, '
    'чтобы мы ничего не пропускали. И на иврите, в зависимости от того, какой '
    'язык поступает».'
)
Я['⭐⭐⭐закон'] = (
    'ЯЗЫК, КОТОРОГО КАБИНЕТ НЕ РАЗБИРАЕТ, — ЭТО ОТКАЗ, А НЕ «ЧИСТО».'
)
Я['⛔что_НЕ_переводится'] = (
    'Канон и движки остаются на русском. «Золь» — не sol, «затвор» — не gate: '
    'перевод потребовал бы переподписать каждое правило в языке, где термины '
    'значат другое, а Страж стоит на русских стоп-словах и перевод удвоил бы '
    'поверхность утечки. Многоязычным делается ВХОД — место, где приходят слова '
    'больного.'
)
Я['⛔словарь_не_переведён_а_написан_заново'] = (
    'Перевод русского списка дал бы русски думающий словарь в чужой одежде. '
    'Больной по-английски говорит "chest tightness", а не «давление в груди»; '
    'на иврите — третий набор идиом. Каждый язык написан своими словами.'
)
Я['поддержанные'] = ['ru', 'en', 'he']
Я['⚠не_поддержаны_пока'] = (
    'ar и fr — экран пациента их предлагает, а словаря под них нет. До словаря '
    'они дают ОТКАЗ, а не «чисто». Р-ЯЗЫК-2.'
)
Я['определение_языка'] = collections.OrderedDict([
    ('как', 'По ПИСЬМЕННОСТИ, а не по словам: кириллица → ru, иврит → he, '
            'арабица → ar, латиница → en/fr. Письменность определяется однозначно '
            'и не требует словаря — значит не может ошибиться из-за его неполноты.'),
    ('смешанный_текст', 'Считается по преобладанию букв. При близком счёте берутся '
                        'ОБА языка: лучше проверить дважды, чем пропустить.'),
    ('⛔язык_не_определён', 'Текст без букв (только цифры, знаки) — это НЕ СПРОШЕНО.'),
])

# ═══ СЛОВАРЬ ПО ЯЗЫКАМ ═══════════════════════════════════════════════
# Ключ — имя поля входа redFlags. Значения — слова больного на каждом языке.
сл = collections.OrderedDict()


def поле(имя, что, en, he):
    d = collections.OrderedDict()
    d['что_это'] = что
    d['en'] = en
    d['he'] = he
    сл[имя] = d


поле('phq9_item9', 'CRISIS. Проверяется первым. Самая высокая цена пропуска.',
     ['i want to die', 'i dont want to live', 'i do not want to live',
      'dont want to live anymore', 'do not want to live anymore',
      'better off dead', 'no reason to live', 'nothing to live for',
      'kill myself', 'killing myself', 'end my life', 'end it all',
      'take my own life', 'suicidal', 'suicide', 'thoughts of death',
      'hurt myself', 'harm myself', 'cutting myself', 'self harm'],
     ['אני לא רוצה לחיות', 'לא רוצה לחיות', 'אין לי סיבה לחיות',
      'עדיף שאמות', 'רוצה למות', 'מחשבות על מוות', 'מחשבות אובדניות',
      'לשים סוף לחיים', 'לפגוע בעצמי', 'לחתוך את עצמי', 'אובדני'])

поле('chest_pain', 'A_cardiac, жёсткая остановка. Одиночный признак.',
     ['chest pain', 'chest pains', 'pain in my chest', 'pain in the chest',
      'chest pressure', 'pressure in my chest', 'chest tightness',
      'tight chest', 'tightness in my chest', 'chest discomfort',
      'heaviness in my chest', 'burning in my chest', 'squeezing in my chest',
      'my chest hurts', 'chest hurts', 'pain behind the breastbone',
      'crushing chest'],
     ['כאב בחזה', 'כאבים בחזה', 'כאב בית החזה', 'לחץ בחזה', 'לחץ בבית החזה',
      'כבדות בחזה', 'צריבה בחזה', 'שריפה בחזה', 'לוחץ לי בחזה',
      'כואב לי החזה', 'הידוק בחזה', 'כאב מאחורי עצם החזה'])

поле('dyspnea_exertion', 'A_cardiac в паре с сердцебиением.',
     ['short of breath when walking', 'shortness of breath on exertion',
      'breathless when walking', 'out of breath when i walk',
      'cant breathe when i walk', 'winded easily', 'get winded',
      'short of breath climbing stairs', 'breathless on stairs'],
     ['קוצר נשימה במאמץ', 'קוצר נשימה כשאני הולך', 'קוצר נשימה בהליכה',
      'מתנשף במאמץ', 'קשה לי לנשום כשאני הולך', 'קוצר נשימה בעליית מדרגות'])

поле('palpitations', 'A_cardiac в паре с одышкой при нагрузке.',
     ['palpitations', 'heart racing', 'racing heart', 'pounding heart',
      'heart pounding', 'heart skipping', 'skipped beats', 'fluttering heart',
      'my heart flutters', 'irregular heartbeat'],
     ['דפיקות לב', 'הלב דופק חזק', 'פרפור בלב', 'הלב מדלג', 'דופק מהיר',
      'פעימות לא סדירות'])

поле('unilateral_weakness',
     'C_focal, жёсткая остановка. Инсульт до доказательства обратного.',
     ['one sided weakness', 'weakness on one side', 'weakness in one arm',
      'weakness in one leg', 'sudden weakness in my arm',
      'sudden weakness in my right arm', 'sudden weakness in my left arm',
      'sudden weakness in my right leg', 'sudden weakness in my left leg',
      'my arm went weak', 'my leg went weak', 'my arm is weak',
      'my leg is weak', 'cant lift my arm', 'cannot lift my arm',
      'cant move my arm', 'cannot move my arm', 'arm went numb',
      'leg went numb', 'numbness on one side', 'half my face is numb',
      'face is numb', 'facial droop', 'face drooping', 'my face is drooping',
      'mouth is drooping', 'corner of my mouth', 'face went crooked'],
     ['חולשה בצד אחד', 'חולשה פתאומית ביד', 'חולשה פתאומית ביד ימין',
      'חולשה פתאומית ביד שמאל', 'חולשה פתאומית ברגל', 'היד נחלשה',
      'הרגל נחלשה', 'לא מרגיש את היד', 'לא מרגיש את הרגל',
      'נימול בצד אחד', 'חצי פנים מנומל', 'הפנים עקומות', 'עיוות בפנים',
      'הפה נמשך הצידה', 'צניחה בפנים'])

поле('night_sweats', 'B_systemic в паре с потерей веса. И гейт 1.',
     ['night sweats', 'sweating at night', 'i sweat at night',
      'sweat through my sheets', 'drenched at night', 'soaking sweats',
      'wake up drenched', 'wake up soaked'],
     ['הזעות לילה', 'מזיע בלילה', 'מזיעה בלילה', 'מתעורר רטוב מזיעה',
      'הזעות לילה מרובות', 'הסדינים רטובים מזיעה'])

поле('weight_loss', 'B_systemic в паре с ночной потливостью. И гейты 1 и 5.',
     ['weight loss', 'losing weight', 'lost weight', 'i am losing weight',
      'dropped weight', 'my clothes are loose', 'clothes are too big',
      'unintentional weight loss', 'lost kilos', 'lost pounds'],
     ['ירידה במשקל', 'ירדתי במשקל', 'אני יורד במשקל', 'אני יורדת במשקל',
      'הבגדים רחבים עלי', 'ירידה לא מוסברת במשקל'])

поле('changing_moles', 'B_systemic, одиночный признак.',
     ['changing mole', 'mole is changing', 'mole got bigger',
      'mole is growing', 'mole turned dark', 'mole is bleeding',
      'mole itches', 'new mole', 'spot is growing'],
     ['שומה משתנה', 'השומה גדלה', 'השומה השחירה', 'השומה מדממת',
      'שומה חדשה', 'נקודת חן משתנה'])

поле('snore_loud', 'F_apnea. Нужны ВСЕ ТРИ признака.',
     ['i snore', 'snoring', 'loud snoring', 'snore loudly'],
     ['אני נוחר', 'נחירות', 'נחירות חזקות', 'אני נוחרת'])
поле('daytime_sleepiness', 'F_apnea, второй из трёх.',
     ['daytime sleepiness', 'sleepy during the day', 'falling asleep during the day',
      'i doze off', 'nodding off', 'fall asleep at the wheel',
      'fall asleep driving', 'tired all day'],
     ['ישנוניות ביום', 'נרדם במשך היום', 'נרדמת במשך היום',
      'נרדם בנהיגה', 'עייפות במשך כל היום'])
поле('breathing_pauses', 'F_apnea, третий из трёх.',
     ['i stop breathing in my sleep', 'stop breathing at night',
      'breathing pauses', 'pauses in breathing', 'i gasp at night',
      'my wife says i stop breathing', 'my husband says i stop breathing',
      'choking in my sleep'],
     ['הפסקות נשימה בשינה', 'מפסיק לנשום בשינה', 'הפסקות נשימה בלילה',
      'אשתי אומרת שאני מפסיק לנשום', 'בעלי אומר שהוא מפסיק לנשום',
      'נחנק בשינה'])

поле('dream_enactment', 'H_rbd. Одиночный признак, распоряжение врача 21.09.2026.',
     ['i act out my dreams', 'acting out dreams', 'i shout in my sleep',
      'yelling in my sleep', 'i punch in my sleep', 'i kick in my sleep',
      'fight in my sleep', 'fall out of bed', 'i fell out of bed',
      'thrashing in my sleep', 'flailing in my sleep'],
     ['אני מממש את החלומות', 'צועק בשינה', 'צועקת בשינה', 'מכה בשינה',
      'בועט בשינה', 'נופל מהמיטה', 'נופלת מהמיטה', 'מתנועע בשינה'])
поле('rbd_injury', 'Усиливает срочность H_rbd, флаг тот же.',
     ['i hit my wife in my sleep', 'i hit my husband in my sleep',
      'i hurt myself in my sleep', 'bruises from sleeping',
      'injured myself in my sleep'],
     ['הכיתי את אשתי בשינה', 'הכיתי את בעלי בשינה', 'נפצעתי בשינה',
      'חבורות מהשינה'])

Я['словарь'] = сл

# ═══ ПРОБЕЛЫ КАНОНА — НА ТРЁХ ЯЗЫКАХ ═════════════════════════════════
Я['опасное_без_флага'] = collections.OrderedDict([
    ('⛔напоминание',
     'Те же ТРИ опасности, под которыми подписанного флага НЕТ (Р-ТРИАЖ-2). '
     'Движок их узнаёт, флага не заводит и ПЛАН НЕ ВЫДАЁТ, называя пробел.'),
    ('кровотечение из желудочно-кишечного тракта', collections.OrderedDict([
        ('en', ['black stool', 'black stools', 'tarry stool', 'black tarry stool',
                'vomiting blood', 'throwing up blood', 'blood in my vomit',
                'coffee ground vomit', 'blood in my stool', 'bloody stool',
                'rectal bleeding']),
        ('he', ['צואה שחורה', 'יציאות שחורות', 'הקאת דם', 'דם בהקאה',
                'דם ביציאות', 'דימום מהרקטום', 'צואה שחורה כמו זפת']),
    ])),
    ('одышка в покое и ортопноэ', collections.OrderedDict([
        ('en', ['short of breath at rest', 'breathless at rest',
                'cant breathe at rest', 'cannot lie flat', 'cant lie down',
                'cannot lie down', 'i sleep sitting up', 'sleep on pillows',
                'wake up gasping', 'severe shortness of breath', 'orthopnea']),
        ('he', ['קוצר נשימה במנוחה', 'לא יכול לשכב', 'לא יכולה לשכב',
                'ישן בישיבה', 'מתעורר בחוסר אוויר', 'קוצר נשימה קשה']),
    ])),
    ('односторонний отёк и боль голени', collections.OrderedDict([
        ('en', ['swollen calf', 'one leg is swollen', 'one leg swollen',
                'my calf hurts and is swollen', 'leg is bigger than the other',
                'hot swollen leg', 'painful swollen calf']),
        ('he', ['שוק נפוחה', 'רגל אחת נפוחה', 'רגל אחת גדולה מהשנייה',
                'שוק כואבת ונפוחה', 'רגל נפוחה וחמה']),
    ])),
])

Я['открытые_вопросы'] = [
    'Р-ЯЗЫК-1: слова на трёх языках построены движком и НЕ ПОДПИСАНЫ. '
    'Ивритский и английский списки нужно прочесть носителю клинического языка.',
    'Р-ЯЗЫК-2: арабский и французский экран пациента предлагает, а словаря нет. '
    'До словаря они дают ОТКАЗ. Заводить ли их.',
    'Р-ЯЗЫК-3: при неразобранном языке движок отказывается выдать план. '
    'Верно ли это для ВРАЧЕБНОГО контура или только для пациентского.',
]
Я['validated'] = False

c[K]['языки_входа'] = Я
c[K]['статус'] = str(c[K]['статус']) + (
    ' ⭐ 29.09.2026 добавлен слой ЯЗЫКОВ ВХОДА: ru · en · he, и отказ на '
    'неразобранном языке. Р-ЯЗЫК-1/2/3 открыты.')

json.dump(c, open(P, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
en = sum(len(v['en']) for v in сл.values())
he = sum(len(v['he']) for v in сл.values())
пр = sum(len(v['en']) + len(v['he']) for k, v in Я['опасное_без_флага'].items()
         if isinstance(v, dict) and 'en' in v)
print(f'ключей канона: {len(c)}')
print(f'полей входа: {len(сл)} · английских слов: {en} · ивритских: {he}')
print(f'слов в трёх пробелах (en+he): {пр}')
print(f'резервная копия: {P}.bak_v{n}')
