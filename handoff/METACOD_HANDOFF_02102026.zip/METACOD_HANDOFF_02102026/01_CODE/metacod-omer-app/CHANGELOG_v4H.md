# METACOD-Omer · v4H — §2J.1 «Разрешение противоречий» зафиксировано в каноне

Дата: 2026-09-13. Слой L1, наружу не выходит. Обратная совместимость: все прежние кейсы без изменений.

## Причина
Тренировка фазовых переходов на 6 пациентах (Итамар, Hussein, Wagner, Efi, М.77, Preston) вскрыла
живое противоречие канона: HARD-STOP Общей таблицы запрещает NAC при M-D2, а редокс-план Preston
назначал NAC 600×2. Плюс пять повторяющихся столкновений «энергия ⇄ гель-золь».

## Что изменено
- `shared/data/diagnosis_algorithm_canon.json` (v1.1):
  - `разрешение_противоречий` — правило верхнего уровня, порядок разрешения (5 шагов), кейсы K1–K8;
  - `замены_при_запрете` — 8 позиций (NAC, GLP-1, SGLT-2/петлевой, метформин, Ca/вит-D, системные
    энзимы, НПВС внутрь, железо): при каком условии, чем заменить, почему, оговорка;
  - `уровни_гель_золь` — организм/орган/кость/очаг/клетка, правило и ошибка-образец;
  - `hard_stop` — строка по NAC уточнена: «редокс закрывать БЕЗ NAC (см. замены_при_запрете)».
- `shared/engines/diagnosisAlgorithm.ts`: `substitutions()` (гейты M-D* и антикоагулянт),
  `SUBSTITUTION_TABLE`, `LEVEL_RULE`, `CONFLICT_CASES`; трасса получила `substitutions` и `levelRule`;
  HARD-STOP теперь говорит «цель закрывать ЗАМЕНОЙ, не вычёркивать»; шаг 4 показывает замены.
- `shared/types.ts`: `SubstitutionNote`, поля `substitutions` / `levelRule` в `DiagnosisTrace`.
- `client/src/screens/AlgorithmScreen.tsx`: блок «ЗАМЕНЫ ПРИ ЗАПРЕТЕ (§2J.1)» + «Уровни гель ⇄ золь».
- `shared/knowledge/АЛГОРИТМ_ДИАГНОЗА.md`: раздел §2J.1 (правила 1–4, таблица K1–K8).
- Тест: +10 проверок (NAC→замена без NAC, гейт M-A2, энзимы при антикоагулянте, уровни, таблицы).

## Ключевое правило
**Запрет не отменяет цель.** HARD-STOP убирает препарат — задача закрывается заменой.
**Гель-золь задаётся на каждом уровне отдельно.** **Безопасность выше столпа метода.**

## Проверка
    # §2H-блок run.sh (строка 11 репозитория падает на этой машине: tsc TS5103 --ignoreDeprecations)
    tsc ... --resolveJsonModule --rootDir shared --outDir _buildA shared/engines/diagnosisAlgorithm.ts shared/engines/solGel.ts
    node shared/engines/__tests__/diagnosisAlgorithm.test.js   # 31/31
Типизация shared: `tsc --noEmit` exit 0. validated:false.
