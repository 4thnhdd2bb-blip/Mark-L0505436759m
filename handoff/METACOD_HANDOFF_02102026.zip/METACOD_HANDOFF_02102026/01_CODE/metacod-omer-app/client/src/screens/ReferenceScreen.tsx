import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { common as c } from '../styles/common.styles';
import { screenStyles as sc } from '../styles/screens.styles';
import { refStyles as s } from '../styles/reference.styles';
const BLOCKS = [
  { t: 'Протоколы титрации (GLP-1/SGLT2/метформин)', b: 'Медленно: тошнота от скорости наращивания, не от дозы. Минимальная эффективная доза. Пожилые — ступени длиннее.' },
  { t: 'Защита мышц (сопровождение)', b: 'Белок 1.2–1.6 г/кг+лейцин, креатин, HMB, вит D3, омега-3, силовая нагрузка; Akkermansia/бутират → свой GLP-1.' },
  { t: 'Схемы побочных эффектов', b: 'Противорвотные по механизму (ондансетрон/метоклопрамид/домперидон); запор/понос по классу.' },
  { t: 'Осложнения диабета — ступени', b: 'Нейропатия/нефро/ретино — по стадиям; препараты и цели.' },
  { t: 'Геронтология', b: 'Inflammaging, сенесценция; приоритет мышц/функции; депрескрайбинг (Бирс).' },
  { t: 'Мембранный индекс MWI / фазовый угол', b: 'MWI=(CL/AP)×… CL=hsCRP×10+(TG/HDL)×15+ГГТ×0.5; AP=PhA×10+25(OH)D×0.5. >60 → приоритет мышц; GTM замедляет титрование.' },
];
export function ReferenceScreen() {
  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.h1}>Справочник (Метаболический пациент)</Text>
      {BLOCKS.map((x) => (
        <View key={x.t} style={s.block}><Text style={s.title}>{x.t}</Text><Text>{x.b}</Text></View>
      ))}
      <Text style={sc.sColorMarginTopMuted30}>Полные тексты — книги в Drive (Тома 1–3 v9, Главная книга v8, монография «8 мембран»).</Text>
    </ScrollView>
  );
}
