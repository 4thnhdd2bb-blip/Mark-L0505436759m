// METACOD-Omer · QueueScreen — очередь на подпись врача.
//
// ⛔⛔ ЗАЧЕМ ЭКРАН. До 28.09.2026 разбор выходил с пометкой validated:false и
// оставался с ней навсегда: снять её было нечем. Правило «снимает только врач»
// исполнялось буквально и означало «не снимает никто».
//
// ⛔⛔ РЕМОНТ 01.10.2026. Экран видел ОДИН разбор — тот, что этот врач только что
// посчитал на этом телефоне. Разборы, присланные пациентами, и разборы коллег в
// очередь не попадали никак: списка не было. Теперь очередь читается из базы
// (читать её могут только врачи — firestore.rules), а последний свой разбор
// выбирается сразу.
//
// ⭐ ЭКРАН НИЧЕГО НЕ РЕШАЕТ. Можно ли подписать — говорит движок `signQueue`,
// ТОТ ЖЕ, что на сервере (общий код shared/). Кнопка не активна там, где движок
// сказал «нельзя», а последнее слово всё равно за сервером.
//
// ⛔ ПОДПИСЬ ВСЛЕПУЮ ПОДПИСЬЮ НЕ СЧИТАЕТСЯ: пока врач не подтвердил, что видел
// вопросы предохранителей, кнопка не активна.
import React, { useCallback, useEffect, useState } from 'react';
import { ScrollView, View, Text, TouchableOpacity, ActivityIndicator, Switch } from 'react-native';
import { signReport, очередьЗагрузить, разборЗагрузить } from '../api/firebase';
import { sqСостояние, sqМожноПодписать, sqБлокСнимаетсяПодписью } from '@shared/engines/signQueue';
import type { ЗаписьОчереди } from '@shared/engines/signQueue';
import { common as c } from '../styles/common.styles';
import { formStyles as f } from '../styles/forms.styles';
import { reportStyles as s } from '../styles/report.styles';
import { useAnalysis } from '../state/analysis';
import { useSession } from '../state/session';

export function QueueScreen() {
  const { analysis } = useAnalysis();
  const { user } = useSession();
  const [записи, setЗаписи] = useState<ЗаписьОчереди[]>([]);
  const [выбрана, setВыбрана] = useState<string | null>(analysis.reportId ?? null);
  const [разбор, setРазбор] = useState<Record<string, any> | null>(null);
  const [вопросыВидел, setВопросыВидел] = useState(false);
  const [грузится, setГрузится] = useState(false);
  const [занят, setЗанят] = useState(false);
  const [итог, setИтог] = useState('');
  const [ошибка, setОшибка] = useState('');

  const загрузить = useCallback(async () => {
    setГрузится(true); setОшибка('');
    try { setЗаписи(await очередьЗагрузить()); }
    catch (e: any) { setОшибка('Очередь не загрузилась: ' + (e?.message ?? 'нет связи')); }
    finally { setГрузится(false); }
  }, []);

  useEffect(() => { void загрузить(); }, [загрузить]);

  useEffect(() => {
    setРазбор(null); setВопросыВидел(false); setИтог('');
    if (!выбрана) return;
    разборЗагрузить(выбрана).then(setРазбор).catch(() => setРазбор(null));
  }, [выбрана]);

  const запись = записи.find((з) => з.reportId === выбрана) ?? null;
  const подписант = { uid: user?.uid ?? '', врач: true };   // сервер всё равно проверит роль по токену
  const решение = запись ? sqМожноПодписать(запись, подписант, вопросыВидел) : null;
  // ⛔ Явно, а не только через движок: без «вопросы видел» кнопки нет ни при каком ответе.
  const подписатьМожно = !!решение?.можно && вопросыВидел && !занят;
  const п = запись?.предохранители;
  // ⭐ Врачу на чтение перед подписью — разбор из базы. Если контур остановил выдачу
  // только из-за отсутствия подписи, читать надо ОСТАНОВЛЕННЫЙ разбор: его и подписывают.
  const текстРазбора = разбор?.['остановленный_разбор'] ?? разбор?.conventional ?? null;

  async function подписать(отозвать: boolean) {
    if (!выбрана) return;
    setЗанят(true); setОшибка(''); setИтог('');
    try {
      const r = await signReport({
        reportId: выбрана,
        вопросыПрочитаны: вопросыВидел,
        ...(отозвать ? { отозвать: true, причина: 'отозвано врачом в кабинете' } : {}),
      });
      setИтог(`Состояние: ${r.состояние} · validated: ${r.validated}`);
      await загрузить();
    } catch (e: any) {
      // ⛔ Причина отказа показывается ЦЕЛИКОМ: отказ, сведённый к слову «ошибка»,
      // ничем не отличается от поломки, и врач не может понять, что делать.
      setОшибка(e?.message ?? 'подпись не принята');
    } finally { setЗанят(false); }
  }

  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.h1}>Очередь на подпись</Text>
      <TouchableOpacity onPress={() => { void загрузить(); }} disabled={грузится}>
        <Text style={f.linkPlain}>{грузится ? 'Загружается…' : 'Обновить очередь'}</Text>
      </TouchableOpacity>

      {записи.length === 0 && !грузится ? <Text>Очередь пуста.</Text> : null}
      {записи.map((з) => (
        <TouchableOpacity key={з.reportId} onPress={() => setВыбрана(з.reportId)}
          style={[f.queueItem, з.reportId === выбрана ? f.queueItemActive : null]}>
          <Text>{sqСостояние(з)}</Text>
          <Text style={f.queueMeta}>
            {`${new Date(з.создан).toLocaleString()} · ${з.reportId}`
             + (з.предохранители ? ` · вопросов: ${з.предохранители.вопросов}` : '')}
          </Text>
        </TouchableOpacity>
      ))}

      {запись ? (
        <View>
          <Text style={c.h2}>Что говорит контур</Text>
          <Text>{`Проверок: ${п?.проверок ?? '—'} · остановивших: ${п?.блоков ?? '—'} · вопросов к врачу: ${п?.вопросов ?? '—'}`}</Text>
          {sqБлокСнимаетсяПодписью(запись) ? (
            <Text style={s.guardBad}>
              {'Выдача остановлена только потому, что под назначением ещё нет подписи врача. '
               + 'Ваша подпись и есть эта подпись — прочтите разбор ниже.'}
            </Text>
          ) : null}

          <Text style={c.h2}>Разбор</Text>
          {текстРазбора ? (
            <View style={c.card}>
              <Text>{String(текстРазбора.logic ?? '')}</Text>
              <Text style={f.queueMeta}>{String(текстРазбора.summary ?? '')}</Text>
            </View>
          ) : <Text>Разбор загружается или недоступен.</Text>}

          {решение && решение.состояние === 'подписать нельзя' ? (
            <View style={s.red}><Text style={s.redText}>
              {'⛔ Этот разбор подписать нельзя. ' + решение.почему}
            </Text></View>
          ) : null}

          <Text style={c.h2}>Подпись</Text>
          <View style={f.row}>
            <Switch value={вопросыВидел} onValueChange={setВопросыВидел} />
            <Text style={f.rowText}>
              {`Я видел вопросы предохранителей (${п?.вопросов ?? 0}) и беру разбор под свою ответственность`}
            </Text>
          </View>

          <TouchableOpacity
            style={[c.button, !подписатьМожно ? f.buttonOff : null]}
            disabled={!подписатьМожно}
            onPress={() => подписать(false)}
          >
            {занят ? <ActivityIndicator color="#fff" />
              : <Text style={c.buttonText}>Подписать и снять validated:false</Text>}
          </TouchableOpacity>

          <TouchableOpacity style={f.linkSpaced} disabled={занят} onPress={() => подписать(true)}>
            <Text style={f.link}>Отозвать подпись (с указанием причины)</Text>
          </TouchableOpacity>
        </View>
      ) : null}

      {итог ? <Text style={s.guardOk}>{итог}</Text> : null}
      {ошибка ? <View style={s.red}><Text style={s.redText}>{ошибка}</Text></View> : null}

      <Text style={s.guardBad}>
        {'Пока подписи нет — validated: false. Снимает её только врач, и только здесь.'}
      </Text>
    </ScrollView>
  );
}
