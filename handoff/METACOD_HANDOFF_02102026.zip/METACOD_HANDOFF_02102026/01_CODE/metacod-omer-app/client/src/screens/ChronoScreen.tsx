import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { common as c } from '../styles/common.styles';
import { screenStyles as sc } from '../styles/screens.styles';
import { useAnalysis } from '../state/analysis';
export function ChronoScreen() {
  const { analysis } = useAnalysis();
  const l1 = analysis.internalL1;
  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.h1}>Хронотерапия</Text>
      <Text style={sc.sColorMarginBottomMuted26}>Расписание по часам (утро/день/вечер/ночь), меняется по этапам. Формируется из фазового плана.</Text>
      {!l1 ? <Text>Нет разбора.</Text> : (l1.phaseJourney ?? []).map((st: any) => (
        <View key={st.phase} style={c.card}>
          <Text style={sc.sFontWeightColorTeal1}>{`Фаза ${st.phase}`}</Text>
          <Text>{`Препараты: ${(st.drugs ?? []).map((d: any) => d.name).join(', ')}`}</Text>
          <Text style={sc.sColorMuted27}>{`Ворота: ${st.gate}`}</Text>
        </View>
      ))}
    </ScrollView>
  );
}
