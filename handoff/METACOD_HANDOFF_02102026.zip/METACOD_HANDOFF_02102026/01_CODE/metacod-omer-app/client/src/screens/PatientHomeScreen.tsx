// METACOD-Omer · PatientHomeScreen — главный экран ПАЦИЕНТА.
//
// ⛔⛔ ЭТО ДРУГОЕ ПРИЛОЖЕНИЕ, А НЕ УКОРОЧЕННОЕ ВРАЧЕБНОЕ.
//
// Слово врача 20.09.2026: «САЙТ НИЧЕГО НЕ РЕШАЕТ. Он собирает данные и
// показывает готовое». Поэтому у пациента ровно три дела: дать согласие,
// прислать анкету или жалобы, увидеть готовое — и ничего больше. Ни разбора,
// ни гипотез, ни обследования, ни препаратов: препаратов на этом контуре нет
// ни при каком ответе, ни по запросу, ни по флагу (Р-САЙТ-3).
//
// ⛔⛔ РЕМОНТ 01.10.2026. Экран читал `analysis.пациенту`, которое не заполнял никто,
// и показывал «Пока ничего не отправлено» даже после отправки. А подписанный врачом
// документ сюда не приходил вовсе. Теперь экран спрашивает сервер (patientDocument):
// до подписи — «ждёт врача», после — действия, пропущенные через фильтр §4N.
//
// ⭐ Экран не фильтрует сам: что можно показать, решает сервер.
import React, { useCallback, useState } from 'react';
import { ScrollView, View, Text, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { patientDocument } from '../api/firebase';
import { useAnalysis } from '../state/analysis';
import { useSession } from '../state/session';
import { common as c } from '../styles/common.styles';
import { formStyles as f } from '../styles/forms.styles';
import { reportStyles as s } from '../styles/report.styles';

export function PatientHomeScreen({ navigation }: any) {
  const { analysis, setAnalysis } = useAnalysis();
  const { выйти } = useSession();
  const [грузится, setГрузится] = useState(false);
  const [ошибка, setОшибка] = useState('');
  const п: any = analysis.пациенту || null;

  const обновить = useCallback(async () => {
    setГрузится(true); setОшибка('');
    try {
      const д: any = await patientDocument();
      // ⭐ У пациента в состоянии нет ничего, кроме его документа: врачебных полей тут не бывает.
      setAnalysis({ reportId: д.reportId, пациенту: д });
    } catch (e: any) {
      // «not-found» — у человека ещё нет ни одного разбора: это не ошибка.
      if (!/not-found|разбора нет/i.test(String(e?.code ?? '') + String(e?.message ?? ''))) {
        setОшибка(e?.message ?? 'не удалось получить документ');
      }
    } finally { setГрузится(false); }
  }, [setAnalysis]);

  // ⭐ При каждом возвращении на экран — свежий документ: подпись могла появиться.
  useFocusEffect(useCallback(() => { void обновить(); }, [обновить]));

  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.h1}>Ваш кабинет</Text>

      <Text style={c.h2}>Что сделать</Text>
      <TouchableOpacity style={c.button} onPress={() => navigation.navigate('Consent')}>
        <Text style={c.buttonText}>1 · Согласие</Text>
      </TouchableOpacity>
      <TouchableOpacity style={[c.button, f.buttonStacked]}
        onPress={() => navigation.navigate('Survey')}>
        <Text style={c.buttonText}>2 · Анкета и жалобы</Text>
      </TouchableOpacity>

      <Text style={c.h2}>Что готово</Text>
      <TouchableOpacity onPress={() => { void обновить(); }} disabled={грузится}>
        <Text style={f.linkPlain}>{грузится ? 'Проверяю…' : 'Обновить'}</Text>
      </TouchableOpacity>
      {грузится && !п ? <ActivityIndicator color="#0d6a6a" /> : null}
      {ошибка ? <View style={s.red}><Text style={s.redText}>{ошибка}</Text></View> : null}
      {!п ? (
        <Text>{'Пока ничего не отправлено. Начните с согласия.'}</Text>
      ) : п['выдан'] === false ? (
        <View style={s.red}><Text style={s.redText}>
          {String(п['что_делать'] || 'Обратитесь к лечащему врачу.')}
        </Text></View>
      ) : (
        <View>
          <Text style={п.состояние === 'готово' ? s.guardOk : s.guardBad}>{п.состояние}</Text>
          <Text>{п.сообщение}</Text>

          {(п.эскалации || []).length > 0 ? (
            <View style={s.red}><Text style={s.redText}>
              {(п.эскалации || []).map((э: any) => э.текст?.ru || э.code).join('\n')}
            </Text></View>
          ) : null}

          {(п.вопросы || []).length > 0 ? (
            <View style={s.red}><Text style={s.redText}>
              {(п.вопросы || []).map((в: any) => в.текст?.ru || в.code).join('\n')}
            </Text></View>
          ) : null}

          {(п.действия || []).length > 0 ? (
            <View>
              <Text style={c.h2}>Что можно сделать сегодня</Text>
              {(п.действия || []).map((д: any) => (
                <Text key={д.action}>{'• ' + (д.detail || д.action)}</Text>
              ))}
            </View>
          ) : null}
        </View>
      )}

      <Text style={s.guardBad}>
        {'Это не заключение и не назначение. Лекарства и дозы назначает только врач.'}
      </Text>
      <TouchableOpacity style={f.linkSpaced} onPress={() => { void выйти(); }}>
        <Text style={f.linkPlain}>Выйти</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}
