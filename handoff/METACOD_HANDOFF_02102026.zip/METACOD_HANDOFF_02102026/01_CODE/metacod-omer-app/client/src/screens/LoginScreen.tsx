// METACOD-Omer · LoginScreen — вход в кабинет (01.10.2026).
//
// ⛔⛔ ЗАЧЕМ. До этого дня экрана входа не было, а каждая функция сервера требует
// вошедшего пользователя. Приложение открывалось, давало ввести больного и падало
// на первом же вызове словами «Требуется вход».
//
// ⭐ Новая учётная запись всегда без роли — то есть пациент. Роль врача здесь
// получить нельзя: её ставит только сервер (tools/назначить_роль.js), и врач
// после этого выходит и входит заново.
import React, { useState } from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, ActivityIndicator } from 'react-native';
import { войти, зарегистрироваться, причинаОтказаВхода, конфигурацияГотова } from '../api/firebase';
import { common as c } from '../styles/common.styles';
import { formStyles as f } from '../styles/forms.styles';
import { reportStyles as s } from '../styles/report.styles';

export function LoginScreen() {
  const [почта, setПочта] = useState('');
  const [пароль, setПароль] = useState('');
  const [занят, setЗанят] = useState(false);
  const [ошибка, setОшибка] = useState('');
  const настройка = конфигурацияГотова();
  const можно = !!почта.trim() && пароль.length >= 6 && !занят && настройка.готова;

  async function сделать(что: 'вход' | 'регистрация') {
    setЗанят(true); setОшибка('');
    try {
      if (что === 'вход') { await войти(почта, пароль); }
      else { await зарегистрироваться(почта, пароль); }
      // ⭐ Дальше ведёт onAuthStateChanged: экран сам ничего не переключает.
    } catch (e) {
      setОшибка(причинаОтказаВхода(e));
    } finally { setЗанят(false); }
  }

  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.h1}>METACOD · вход</Text>
      {!настройка.готова ? <Text style={f.error}>{настройка.текст}</Text> : null}
      <Text style={c.label}>Почта</Text>
      <TextInput style={c.input} value={почта} onChangeText={setПочта}
        autoCapitalize="none" keyboardType="email-address" autoComplete="email" />
      <Text style={c.label}>Пароль (не меньше 6 знаков)</Text>
      <TextInput style={c.input} value={пароль} onChangeText={setПароль}
        secureTextEntry autoComplete="password" />
      {ошибка ? <Text style={f.error}>{ошибка}</Text> : null}
      <TouchableOpacity style={[c.button, !можно ? f.buttonOff : null]} disabled={!можно}
        onPress={() => сделать('вход')}>
        {занят ? <ActivityIndicator color="#fff" /> : <Text style={c.buttonText}>Войти</Text>}
      </TouchableOpacity>
      <TouchableOpacity style={f.linkSpaced} disabled={!можно} onPress={() => сделать('регистрация')}>
        <Text style={f.linkPlain}>Создать учётную запись пациента</Text>
      </TouchableOpacity>
      <Text style={s.guardBad}>
        {'Учётная запись врача создаётся так же, а роль врача назначает администратор кабинета. '
         + 'После назначения роли выйдите и войдите заново.'}
      </Text>
    </ScrollView>
  );
}
