import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { common as c } from '../styles/common.styles';
import { reportStyles as s } from '../styles/report.styles';
import { HypothesisTable } from '../components/HypothesisTable';
import { useAnalysis } from '../state/analysis';
export function DifferentialScreen() {
  const { analysis } = useAnalysis();
  const conv = analysis.conventional;
  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.h1}>Дифференциальный диагноз</Text>
      {!conv ? <Text>Нет разбора.</Text> : (
        <>
          <Text style={c.h2}>Гипотезы (одна связывающая причина)</Text>
          <HypothesisTable hypotheses={conv.hypotheses ?? []} />
          <View style={s.red}><Text style={s.redText}>{`Параллельно не пропустить: ${(conv.cannotMiss ?? []).join('; ')}`}</Text></View>
        </>
      )}
    </ScrollView>
  );
}
