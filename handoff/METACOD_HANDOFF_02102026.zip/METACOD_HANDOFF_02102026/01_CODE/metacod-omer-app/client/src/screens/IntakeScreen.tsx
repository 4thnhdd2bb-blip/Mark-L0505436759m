// METACOD-Omer · IntakeScreen — вход (3 источника) → «Анализ» → состояние → Заключение
import React, { useState } from 'react';
import { ScrollView, View, Text, TextInput, TouchableOpacity, ActivityIndicator } from 'react-native';
import type { PatientInput } from '@shared/types';
import { analyzePatient, конфигурацияГотова } from '../api/firebase';
import { useAnalysis } from '../state/analysis';
import { common as c } from '../styles/common.styles';
import { formStyles as f } from '../styles/forms.styles';
import { intakeStyles as s } from '../styles/intake.styles';

export function IntakeScreen({ navigation }: any) {
  const { setAnalysis } = useAnalysis();
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [complaints, setComplaints] = useState('');
  const [labs, setLabs] = useState('');
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');

  // ⛔ РЕМОНТ 28.09.2026: отказ по настройке показывается ДО ввода данных больного,
  // а не после нажатия «Анализ». Просить врача заполнить форму, которую всё равно
  // некуда отправить, — это украсть у него время у постели.
  const настройка = конфигурацияГотова();

  async function onAnalyze() {
    setLoading(true); setErr('');
    try {
      if (!настройка.готова) { throw new Error(настройка.текст); }
      const patient: PatientInput = {
        name, age: Number(age) || undefined,
        complaints: complaints.split('\n').map((x) => x.trim()).filter(Boolean),
        labs: parseLabs(labs),
      };
      const res = await analyzePatient(patient);
      // ⛔ РЕМОНТ 28.09.2026: вердикт предохранительного контура, вердикт выпуска
      // и пометка «не валидировано» больше не выбрасываются по дороге к экрану.
      setAnalysis({
        reportId: res.reportId, conventional: res.conventional, internalL1: res.internalL1,
        guard: res.guard, source: res.source, patientName: name,
        предохранители: (res as any).предохранители,
        выпуск: (res as any).выпуск,
        validated: (res as any).validated === true,
        // ⭐ Р-КОНТУР-2 (подпись врача 29.09.2026): остановленный разбор врачу на
        // проверку. ⛔ Тот же урок, что 28.09: поле, которому некуда лечь, экран
        // выбрасывает молча, и врач не может узнать, что оно вообще приходило.
        'остановленный_разбор': (res as any)['остановленный_разбор'] ?? null,
      });
      navigation.navigate('Report');
    } catch (e: any) { setErr(e?.message ?? 'ошибка'); }
    finally { setLoading(false); }
  }

  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.h1}>Приём</Text>
      {!настройка.готова ? (
        <Text style={f.error}>{настройка.текст}</Text>
      ) : null}
      <View style={s.section}>
        <Text style={c.label}>Имя</Text>
        <TextInput style={c.input} value={name} onChangeText={setName} />
        <Text style={c.label}>Возраст</Text>
        <TextInput style={c.input} value={age} onChangeText={setAge} keyboardType="numeric" />
        <Text style={c.label}>Жалобы (по одной в строке)</Text>
        <TextInput style={[c.input, f.textareaSmall]} value={complaints} onChangeText={setComplaints} multiline />
        <Text style={c.label}>Анализы (маркёр=значение)</Text>
        <TextInput style={[c.input, f.textareaSmall]} value={labs} onChangeText={setLabs} multiline placeholder={'Hb=17.6\nHct=51.2\nТГ=130'} />
      </View>
      {err ? <Text style={f.error}>{err}</Text> : null}
      <TouchableOpacity style={c.button} onPress={onAnalyze} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={c.buttonText}>Анализ</Text>}
      </TouchableOpacity>
    </ScrollView>
  );
}

function parseLabs(raw: string): Record<string, number | string> {
  const out: Record<string, number | string> = {};
  for (const line of raw.split('\n')) {
    const [k, v] = line.split('=').map((x) => x?.trim());
    if (k && v !== undefined) out[k] = isNaN(Number(v)) ? v : Number(v);
  }
  return out;
}
