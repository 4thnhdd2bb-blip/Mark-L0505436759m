// METACOD-Omer · AlgorithmScreen — СЛОЙ АЛГОРИТМА ДИАГНОЗА (§2H, L1).
// Трасса первичное→вторичное: жалоба → мембрана → энергия → фаза → 658+JCZ → EBM.
// Объединяет Excel-таблицы (Gel-Zol · Общая таблица · 658 · фазы) в один экран разбора.
import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { common as c } from '../styles/common.styles';
import { screenStyles as sc, цветСлоя, полосаСлоя, цветТочки } from '../styles/screens.styles';
import { useAnalysis } from '../state/analysis';

const LAYER_COLOR: Record<string, string> = {
  'вход': '#5c7472',
  'ПЕРВИЧНО · безопасность': '#c0392b',
  'ВТОРИЧНО · мишень': '#1f7a8c',
  'момент': '#2e7d4f',
  'исполнение': '#2e7d4f',
  'поверх всего': '#6b4fa0',
};

export function AlgorithmScreen() {
  const { analysis } = useAnalysis();
  const l1 = analysis.internalL1;
  const t = l1?.diagnosisTrace;

  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.l1Tag}>ВНУТРЕННИЙ L1 · только проф. Литваку · наружу НЕ выходит</Text>
      <Text style={c.h1}>Алгоритм диагноза</Text>
      {!t ? (
        <Text>Нет разбора, либо у вас нет роли L1.</Text>
      ) : (
        <>
          <View style={c.card}>
            <Text style={sc.sFontWeightColorTeal1}>{t.order}</Text>
            <Text style={sc.sColorFontStyleMuted2}>{`«${t.mantra}»`}</Text>
            <Text style={sc.sMarginTop3}>{`Направление (из мембраны): ${t.direction}`}</Text>
          </View>

          {/* Водопад стадий 0→5 */}
          {t.steps.map((st: any) => (
            <View key={st.n} style={[c.card, полосаСлоя(LAYER_COLOR[st.layer])]}>
              <Text style={sc.sFontWeightColor4}>{`${st.n}. ${st.name}`}</Text>
              <Text style={[sc.sColorFontSizeMuted5, цветСлоя(LAYER_COLOR[st.layer])]}>
                {`${st.layer}  ·  решает: ${st.decides}`}
              </Text>
              <Text style={sc.sMarginTop3}>{st.finding}</Text>
            </View>
          ))}

          {/* Подобранная строка Общей таблицы лечения */}
          {t.treatmentRow ? (
            <View style={c.card}>
              <Text style={c.h2}>Общая таблица лечения — строка</Text>
              <Text>{`Энергия: ${t.treatmentRow.energy}`}</Text>
              <Text>{`Орган: ${t.treatmentRow.organ} · Мембрана: ${t.treatmentRow.membrane}`}</Text>
              <Text>{`Вектор: ${t.treatmentRow.vector}`}</Text>
              <Text>{`Магнит (кол-во): ${t.treatmentRow.magnet} · Цвет (Ко): ${t.treatmentRow.color}`}</Text>
              <Text>{`Препараты (658): ${t.treatmentRow.drugs658}`}</Text>
            </View>
          ) : null}

          {/* JCZ-лестница */}
          {t.jczLadder?.length ? (
            <View style={c.card}>
              <Text style={c.h2}>Приоритет JCZ (Jun-Chen-Zuo-Shi)</Text>
              {t.jczLadder.map((j: any, i: number) => (
                <Text key={i}>{`${j.role}: ${j.item}`}</Text>
              ))}
            </View>
          ) : null}

          {/* 3 контрольные точки */}
          <Text style={c.h2}>Три контрольные точки</Text>
          {t.controlPoints.map((cp: any) => (
            <View key={cp.id} style={c.card}>
              <Text style={[sc.sFontWeightColorTeal6, цветТочки(cp.status)]}>
                {`${cp.status === 'внимание' ? '⚠' : cp.status === 'ok' ? '✓' : '·'} ${cp.text}`}
              </Text>
              {cp.note ? <Text style={sc.sColorMarginTop7}>{cp.note}</Text> : null}
            </View>
          ))}

          {/* Конфликт мембрана⇄энергия */}
          {t.conflict ? (
            <View style={[c.card, { borderColor: '#e0a89f', borderWidth: 1 }]}>
              <Text style={sc.sFontWeightColor8}>Конфликт мембрана ⇄ энергия</Text>
              <Text style={sc.sMarginTop9}>{t.conflict}</Text>
            </View>
          ) : null}

          {/* HARD-STOP */}
          {t.hardStops?.length ? (
            <View style={[c.card, { backgroundColor: '#fdf3f1', borderColor: '#e0a89f', borderWidth: 1 }]}>
              <Text style={sc.sFontWeightColor8}>HARD-STOP</Text>
              {t.hardStops.map((h: string, i: number) => (
                <Text key={i} style={sc.sMarginTop9}>{`⛔ ${h}`}</Text>
              ))}
            </View>
          ) : null}

          {/* §2N — ДВУХУРОВНЕВАЯ МЕМБРАНА: СИСТЕМА (фон) × ОРГАН (точечно) */}
          {t.compartments ? (
            <View style={[c.card, { borderColor: '#8fb3a8', borderWidth: 1 }]}>
              <Text style={sc.sFontWeightColorTeal1}>МЕМБРАНА ПО КОМПАРТМЕНТАМ (§2N)</Text>
              <Text style={sc.sMarginTop9}>{`ФОН (система): ${t.compartments.background}`}</Text>
              {t.compartments.list.map((x: any, i: number) => (
                <Text key={i} style={sc.sMarginTop10}>
                  {`${x.leading ? '◆' : '·'} ${x.target ?? x.level} — ${x.membrane} (${x.pole}) → ${x.vector}`}
                </Text>
              ))}
              {t.compartments.cataBodywide ? (
                <Text style={sc.sMarginTopFontWeight11}>{`⛔ ${t.compartments.safetyNote}`}</Text>
              ) : null}
              {t.compartments.conflicts?.length ? (
                <View style={sc.sMarginTop12}>
                  <Text style={sc.sFontWeightColor13}>Конфликт уровней (правило Литвака)</Text>
                  {t.compartments.conflicts.map((x: string, i: number) => (
                    <Text key={i} style={sc.sFontSizeColor14}>{x}</Text>
                  ))}
                </View>
              ) : null}
              {t.compartments.plans?.length ? (
                <View style={sc.sMarginTop12}>
                  <Text style={sc.sFontWeight15}>Орган точечно ВНУТРИ фона</Text>
                  {t.compartments.plans.map((pl: any, i: number) => (
                    <View key={i} style={sc.sMarginTop3}>
                      <Text>{`${pl.organ} (клетка ${pl.cellId} · ${pl.relation}): ${pl.action}`}</Text>
                      {pl.hardStop ? <Text style={sc.sFontSizeColor16}>{`⛔ ${pl.hardStop}`}</Text> : null}
                    </View>
                  ))}
                </View>
              ) : null}
              {t.compartments.needsMoreData?.length ? (
                <Text style={sc.sFontSizeColor17}>{`не хватает: ${t.compartments.needsMoreData.join(' · ')}`}</Text>
              ) : null}
            </View>
          ) : null}

          {/* §2M — БИБЛИОТЕКА ПО МЕМБРАНЕ + НУТРИЦЕВТИКА КАК ЧАСТЬ СХЕМЫ */}
          {t.library ? (
            <View style={c.card}>
              <Text style={sc.sFontWeight18}>{`ПРОГРАММА ПО МЕМБРАНЕ (§2M): ${t.library.name}`}</Text>
              <Text style={sc.sMarginTop9}>{`вектор: ${t.library.vector}`}</Text>
              <Text style={sc.sFontSizeColor14}>{`цели: ${t.library.goals}`}</Text>
              <Text style={sc.sFontSizeColor19}>{`мониторинг: ${t.library.monitoring}`}</Text>
              {t.library.hardStop ? <Text style={sc.sFontSizeColor20}>{`⛔ ${t.library.hardStop}`}</Text> : null}
            </View>
          ) : null}

          {t.supplements?.length ? (
            <View style={[c.card, { backgroundColor: '#f7f9f2', borderColor: '#b9c9a0', borderWidth: 1 }]}>
              <Text style={sc.sFontWeightColor21}>НУТРИЦЕВТИКА — часть схемы (§2M)</Text>
              <Text style={sc.sFontSizeColor14}>
                Лекарства открывают и толкают, добавки достраивают ткань. Дозы — ориентир.
              </Text>
              {t.supplements.map((s: any, i: number) => (
                <View key={i} style={sc.sMarginTop12}>
                  <Text style={sc.sFontWeight15}>{`${s.item}${s.dose ? ' — ' + s.dose : ''}`}</Text>
                  <Text style={sc.sFontSizeColor19}>{`${s.step} · ${s.reason}`}</Text>
                  {s.caution ? <Text style={sc.sFontSizeColor22}>{`осторожно: ${s.caution}`}</Text> : null}
                </View>
              ))}
            </View>
          ) : null}

          {/* §2K — ФАЗОВЫЙ ПЕРЕХОД: режим, тип люка, гейты, страховка */}
          {t.transition ? (
            <View style={[c.card, { borderColor: '#9fb6c9', borderWidth: 1 }]}>
              <Text style={sc.sFontWeight18}>{`ФАЗОВЫЙ ПЕРЕХОД (§2K) · режим: ${t.transition.mode}`}</Text>
              <Text style={sc.sFontSizeColor14}>{t.transition.modeWhy}</Text>
              {t.transition.lock ? (
                <View style={sc.sMarginTop12}>
                  <Text style={sc.sFontWeight15}>{`Люк ${t.transition.lock.id}: ${t.transition.lock.name} (уверенность: ${t.transition.lock.confidence})`}</Text>
                  <Text style={sc.sMarginTop9}>{`ПЕРВЫЙ ХОД — ${t.transition.lock.firstMove}`}</Text>
                  <Text style={sc.sFontSizeColor19}>{`держит: ${t.transition.lock.heldBy.join(' · ')}`}</Text>
                  <Text style={sc.sFontSizeColor22}>{`страховка: ${t.transition.lock.guard}`}</Text>
                </View>
              ) : null}
              {t.transition.gates?.length ? (
                <View style={sc.sMarginTop12}>
                  <Text style={sc.sFontWeightColor8}>CAN'T-MISS ГЕЙТ — выполняется ПЕРВЫМ, гатирует вектор</Text>
                  {t.transition.gates.map((g: any, i: number) => (
                    <Text key={i} style={sc.sMarginTop9}>{`⛳ ${g.trigger} → ${g.gate} (${g.rule})`}</Text>
                  ))}
                </View>
              ) : null}
              {t.transition.guards?.length ? (
                <View style={sc.sMarginTop12}>
                  <Text style={sc.sFontWeight15}>Страховка от переката</Text>
                  {t.transition.guards.map((g: any, i: number) => (
                    <Text key={i} style={sc.sFontSizeColor19}>{`${g.vector} → риск ${g.overshoot}: ${g.guard}`}</Text>
                  ))}
                </View>
              ) : null}
              {t.transition.causeProtection ? (
                <Text style={sc.sMarginTopColor23}>{t.transition.causeProtection}</Text>
              ) : null}
              {t.transition.needsMoreData?.length ? (
                <Text style={sc.sFontSizeColor17}>{`не хватает данных: ${t.transition.needsMoreData.join(' · ')}`}</Text>
              ) : null}
            </View>
          ) : null}

          {/* §2J.1 — ЗАМЕНЫ ПРИ ЗАПРЕТЕ: запрет не отменяет цель */}
          {t.substitutions?.length ? (
            <View style={[c.card, { backgroundColor: '#f2f8f4', borderColor: '#9ec9ae', borderWidth: 1 }]}>
              <Text style={sc.sFontWeightColor24}>ЗАМЕНЫ ПРИ ЗАПРЕТЕ (§2J.1)</Text>
              <Text style={sc.sFontSizeColor14}>
                HARD-STOP убирает препарат, но НЕ отменяет цель — цель закрывается заменой.
              </Text>
              {t.substitutions.map((s: any, i: number) => (
                <View key={i} style={sc.sMarginTop12}>
                  <Text style={sc.sFontWeight15}>{`⛔ ${s.banned} → ${s.replacement}`}</Text>
                  <Text style={sc.sFontSizeColor19}>{`почему: ${s.reason} · при: ${s.when}`}</Text>
                  {s.caveat ? <Text style={sc.sFontSizeColor22}>{`оговорка: ${s.caveat}`}</Text> : null}
                </View>
              ))}
            </View>
          ) : null}

          {/* §2J.1 — уровни гель-золь */}
          {t.levelRule ? (
            <View style={c.card}>
              <Text style={sc.sFontWeight18}>Уровни гель ⇄ золь</Text>
              <Text style={sc.sMarginTop9}>{t.levelRule}</Text>
            </View>
          ) : null}

          <Text style={sc.sColorFontSize25}>
            validated:false · препараты/классы — векторы, не дозы · диагноз ПРЕЖДЕ фазы · дозы, красные флаги, онко — за врачом.
          </Text>
        </>
      )}
    </ScrollView>
  );
}
