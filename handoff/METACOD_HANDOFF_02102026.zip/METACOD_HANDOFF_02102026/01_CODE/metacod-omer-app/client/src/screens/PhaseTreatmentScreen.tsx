import React from 'react';
import { ScrollView, Text } from 'react-native';
import { common as c } from '../styles/common.styles';
import { screenStyles as sc } from '../styles/screens.styles';
import { PhaseJourney } from '../components/PhaseJourney';
import { useAnalysis } from '../state/analysis';
export function PhaseTreatmentScreen() {
  const { analysis } = useAnalysis();
  const l1 = analysis.internalL1;
  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.l1Tag}>ВНУТРЕННИЙ L1 · только проф. Литваку</Text>
      <Text style={c.h1}>Фазовое лечение</Text>
      {!l1 ? <Text>Нет разбора. Откройте «Приём» → «Анализ».</Text> : (
        <>
          <Text style={sc.sMarginBottom29}>{`Точка зависания: ${l1.hangingPoint} · мембрана ${l1.membrane} · вектор ${l1.solGelVector} · фаза ${l1.phase}`}</Text>
          <PhaseJourney steps={l1.phaseJourney ?? []} />
        </>
      )}
    </ScrollView>
  );
}
