// METACOD-Omer · MenuScreen — единое меню кабинета (все экраны-модули)
import React from 'react';
import { ScrollView, Text, TouchableOpacity, View } from 'react-native';
import { common as c } from '../styles/common.styles';
import { screenStyles as sc } from '../styles/screens.styles';
import { menuStyles as s } from '../styles/menu.styles';
import { useAnalysis } from '../state/analysis';
import { useSession } from '../state/session';

const MODULES: { key: string; title: string; sub: string; l1?: boolean }[] = [
  { key: 'Intake', title: 'Приём', sub: 'жалобы · анализы · приборы 3D → «Анализ»' },
  { key: 'Report', title: 'Заключение (EBM)', sub: 'эталонный стандарт · страж · наружу' },
  { key: 'Queue', title: 'Очередь на подпись', sub: 'подпись врача снимает validated:false' },
  { key: 'Image', title: 'Снимок документа', sub: 'прочитанное подтверждается человеком' },
  { key: 'Survey', title: 'Анкета в разбор', sub: 'текст анкеты становится жалобами и анализами' },
  { key: 'Consent', title: 'Согласие', sub: 'на что пациент согласился — и что можно обрабатывать' },
  { key: 'Differential', title: 'Дифдиагноз', sub: 'одна связывающая причина + «не пропустить»' },
  { key: 'PhaseTreatment', title: 'Фазовое лечение', sub: 'дорога по фазам · меняется на переходах', l1: true },
  { key: 'Membrane', title: 'Мембрана', sub: 'типирование 8 состояний + протокол', l1: true },
  { key: 'Algorithm', title: 'Алгоритм диагноза', sub: 'мембрана→энергия→фаза→658+JCZ→EBM · Excel-таблицы + архитектура', l1: true },
  { key: 'Chrono', title: 'Хронотерапия', sub: 'расписание по часам · меняется по этапам' },
  { key: 'Reference', title: 'Справочник', sub: 'Метаболический пациент · титрации · геронтология · MWI' },
  { key: 'L1', title: 'Внутренний L1', sub: 'энергии/мембраны/фазы — только проф. Литваку', l1: true },
];

export function MenuScreen({ navigation }: any) {
  const { analysis } = useAnalysis();
  const { роль, выйти } = useSession();
  // ⛔ 01.10.2026: модули внутреннего слоя видит только подписывающий врач. Их экранов
  // нет в навигаторе у остальных — пункт меню вёл бы в пустоту.
  const видимые = MODULES.filter((m) => !m.l1 || роль === 'litvak');
  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.h1}>METACOD-Omer · Кабинет</Text>
      {analysis.patientName ? <Text style={sc.sColorMuted27}>{`Пациент: ${analysis.patientName} · источник: ${analysis.source ?? '—'}`}</Text> : null}
      <View style={s.grid}>
        {видимые.map((m) => (
          <TouchableOpacity key={m.key} style={[s.item, m.l1 ? s.l1 : null]} onPress={() => navigation.navigate(m.key)}>
            <Text style={s.itemTitle}>{m.title}{m.l1 ? '  ·  L1' : ''}</Text>
            <Text style={s.itemSub}>{m.sub}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <TouchableOpacity style={sc.sMarginTop12} onPress={() => { void выйти(); }}>
        <Text style={sc.sColorMuted27}>{`Выйти · роль: ${роль === 'litvak' ? 'подписывающий врач' : 'врач'}`}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}
