import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { common as c } from '../styles/common.styles';
import { screenStyles as sc } from '../styles/screens.styles';
import { useAnalysis } from '../state/analysis';
export function MembraneScreen() {
  const { analysis } = useAnalysis();
  const l1 = analysis.internalL1;
  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.l1Tag}>ВНУТРЕННИЙ L1 · только проф. Литваку</Text>
      <Text style={c.h1}>Мембрана</Text>
      {!l1 ? <Text>Нет разбора.</Text> : (
        <View style={c.card}>
          <Text>{`Тип мембраны: ${l1.membrane}`}</Text>
          <Text>{`Золь/гель вектор: ${l1.solGelVector}`}</Text>
          <Text style={sc.sMarginTopColorMuted28}>Протокол восстановления и биомаркеры — см. фазовое лечение и SKILL (монография «8 мембран»).</Text>
        </View>
      )}
    </ScrollView>
  );
}
