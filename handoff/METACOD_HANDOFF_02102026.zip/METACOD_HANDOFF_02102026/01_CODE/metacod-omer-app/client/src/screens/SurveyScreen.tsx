// METACOD-Omer · SurveyScreen — анкета в разбор.
//
// ⛔⛔ ЗАЧЕМ. Анкета (public/anketa.html) существует с 17.09.2026 и все эти дни
// уходила ПИСЬМОМ: данные больного собирались полностью и не доходили до разбора
// ни разу. Экран не переписывает анкету заново — он принимает её текст, который
// у врача уже лежит в почте и в WhatsApp, и отправляет в разбор.
//
// ⭐ Поэтому годится КАЖДАЯ анкета, заполненная с 17.09.2026, без ожидания
// приложения пациента и без повторного заполнения.
//
// ⛔ ЭКРАН НЕ РЕШАЕТ. Что удалось прочитать и чего не хватает, говорит движок
// `surveyIntake`; экран показывает его ответ дословно.
import React, { useState } from 'react';
import { ScrollView, View, Text, TextInput, TouchableOpacity, ActivityIndicator } from 'react-native';
import { analyzePatient } from '../api/firebase';
import { useAnalysis } from '../state/analysis';
import { useSession } from '../state/session';
import { common as c } from '../styles/common.styles';
import { formStyles as f } from '../styles/forms.styles';
import { reportStyles as s } from '../styles/report.styles';

export function SurveyScreen({ navigation }: any) {
  const { setAnalysis } = useAnalysis();
  const { роль } = useSession();
  const [текст, setТекст] = useState('');
  const [занят, setЗанят] = useState(false);
  const [ошибка, setОшибка] = useState('');
  const [итог, setИтог] = useState<{ разобрана: boolean; почему: string; чего?: string[] } | null>(null);

  async function отправить() {
    setЗанят(true); setОшибка(''); setИтог(null);
    try {
      const res: any = await analyzePatient({ complaints: [], анкета: текст } as any);
      const а = res['анкета'] || {};
      setИтог({ разобрана: !!а.разобрана, почему: String(а.почему || ''),
        чего: а['чего_не_хватает'] });
      // ⛔⛔ РЕМОНТ 01.10.2026. Пациента экран уводил на «Заключение» — врачебный
      // экран, которого в его приложении нет (и пустой, потому что разбора пациенту
      // не выдают). Пациенту ответ — ДРУГОЙ документ: он ложится в «Что готово».
      if (роль === 'пациент') {
        setAnalysis({ reportId: res.reportId, пациенту: res as any });
        navigation.navigate('Menu');
        return;
      }
      setAnalysis({
        reportId: res.reportId, conventional: res.conventional, internalL1: res.internalL1,
        guard: res.guard, source: res.source,
        предохранители: res['предохранители'], выпуск: res['выпуск'],
        validated: res['validated'] === true,
        'остановленный_разбор': res['остановленный_разбор'] ?? null,
      });
      if (а.разобрана) { navigation.navigate('Report'); }
    } catch (e: any) {
      setОшибка(e?.message ?? 'анкета не принята');
    } finally { setЗанят(false); }
  }

  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.h1}>Анкета в разбор</Text>
      <Text>
        {'Вставьте текст анкеты целиком — так, как он пришёл письмом или в WhatsApp. '
         + 'Рассказ больного своими словами станет первой жалобой, отмеченные симптомы — '
         + 'следующими, анализы войдут как значения.'}
      </Text>

      <TextInput
        style={[c.input, f.textarea]}
        value={текст}
        onChangeText={setТекст}
        multiline
        placeholder={'METACOD F-2026-09-17\n== 2 · Расскажите своими словами\n…'}
      />

      <TouchableOpacity
        style={[c.button, (!текст.trim() || занят) ? f.buttonOff : null]}
        disabled={!текст.trim() || занят}
        onPress={отправить}
      >
        {занят ? <ActivityIndicator color="#fff" /> : <Text style={c.buttonText}>Разобрать анкету</Text>}
      </TouchableOpacity>

      {итог ? (
        <View>
          <Text style={итог.разобрана ? s.guardOk : s.guardBad}>{итог.почему}</Text>
          {итог.чего && итог.чего.length ? (
            <View style={s.red}><Text style={s.redText}>
              {'⚠ Не найдено в анкете:\n' + итог.чего.join('\n')}
            </Text></View>
          ) : null}
        </View>
      ) : null}
      {ошибка ? <View style={s.red}><Text style={s.redText}>{ошибка}</Text></View> : null}
    </ScrollView>
  );
}
