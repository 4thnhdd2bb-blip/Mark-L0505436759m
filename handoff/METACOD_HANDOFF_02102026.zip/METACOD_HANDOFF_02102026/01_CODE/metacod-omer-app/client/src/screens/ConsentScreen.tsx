// METACOD-Omer · ConsentScreen — согласие пациента.
//
// ⛔⛔ ЗАЧЕМ. Коллекция согласий и правила доступа к ней были заведены раньше,
// но экрана, на котором согласие можно ДАТЬ, не существовало. Пустая коллекция
// с правилами — это место для согласия, а не согласие.
//
// ⭐ ЭКРАН НИЧЕГО НЕ РЕШАЕТ. Что считается согласием и когда оно требуется,
// говорит движок `consent`; сервер проверяет его ДО разбора. Здесь только выбор
// предметов и отправка.
//
// ⛔ СОГЛАСИЕ ДАЁТСЯ НА НАЗВАННОЕ. Поэтому каждый предмет — отдельный
// переключатель, а не одна галочка «я со всем согласен».
import React, { useState } from 'react';
import { ScrollView, View, Text, TouchableOpacity, Switch, ActivityIndicator } from 'react-native';
import { ПРЕДМЕТЫ_СОГЛАСИЯ } from '@shared/engines/consent';
import { saveConsent } from '../api/firebase';
import { common as c } from '../styles/common.styles';
import { formStyles as f } from '../styles/forms.styles';
import { reportStyles as s } from '../styles/report.styles';

export function ConsentScreen() {
  const [выбрано, setВыбрано] = useState<Record<string, boolean>>({});
  const [занят, setЗанят] = useState(false);
  const [итог, setИтог] = useState('');
  const [ошибка, setОшибка] = useState('');

  // ⛔ Первые три предмета обязательны для разбора: без них программа не имеет
  // права обрабатывать жалобы и анализы. Четвёртый — добровольный.
  const обязательные = ПРЕДМЕТЫ_СОГЛАСИЯ.slice(0, 3);
  const всеОбязательные = обязательные.every((п) => выбрано[п]);

  async function отправить() {
    setЗанят(true); setОшибка(''); setИтог('');
    try {
      const предметы = ПРЕДМЕТЫ_СОГЛАСИЯ.filter((п) => выбрано[п]);
      const r = await saveConsent({ предметы });
      setИтог(`Согласие записано: предметов ${(r as any).предметов}, версия «${(r as any).версия}».`);
    } catch (e: any) {
      setОшибка(e?.message ?? 'согласие не записано');
    } finally { setЗанят(false); }
  }

  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.h1}>Согласие</Text>
      <Text>
        {'Программа обрабатывает Ваши жалобы и анализы только на то, на что Вы согласились. '
         + 'Согласие можно отозвать в любой момент — запись об этом сохраняется.'}
      </Text>

      <Text style={c.h2}>На что даётся согласие</Text>
      {ПРЕДМЕТЫ_СОГЛАСИЯ.map((п, i) => (
        <View key={п} style={f.row}>
          <Switch
            value={!!выбрано[п]}
            onValueChange={(v) => setВыбрано({ ...выбрано, [п]: v })}
          />
          <Text style={f.rowText}>
            {п}{i < 3 ? ' · обязательно для разбора' : ' · по желанию'}
          </Text>
        </View>
      ))}

      {!всеОбязательные ? (
        <View style={s.red}><Text style={s.redText}>
          {'⛔ Без первых трёх пунктов разбор не выполняется: программа не имеет права '
           + 'обрабатывать Ваши данные. Это не ошибка — это Ваше право отказаться.'}
        </Text></View>
      ) : null}

      <TouchableOpacity
        style={[c.button, (!всеОбязательные || занят) ? f.buttonOff : null]}
        disabled={!всеОбязательные || занят}
        onPress={отправить}
      >
        {занят ? <ActivityIndicator color="#fff" /> : <Text style={c.buttonText}>Дать согласие</Text>}
      </TouchableOpacity>

      {итог ? <Text style={s.guardOk}>{итог}</Text> : null}
      {ошибка ? <View style={s.red}><Text style={s.redText}>{ошибка}</Text></View> : null}
    </ScrollView>
  );
}
