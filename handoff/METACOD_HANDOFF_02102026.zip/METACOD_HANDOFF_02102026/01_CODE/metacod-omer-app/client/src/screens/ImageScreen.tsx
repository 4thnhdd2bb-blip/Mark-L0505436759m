// METACOD-Omer · ImageScreen — снимок документа и подтверждение значений.
//
// ⛔⛔⛔ ГЛАВНОЕ ПРАВИЛО ЭКРАНА. Прочитанное со снимка показывается как
// ПРЕДЛОЖЕНИЯ, и ни одно из них не отмечено заранее. Человек подтверждает
// каждое отдельно, может исправить — и только тогда оно становится данными.
//
// ⭐ Почему так строго: 26.09.2026 движок принял число «220 мл/ч» со слов и
// построил на нём разбор, а в карте стояло 300 мл за смену — ход оказался
// противоположным. Правило записано в канон, §4О П10.
//
// ⛔ Экран ничего не решает: что вошло в разбор, а что ждёт, говорит сервер.
import React, { useState } from 'react';
import { ScrollView, View, Text, TextInput, TouchableOpacity, ActivityIndicator } from 'react-native';
import { submitImage } from '../api/firebase';
import { common as c } from '../styles/common.styles';
import { formStyles as f } from '../styles/forms.styles';
import { reportStyles as s } from '../styles/report.styles';

export function ImageScreen() {
  const [imageId, setImageId] = useState('');
  const [итог, setИтог] = useState<any>(null);
  const [правки, setПравки] = useState<Record<string, string>>({});
  const [занят, setЗанят] = useState(false);
  const [ошибка, setОшибка] = useState('');

  async function подтвердить(имя: string, принять: boolean) {
    setЗанят(true); setОшибка('');
    try {
      const r = await submitImage({
        imageId,
        подтвердить: { имя, принять, значение: правки[имя] || undefined },
      });
      setИтог(r);
    } catch (e: any) { setОшибка(e?.message ?? 'не принято'); }
    finally { setЗанят(false); }
  }

  async function загрузить() {
    setЗанят(true); setОшибка('');
    try { setИтог(await submitImage({ imageId })); }
    catch (e: any) { setОшибка(e?.message ?? 'снимок не принят'); }
    finally { setЗанят(false); }
  }

  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.h1}>Снимок документа</Text>
      <Text>
        {'Сфотографируйте бланк анализов, выписку или экран монитора. Программа прочитает '
         + 'цифры и покажет их вам. Ни одна из них не попадёт в разбор, пока вы её не '
         + 'подтвердите.'}
      </Text>

      <Text style={c.label}>Номер снимка</Text>
      <TextInput style={c.input} value={imageId} onChangeText={setImageId} />
      <TouchableOpacity style={[c.button, (!imageId || занят) ? f.buttonOff : null]}
        disabled={!imageId || занят} onPress={загрузить}>
        {занят ? <ActivityIndicator color="#fff" /> : <Text style={c.buttonText}>Показать прочитанное</Text>}
      </TouchableOpacity>

      {итог ? (
        <View>
          {!итог.распознано ? (
            <View style={s.red}><Text style={s.redText}>
              {'⛔ На снимке не прочитано ни одного значения. Это не значит, что анализов нет — '
               + 'значит снимок не прочитан. Попробуйте переснять при лучшем свете.'}
            </Text></View>
          ) : null}

          <Text style={c.h2}>{`Ждут подтверждения: ${итог['не_подтверждено']}`}</Text>
          {(итог['ждут_подтверждения'] || []).map((к: any) => (
            <View key={к.имя} style={f.candidate}>
              <Text>{`${к.имя}: прочитано «${к.значение}»${к.единица ? ' ' + к.единица : ''}`}</Text>
              <TextInput
                style={c.input}
                value={правки[к.имя] ?? к.значение}
                onChangeText={(v) => setПравки({ ...правки, [к.имя]: v })}
              />
              <View style={f.candidateRow}>
                <TouchableOpacity style={[c.button, f.candidateButton]} disabled={занят}
                  onPress={() => подтвердить(к.имя, true)}>
                  <Text style={c.buttonText}>Верно</Text>
                </TouchableOpacity>
                <TouchableOpacity style={f.linkInline}
                  disabled={занят} onPress={() => подтвердить(к.имя, false)}>
                  <Text style={f.link}>Не это</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}

          <Text style={c.h2}>{`Вошло в разбор: ${итог.подтверждено}`}</Text>
          {Object.keys(итог.значения || {}).map((и) => (
            <Text key={и}>{`• ${и}: ${итог.значения[и]}`}</Text>
          ))}

          {(итог.предупреждения || []).length ? (
            <View style={s.red}><Text style={s.redText}>
              {(итог.предупреждения || []).join('\n')}
            </Text></View>
          ) : null}
        </View>
      ) : null}
      {ошибка ? <View style={s.red}><Text style={s.redText}>{ошибка}</Text></View> : null}
    </ScrollView>
  );
}
