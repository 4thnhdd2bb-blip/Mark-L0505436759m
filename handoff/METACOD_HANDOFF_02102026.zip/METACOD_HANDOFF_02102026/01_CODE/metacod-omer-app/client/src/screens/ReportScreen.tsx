// METACOD-Omer · ReportScreen — заключение по эталонному стандарту (наружу)
import React from 'react';
import { ScrollView, View, Text } from 'react-native';
import { common as c } from '../styles/common.styles';
import { reportStyles as s } from '../styles/report.styles';
import { HypothesisTable } from '../components/HypothesisTable';
import { useAnalysis } from '../state/analysis';

export function ReportScreen() {
  const { analysis } = useAnalysis();
  const conv = analysis.conventional;
  if (!conv) return <ScrollView style={c.screen} contentContainerStyle={c.container}><Text>Нет разбора. Откройте «Приём».</Text></ScrollView>;
  // ⛔⛔ РЕМОНТ 28.09.2026. ЭКРАН НЕ ПОКАЗЫВАЛ ОТКАЗ.
  //
  // Было так: заголовок «Клиническое заключение», под ним пять разделов, и если
  // предохранительный контур разбор ОСТАНОВИЛ — об этом говорила одна строка
  // внутри пункта 1, между пустой таблицей гипотез и пустым обследованием.
  // Экран с заголовком «заключение» и пустыми разделами читается как заключение,
  // которое просто вышло скупым. Это тот же закон, что и в §4У:
  // БЛОК — ЭТО ОТКАЗ ВЫДАТЬ РАЗБОР, А НЕ ПОМЕТКА НА НЁМ.
  //
  // ⛔ И отдельно: пометки «не валидировано» на экране не было вовсе, хотя она
  // обязана стоять на всём, что выходит наружу, пока её не снял врач.
  const остановлен = analysis.предохранители?.выпускать === false;
  const невыпуск = !!analysis.выпуск;
  // ⭐ Р-КОНТУР-2 (подпись врача 29.09.2026). Поле есть только у врача и только
  // при блоке: сервер пациенту его не отдаёт вовсе.
  const остановленный = analysis['остановленный_разбор'];

  if (остановлен) {
    return (
      <ScrollView style={c.screen} contentContainerStyle={c.container}>
        <Text style={c.h1}>Разбор не выдан</Text>
        <View style={s.red}><Text style={s.redText}>
          {'⛔ Проверка безопасности остановила выдачу. Заключения нет — это не краткий '
           + 'разбор, а его отсутствие. Обратитесь к лечащему врачу.'}
        </Text></View>
        <Text style={s.guardBad}>
          {`Проверок пройдено: ${analysis.предохранители?.проверок ?? 0} · `
           + `остановивших: ${analysis.предохранители?.блоков ?? 0} · `
           + `требующих ответа врача: ${analysis.предохранители?.вопросов ?? 0}`}
        </Text>
        <Text style={c.h2}>Не пропустить</Text>
        <View style={s.red}><Text style={s.redText}>
          {(conv.cannotMiss ?? []).join('\n') || '—'}
        </Text></View>
        <Text style={c.h2}>Красные флаги</Text>
        <View style={s.red}><Text style={s.redText}>{(conv.redFlags ?? []).join('\n') || '—'}</Text></View>

        {/*
          ⭐⭐⭐ Р-КОНТУР-2, ПОДПИСЬ ВРАЧА 29.09.2026: «блок контура — это отказ
          выдать разбор (как сделано), ДАВАТЬ РАЗБОР НА ПРОВЕРКУ».

          ⛔ ЗАГОЛОВОК ЭКРАНА ОСТАЛСЯ «РАЗБОР НЕ ВЫДАН», и это главное. Остановленный
          разбор идёт НИЖЕ отказа, отдельным блоком и со своей пометкой — он не
          превращает отказ в заключение, как не превращала бы его и оговорка.
          Разница в том, что отказ теперь можно ПРОВЕРИТЬ: до этого дня движок мог
          остановить разбор ошибочно, и его ошибка была невидима.

          ⛔ Поле приходит от сервера только врачу. Пациентское приложение сюда не
          заходит вовсе — у него свой экран, — но даже если бы зашло, показывать
          было бы нечего: поля в ответе пациенту нет.
        */}
        {остановленный ? (
          <View>
            <Text style={c.h2}>Остановленный разбор — на проверку врачу</Text>
            <View style={s.red}><Text style={s.redText}>
              {остановленный['⛔пометка']}
            </Text></View>
            <Text style={s.guardBad}>
              {`Почему остановлен: проверок ${остановленный['почему_остановлен']?.проверок ?? '—'}`
               + ` · остановивших ${остановленный['почему_остановлен']?.блоков ?? '—'}`
               + ` · требующих ответа врача ${остановленный['почему_остановлен']?.вопросов ?? '—'}`}
            </Text>
            <Text style={c.label}>Клиническая логика, которая не вышла</Text>
            <View style={s.logic}><Text style={s.logicText}>
              {остановленный.разбор?.logic || '—'}
            </Text></View>
            <Text style={c.label}>Рабочие гипотезы, которые не вышли</Text>
            <HypothesisTable hypotheses={остановленный.разбор?.hypotheses ?? []} />
            <Text style={c.label}>Итог, который не вышел</Text>
            <Text>{остановленный.разбор?.summary || '—'}</Text>
          </View>
        ) : null}

        <Text style={s.guardBad}>{'validated: false — не валидировано'}</Text>
      </ScrollView>
    );
  }

  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.h1}>Клиническое заключение</Text>
      <Text style={analysis.guard?.clean ? s.guardOk : s.guardBad}>
        {analysis.guard?.clean ? '✓ Страж: чисто (EBM)' : '⚠ Страж: есть внутренние слова — не выпускать'}
      </Text>
      {analysis.предохранители ? (
        <Text style={analysis.предохранители.вопросов > 0 ? s.guardBad : s.guardOk}>
          {`Предохранители: проверок ${analysis.предохранители.проверок}, `
           + `вопросов к врачу ${analysis.предохранители.вопросов}`}
        </Text>
      ) : null}
      {невыпуск ? (
        <View style={s.red}><Text style={s.redText}>
          {'⚠ Гейт выпуска: разбор помечен как НЕ ГОТОВЫЙ к выдаче. Подробности — у врача.'}
        </Text></View>
      ) : null}
      <Text style={c.h2}>1. Клиническая логика</Text>
      <View style={s.logic}><Text style={s.logicText}>{conv.logic}</Text></View>
      <Text style={c.h2}>2. Рабочие гипотезы</Text>
      <HypothesisTable hypotheses={conv.hypotheses ?? []} />
      <View style={s.red}><Text style={s.redText}>{`Параллельно не пропустить: ${(conv.cannotMiss ?? []).join('; ')}`}</Text></View>
      <Text style={c.h2}>3. Полное обследование</Text>
      <Text>{`Шаг 1 — анамнез: ${(conv.workup?.step1_history ?? []).join('; ') || '—'}`}</Text>
      <Text>{`Шаг 2 — лаборатория: ${(conv.workup?.step2_labs ?? []).join('; ') || '—'}`}</Text>
      <Text>{`Шаг 3 — визуализация: ${(conv.workup?.step3_imaging ?? []).join('; ') || '—'}`}</Text>
      <Text>{`Шаг 4 — специалисты: ${(conv.workup?.step4_referrals ?? []).join('; ') || '—'}`}</Text>
      <Text style={c.h2}>4. Красные флаги</Text>
      <View style={s.red}><Text style={s.redText}>{(conv.redFlags ?? []).join('\n') || '—'}</Text></View>
      <Text style={c.h2}>5. Итог</Text>
      <Text>{conv.summary}</Text>
      {/* ⛔ Пометка стоит на КАЖДОМ выданном разборе, пока её не снял врач. */}
      <Text style={s.guardBad}>{'validated: false — не валидировано'}</Text>
    </ScrollView>
  );
}
