import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { common as c } from '../styles/common.styles';
import { screenStyles as sc } from '../styles/screens.styles';
import { useAnalysis } from '../state/analysis';
export function L1Screen() {
  const { analysis } = useAnalysis();
  const l1 = analysis.internalL1;
  return (
    <ScrollView style={c.screen} contentContainerStyle={c.container}>
      <Text style={c.l1Tag}>ВНУТРЕННИЙ L1 · только проф. Литваку · наружу НЕ выходит</Text>
      <Text style={c.h1}>Внутренний разбор</Text>
      {!l1 ? <Text>Нет разбора, либо у вас нет роли L1.</Text> : (
        <>
          <View style={c.card}>
            <Text>{`Доминанты: ${(l1.dominantEnergies ?? []).join(', ')}`}</Text>
            <Text>{`Мембрана: ${l1.membrane} · золь/гель: ${l1.solGelVector} · фаза: ${l1.phase}`}</Text>
            <Text>{`Точка зависания: ${l1.hangingPoint}`}</Text>
          </View>
          <Text style={c.h2}>Карта симптом→орган×энергия</Text>
          {(l1.organMap ?? []).map((o: any, i: number) => (
            <View key={i} style={c.card}>
              <Text style={sc.sFontWeight18}>{o.symptom}</Text>
              <Text style={sc.sColorMuted27}>{`${o.organ} × ${o.energy} · ${o.solGel} · ${o.membrane ?? ''}`}</Text>
              <Text>{`ДДЗ: ${(o.differential ?? []).join(', ')} · тест: ${o.confirmTest}`}</Text>
            </View>
          ))}
        </>
      )}
    </ScrollView>
  );
}
