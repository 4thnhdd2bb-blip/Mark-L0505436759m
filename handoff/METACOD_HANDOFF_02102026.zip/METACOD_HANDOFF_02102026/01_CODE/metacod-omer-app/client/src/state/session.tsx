// METACOD-Omer · client/src/state/session.tsx — кто вошёл и в какой роли.
//
// ⛔ Роль берётся ТОЛЬКО из claims токена (см. api/firebase.ts · рольИзТокена).
// Пока ответа нет — «проверяется», и ни одно дерево экранов не открывается:
// показать врачебное меню «на секунду, пока грузится» — это и есть утечка.
import React, { createContext, useContext, useEffect, useState } from 'react';
import type { User } from 'firebase/auth';
import { следитьЗаВходом, рольИзТокена, выйти as выйтиИзFirebase, Роль } from '../api/firebase';

export interface Сессия {
  состояние: 'проверяется' | 'не вошёл' | 'вошёл';
  user: User | null;
  роль: Роль;
  /** Перечитать роль из нового токена — после назначения роли сервером. */
  обновитьРоль: () => Promise<void>;
  выйти: () => Promise<void>;
}

const SessionContext = createContext<Сессия>({
  состояние: 'проверяется', user: null, роль: 'пациент',
  обновитьРоль: async () => {}, выйти: async () => {},
});

export function SessionProvider({ children }: { children: React.ReactNode }) {
  const [состояние, setСостояние] = useState<Сессия['состояние']>('проверяется');
  const [user, setUser] = useState<User | null>(null);
  const [роль, setРоль] = useState<Роль>('пациент');

  useEffect(() => следитьЗаВходом(async (u) => {
    setUser(u);
    if (!u) { setРоль('пациент'); setСостояние('не вошёл'); return; }
    setСостояние('проверяется');
    try { setРоль(await рольИзТокена(u)); }
    catch { setРоль('пациент'); }          // ⛔ не прочли роль — пациент, не врач
    setСостояние('вошёл');
  }), []);

  async function обновитьРоль() {
    if (user) { setРоль(await рольИзТокена(user)); }
  }

  return (
    <SessionContext.Provider value={{ состояние, user, роль, обновитьРоль, выйти: выйтиИзFirebase }}>
      {children}
    </SessionContext.Provider>
  );
}

export const useSession = () => useContext(SessionContext);
