// METACOD-Omer · client/src/state/analysis.tsx
// Единое состояние разбора: последний результат доступен всем экранам кабинета.
import React, { createContext, useContext, useState } from 'react';

export interface AnalysisState {
  reportId?: string;
  conventional?: any;
  internalL1?: any;         // только у проф. Литвака
  guard?: { clean: boolean; hits: string[] };
  source?: 'llm' | 'fallback';
  patientName?: string;
  /**
   * ⛔⛔ РЕМОНТ 28.09.2026. Этих трёх полей здесь НЕ БЫЛО, и экран приёма их
   * выбрасывал. Сервер считал предохранительный контур, отдавал вердикт выпуска
   * и пометку «не валидировано» — а состояние приложения их не хранило, так что
   * показать их было физически нечем. Отказ, которому некуда лечь, не виден.
   */
  предохранители?: { выпускать: boolean; блоков: number; вопросов: number; проверок: number };
  выпуск?: Record<string, unknown> | null;
  validated?: boolean;
  /**
   * ⛔ Пациентская выдача — ДРУГОЙ документ, а не часть врачебного.
   * Хранится отдельным полем намеренно: смешать их в одном объекте значило бы
   * рано или поздно показать не то не тому.
   */
  пациенту?: {
    состояние: string; сообщение: string;
    действия: Array<{ action: string; category: string; detail?: string }>;
    эскалации: Array<{ code: string; текст?: { ru?: string } }>;
    вопросы: Array<{ code: string; текст?: { ru?: string } }>;
  };
  /**
   * ⭐⭐⭐ Р-КОНТУР-2, ПОДПИСЬ ВРАЧА 29.09.2026: «блок контура — это отказ выдать
   * разбор (как сделано), ДАВАТЬ РАЗБОР НА ПРОВЕРКУ».
   *
   * ⛔ Поле приходит ТОЛЬКО врачу и ТОЛЬКО когда контур остановил выдачу. Оно не
   * заменяет отказ: `conventional` по-прежнему несёт отказ, и экран показывает
   * именно отказ. Это вторая, ясно помеченная копия — чтобы врач мог проверить,
   * правильно ли сработал предохранитель. Отказ, которого никто не может
   * проверить, нельзя ни исправить, ни оспорить.
   */
  'остановленный_разбор'?: {
    '⛔пометка': string;
    'почему_остановлен': { проверок: number; блоков: number; вопросов: number };
    разбор: any;
  } | null;
  /** Роль вошедшего: от неё зависит, какое приложение показывается. */
  роль?: 'врач' | 'пациент';
}

interface Ctx {
  analysis: AnalysisState;
  setAnalysis: (a: AnalysisState) => void;
}

const AnalysisContext = createContext<Ctx>({ analysis: {}, setAnalysis: () => {} });

export function AnalysisProvider({ children }: { children: React.ReactNode }) {
  const [analysis, setAnalysis] = useState<AnalysisState>({});
  return <AnalysisContext.Provider value={{ analysis, setAnalysis }}>{children}</AnalysisContext.Provider>;
}

export const useAnalysis = () => useContext(AnalysisContext);
