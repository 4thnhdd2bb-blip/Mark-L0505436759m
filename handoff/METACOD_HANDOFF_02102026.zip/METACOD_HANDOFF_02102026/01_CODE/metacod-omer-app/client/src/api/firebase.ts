// METACOD-Omer · client/src/api/firebase.ts
import { initializeApp } from 'firebase/app';
import {
  getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut,
  onAuthStateChanged, User, Auth,
} from 'firebase/auth';
import { getFunctions, httpsCallable } from 'firebase/functions';
import {
  getFirestore, collection, query, orderBy, limit, getDocs, doc, getDoc,
} from 'firebase/firestore';
import type { ЗаписьОчереди } from '@shared/engines/signQueue';
import type { PatientInput } from '@shared/types';

/**
 * ⛔⛔ РЕМОНТ 28.09.2026. ЗДЕСЬ СТОЯЛИ СЛОВА «YOUR_API_KEY» И «YOUR_APP_ID».
 *
 * Приложение с такими значениями собирается, запускается, открывает экран приёма,
 * даёт ввести жалобы и анализы — и падает только в момент вызова, уже с больным
 * перед глазами. Заглушка, которая выглядит как настройка, хуже отсутствующей
 * настройки: она откладывает отказ до самого неудобного момента.
 *
 * Теперь ключи берутся из окружения (Expo подставляет EXPO_PUBLIC_*), а если их
 * нет — приложение говорит об этом СРАЗУ и понятными словами, при запуске.
 *
 * Что задать перед сборкой (файл .env рядом с app.json):
 *   EXPO_PUBLIC_FIREBASE_API_KEY=…
 *   EXPO_PUBLIC_FIREBASE_APP_ID=…
 *   EXPO_PUBLIC_FIREBASE_PROJECT_ID=metacod-omer        (необязательно)
 *   EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN=metacod-omer.firebaseapp.com   (необязательно)
 */
// ⛔⛔ РЕМОНТ 01.10.2026. Expo подставляет EXPO_PUBLIC_* в сборку ТОЛЬКО там, где
// написано буквально `process.env.EXPO_PUBLIC_ИМЯ`. Здесь стояло `env[имя]` —
// динамический доступ, который сборщик не видит. В собранном приложении ключи были
// бы ПУСТЫМИ всегда, даже при правильном .env: «кабинет не настроен» навсегда.
// Поэтому каждое имя написано целиком, и это не стиль, а условие работы.
const ЗНАЧЕНИЯ: Record<string, string | undefined> = {
  EXPO_PUBLIC_FIREBASE_API_KEY: process.env.EXPO_PUBLIC_FIREBASE_API_KEY,
  EXPO_PUBLIC_FIREBASE_APP_ID: process.env.EXPO_PUBLIC_FIREBASE_APP_ID,
  EXPO_PUBLIC_FIREBASE_PROJECT_ID: process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID,
  EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN: process.env.EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN,
};

export const КОНФИГ_НЕ_ЗАДАН: string[] = [];
function обязательный(имя: string): string {
  const v = String(ЗНАЧЕНИЯ[имя] ?? '').trim();
  if (!v || /^YOUR_/i.test(v)) { КОНФИГ_НЕ_ЗАДАН.push(имя); return ''; }
  return v;
}

const firebaseConfig = {
  apiKey: обязательный('EXPO_PUBLIC_FIREBASE_API_KEY'),
  appId: обязательный('EXPO_PUBLIC_FIREBASE_APP_ID'),
  projectId: String(ЗНАЧЕНИЯ['EXPO_PUBLIC_FIREBASE_PROJECT_ID'] || 'metacod-omer'),
  authDomain: String(ЗНАЧЕНИЯ['EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN'] || 'metacod-omer.firebaseapp.com'),
};

/** ⭐ Одна строка для экрана: чего не хватает, чтобы кабинет вообще включился. */
export function конфигурацияГотова(): { готова: boolean; чегоНет: string[]; текст: string } {
  const чегоНет = [...КОНФИГ_НЕ_ЗАДАН];
  return {
    готова: чегоНет.length === 0,
    чегоНет,
    текст: чегоНет.length === 0
      ? 'Подключение настроено.'
      : '⛔ Кабинет не настроен: не заданы ' + чегоНет.join(', ')
        + '. Разбор выполнить нельзя — это настройка сборки, а не ошибка больного.',
  };
}

export const app = initializeApp(firebaseConfig);
// ⛔ РЕМОНТ 01.10.2026: getAuth без ключа БРОСАЕТ (auth/invalid-api-key) при загрузке
// модуля — приложение падало белым экраном вместо слов «кабинет не настроен».
// Без настройки вход просто не создаётся, а экран входа говорит, чего не хватает.
const НАСТРОЕНО = КОНФИГ_НЕ_ЗАДАН.length === 0;
export const auth: Auth | null = НАСТРОЕНО ? getAuth(app) : null;
export const db = getFirestore(app);
const functions = getFunctions(app, 'europe-west1');

function нужнаНастройка(): Auth {
  if (!auth) { throw new Error(конфигурацияГотова().текст); }
  return auth;
}

// ═══ ВХОД И РОЛЬ (01.10.2026) ═══════════════════════════════════════════
//
// ⛔⛔ РЕМОНТ. В приложении НЕ БЫЛО ВХОДА: ни одного signIn и ни одного
// onAuthStateChanged, а все функции сервера требуют req.auth. Роль бралась из
// globalThis.METACOD_ROLE, который не выставлял никто, — значит любой видел
// пациентское меню, а любой вызов сервера отвечал «Требуется вход».
//
// ⭐ Роль приходит ТОЛЬКО из claims токена, которые ставит сервер скриптом
// tools/назначить_роль.js. Выбрать роль в приложении нельзя: выбор на клиенте
// подделывается одной правкой. Неизвестность — пациент (умолчание не открывает).

export type Роль = 'litvak' | 'врач' | 'пациент';

export async function рольИзТокена(user: User | null): Promise<Роль> {
  if (!user) return 'пациент';
  // true — заставить обновить токен: роль, назначенную минуту назад, старый не знает.
  const t = await user.getIdTokenResult(true);
  if (t.claims['litvak'] === true) return 'litvak';
  if (t.claims['doctor'] === true) return 'врач';
  return 'пациент';
}

export function следитьЗаВходом(cb: (user: User | null) => void): () => void {
  if (!auth) { cb(null); return () => {}; }
  return onAuthStateChanged(auth, cb);
}

export async function войти(email: string, пароль: string): Promise<void> {
  await signInWithEmailAndPassword(нужнаНастройка(), email.trim(), пароль);
}

/** Новая учётная запись — всегда без роли, то есть пациент. Роль врача ставит только сервер. */
export async function зарегистрироваться(email: string, пароль: string): Promise<void> {
  await createUserWithEmailAndPassword(нужнаНастройка(), email.trim(), пароль);
}

export async function выйти(): Promise<void> {
  if (auth) { await signOut(auth); }
}

/** Понятные слова для частых отказов входа — вместо кода Firebase. */
export function причинаОтказаВхода(e: unknown): string {
  const код = String((e as { code?: string })?.code ?? '');
  if (/invalid-credential|wrong-password|user-not-found/.test(код)) return 'Неверная почта или пароль.';
  if (/email-already-in-use/.test(код)) return 'Такая почта уже зарегистрирована — войдите.';
  if (/weak-password/.test(код)) return 'Пароль слишком короткий: нужно не меньше 6 знаков.';
  if (/invalid-email/.test(код)) return 'Почта записана с ошибкой.';
  if (/network-request-failed/.test(код)) return 'Нет связи с сервером. Проверьте интернет.';
  if (/too-many-requests/.test(код)) return 'Слишком много попыток. Подождите и попробуйте снова.';
  return (e as Error)?.message || 'Вход не выполнен.';
}

// ═══ ОЧЕРЕДЬ ВРАЧА (01.10.2026) ═════════════════════════════════════════
// ⭐ Читается прямо из базы: правила firestore разрешают чтение только врачам.
// Решение «можно ли подписать» здесь НЕ принимается — его даёт движок signQueue.

export async function очередьЗагрузить(сколько = 50): Promise<ЗаписьОчереди[]> {
  const q = query(collection(db, 'signQueue'), orderBy('создан', 'desc'), limit(сколько));
  const s = await getDocs(q);
  return s.docs.map((d) => d.data() as ЗаписьОчереди);
}

export async function разборЗагрузить(reportId: string): Promise<Record<string, any> | null> {
  const d = await getDoc(doc(db, 'reports', reportId));
  return d.exists() ? (d.data() as Record<string, any>) : null;
}

/**
 * ⭐ ДОКУМЕНТ ПАЦИЕНТА. Без reportId — последний разбор вошедшего. До подписи
 * сервер отвечает «ждёт врача», после — действиями через фильтр выхода §4N.
 */
export async function patientDocument(reportId?: string) {
  const fn = httpsCallable(functions, 'patientDocument');
  const res = await fn(reportId ? { reportId } : {});
  return res.data as {
    reportId: string; состояние?: string; сообщение?: string; подписан: boolean; validated: boolean;
    действия?: Array<{ action: string; category: string; detail?: string }>;
    эскалации?: Array<{ code: string; текст?: { ru?: string } }>;
    вопросы?: Array<{ code: string; текст?: { ru?: string } }>;
    'выдан'?: boolean; '⛔почему'?: string; 'что_делать'?: string;
  };
}

export async function analyzePatient(patient: PatientInput & { анкета?: string }) {
  const fn = httpsCallable(functions, 'analyzePatient');
  // ⛔ Анкета едет ОТДЕЛЬНЫМ полем, а не внутри пациента: её разбирает сервер,
  // и подмешивать разобранное на клиенте значило бы разбирать её дважды.
  const { анкета, ...чистый } = patient as PatientInput & { анкета?: string };
  const res = await fn(анкета ? { patient: чистый, анкета, язык: 'ru' } : { patient: чистый, язык: 'ru' });
  return res.data as {
    reportId: string;
    conventional?: any;
    internalL1?: any;
    guard?: { clean: boolean; hits: string[] };
    source?: 'llm' | 'fallback';
    [поле: string]: any;
  };
}

/**
 * ⭐ ПОДПИСЬ ВРАЧА. Отдельного правила у клиента нет и быть не может: сервер
 * зовёт тот же apiHandle, что и разбор, а решение принимает движок signQueue.
 * Здесь только вызов.
 */
export async function signReport(данные: {
  reportId: string; вопросыПрочитаны?: boolean; отозвать?: boolean; причина?: string;
  комментарий?: string;
}) {
  const fn = httpsCallable(functions, 'signReport');
  const res = await fn(данные);
  return res.data as {
    reportId: string; состояние: string; подписано: boolean; validated: boolean;
    подпись: { uid: string; когда: number } | null; отзывов: number;
  };
}

/**
 * ⭐ СОГЛАСИЕ ПАЦИЕНТА. Версию текста и правило «что считается согласием»
 * задаёт сервер: клиент присылает только выбранные предметы.
 */
export async function saveConsent(данные: { предметы: string[] }) {
  const fn = httpsCallable(functions, 'saveConsent');
  const res = await fn(данные);
  return res.data as { ok: boolean; предметов: number; версия: string; когда: number };
}

/**
 * ⭐ СНИМОК. Клиент присылает то, что прочитала модель, — и НИЧЕГО не
 * подтверждает за человека: подтверждение идёт отдельным вызовом с ролью.
 */
export async function submitImage(данные: {
  imageId: string; вид?: string; путь?: string;
  прочитано?: Array<{ имя: string; значение: string; единица?: string; откуда?: string }>;
  подтвердить?: { имя: string; принять: boolean; значение?: string };
}) {
  const fn = httpsCallable(functions, 'submitImage');
  const res = await fn(данные);
  return res.data as {
    imageId: string; распознано: boolean; всего: number; подтверждено: number;
    'не_подтверждено': number; отклонено: number;
    значения: Record<string, number | string>;
    'ждут_подтверждения': Array<{ имя: string; значение: string; единица?: string }>;
    предупреждения: string[];
  };
}
