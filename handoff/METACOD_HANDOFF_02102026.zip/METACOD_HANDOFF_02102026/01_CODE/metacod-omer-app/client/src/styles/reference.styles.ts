import { StyleSheet } from 'react-native';
import { theme as t } from './theme';
export const refStyles = StyleSheet.create({
  block: { borderLeftWidth: 4, borderLeftColor: t.color.teal, backgroundColor: t.color.soft, borderRadius: 8, padding: t.space(3), marginBottom: t.space(2) },
  title: { fontWeight: '700', color: t.color.teal, marginBottom: 4 },
});
