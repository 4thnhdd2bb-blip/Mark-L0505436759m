// METACOD-Omer · client/src/styles/theme.ts — единая тема (цвета/типографика)
export const theme = {
  color: {
    ink: '#14312f', muted: '#5c7472', teal: '#0d6a6a', tealBg: '#eefafa',
    line: '#bfe0df', soft: '#f4fbfb', red: '#a83228', amber: '#8a5e00',
    green: '#1c7a46', blue: '#0b3d5c', purple: '#5b3ea6', l1: '#3a0a52',
    white: '#ffffff',
  },
  space: (n: number) => n * 4,
  radius: 10,
  font: { h1: 22, h2: 17, body: 15, small: 12 },
} as const;
export type Theme = typeof theme;
