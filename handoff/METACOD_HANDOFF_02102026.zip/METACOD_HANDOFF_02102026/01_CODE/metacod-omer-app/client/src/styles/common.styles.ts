import { StyleSheet } from 'react-native';
import { theme as t } from './theme';
export const common = StyleSheet.create({
  screen: { flex: 1, backgroundColor: t.color.white },
  container: { padding: t.space(4) },
  h1: { fontSize: t.font.h1, fontWeight: '800', color: t.color.teal, marginBottom: t.space(1) },
  h2: { fontSize: t.font.h2, fontWeight: '700', color: t.color.white, backgroundColor: t.color.teal, padding: t.space(2), borderRadius: 7, marginTop: t.space(4), marginBottom: t.space(2) },
  card: { borderWidth: 1, borderColor: t.color.line, borderRadius: t.radius, padding: t.space(3), marginVertical: t.space(2), backgroundColor: t.color.soft },
  label: { fontSize: t.font.small, color: t.color.muted, marginBottom: t.space(1) },
  input: { borderWidth: 1, borderColor: t.color.line, borderRadius: 8, padding: t.space(2), marginBottom: t.space(2), fontSize: t.font.body, color: t.color.ink },
  button: { backgroundColor: t.color.teal, padding: t.space(3), borderRadius: 8, alignItems: 'center' },
  buttonText: { color: t.color.white, fontWeight: '700', fontSize: t.font.body },
  l1Tag: { alignSelf: 'flex-start', backgroundColor: t.color.l1, color: t.color.white, fontSize: 11, fontWeight: '700', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 4, overflow: 'hidden' },
});
