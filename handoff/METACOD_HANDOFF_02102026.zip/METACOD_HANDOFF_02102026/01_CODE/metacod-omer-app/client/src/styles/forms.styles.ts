// METACOD-Omer · forms.styles.ts — стили экранов подписи, согласия, анкеты и снимка.
//
// ⛔ ЗДЕСЬ ЖИВУТ ВСЕ СТИЛИ ЭТИХ ЭКРАНОВ. В самих экранах встроенных стилей нет
// ни одного: требование врача 28.09.2026 — «разделите все стили на отдельные
// файлы». Встроенный стиль незаметно расходится между экранами, и через месяц
// одно и то же выглядит по-разному в четырёх местах.
import { StyleSheet } from 'react-native';
import { theme as t } from './theme';

export const formStyles = StyleSheet.create({
  /** Кнопка, недоступная по условию: видно, что она есть, и видно, что нельзя. */
  buttonOff: { opacity: 0.45 },
  /** Строка «переключатель + подпись к нему». */
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: t.space(3) },
  rowText: { marginLeft: t.space(2), flex: 1 },
  /** Ссылка-действие второго плана (отзыв подписи, «не это»). */
  link: { color: t.color.red },
  linkSpaced: { marginTop: t.space(3) },
  linkInline: { marginLeft: t.space(3), justifyContent: 'center' },
  /** Ошибка над кнопкой. */
  error: { color: t.color.red, marginBottom: t.space(2) },
  /** Многострочное поле: анкета целиком, свободный текст. */
  textarea: { height: 220, textAlignVertical: 'top' },
  /** Поле ввода средней высоты. */
  textareaSmall: { height: 100 },
  /** Блок одного значения со снимка, ждущего подтверждения. */
  candidate: { marginBottom: t.space(3) },
  candidateRow: { flexDirection: 'row' },
  candidateButton: { flex: 1 },
  /** Кнопка второго ряда в столбце. */
  buttonStacked: { marginTop: t.space(2) },
  /** Ссылка-действие без тревожного цвета (регистрация, «обновить»). */
  linkPlain: { color: t.color.teal, fontWeight: '600' },
  /** Строка списка очереди: одна запись, нажимается целиком. */
  queueItem: { borderWidth: 1, borderColor: t.color.line, borderRadius: t.radius,
    padding: t.space(3), marginBottom: t.space(2), backgroundColor: t.color.soft },
  queueItemActive: { borderColor: t.color.teal, borderWidth: 2 },
  queueMeta: { color: t.color.muted, fontSize: t.font.small },
});
