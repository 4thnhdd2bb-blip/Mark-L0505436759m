import { StyleSheet } from 'react-native';
import { theme as t } from './theme';
export const reportStyles = StyleSheet.create({
  logic: { backgroundColor: '#f3eefb', borderColor: '#cdbdec', borderWidth: 1, borderRadius: t.radius, padding: t.space(3), marginVertical: t.space(2) },
  logicText: { color: t.color.purple, fontSize: t.font.body },
  hyp: { borderWidth: 1, borderColor: t.color.line, borderRadius: 8, padding: t.space(2), marginBottom: t.space(1) },
  hypRank: { fontWeight: '800', color: t.color.teal },
  red: { backgroundColor: '#fdeceb', borderColor: '#e2a5a5', borderWidth: 1, borderRadius: t.radius, padding: t.space(3), marginVertical: t.space(2) },
  redText: { color: t.color.red, fontSize: t.font.small },
  guardOk: { color: t.color.green, fontWeight: '700' },
  guardBad: { color: t.color.red, fontWeight: '700' },
});
