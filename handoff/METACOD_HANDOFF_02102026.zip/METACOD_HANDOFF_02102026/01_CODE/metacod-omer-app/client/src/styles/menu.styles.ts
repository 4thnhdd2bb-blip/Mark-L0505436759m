import { StyleSheet } from 'react-native';
import { theme as t } from './theme';
export const menuStyles = StyleSheet.create({
  grid: { marginTop: t.space(2) },
  item: { borderWidth: 1, borderColor: t.color.line, borderRadius: t.radius, padding: t.space(3), marginBottom: t.space(2), backgroundColor: t.color.tealBg },
  itemTitle: { fontSize: 15, fontWeight: '700', color: t.color.teal },
  itemSub: { fontSize: 12, color: t.color.muted, marginTop: 2 },
  l1: { backgroundColor: '#efe7fb', borderColor: '#cdbdec' },
});
