// METACOD-Omer · screens.styles.ts — стили справочных экранов кабинета.
//
// ⛔ ВЫНЕСЕНО ИЗ ЭКРАНОВ 28.09.2026 по требованию врача: «разделите все стили
// на отдельные файлы». Встроенный стиль незаметно расходится между экранами,
// и одно и то же начинает выглядеть по-разному в разных местах.
//
// ⚠ Имена намеренно описывают СОДЕРЖАНИЕ правила, а не экран: одно и то же
// правило встречается в нескольких экранах, и дублировать его по файлам
// значило бы вернуть ту же беду под другим видом.
import { StyleSheet } from 'react-native';

export const screenStyles = StyleSheet.create({
  sFontWeightColorTeal1: { fontWeight: '700', color: '#0d6a6a' },
  sColorFontStyleMuted2: { color: '#5c7472', fontStyle: 'italic', marginTop: 4 },
  sMarginTop3: { marginTop: 4 },
  sFontWeightColor4: { fontWeight: '700', color: '#0b3d2e' },
  // ⛔⛔ РЕМОНТ 01.10.2026. Здесь стояли выражения экрана (LAYER_COLOR[st.layer],
  // cp.status) — переменные, которых в этом файле НЕТ. Файл грузится при запуске
  // приложения, и StyleSheet.create падал бы ReferenceError ещё до первого экрана.
  // Динамическая часть стиля вынесена в функции ниже, статическая осталась здесь.
  sColorFontSizeMuted5: { color: '#5c7472', fontSize: 12, marginTop: 1 },
  sFontWeightColorTeal6: { fontWeight: '700', color: '#0d6a6a' },
  sColorMarginTop7: { color: '#c0392b', marginTop: 2 },
  sFontWeightColor8: { fontWeight: '700', color: '#c0392b' },
  sMarginTop9: { marginTop: 2 },
  sMarginTop10: { marginTop: 3 },
  sMarginTopFontWeight11: { marginTop: 6, fontWeight: '700', color: '#c0392b' },
  sMarginTop12: { marginTop: 6 },
  sFontWeightColor13: { fontWeight: '600', color: '#b06a00' },
  sFontSizeColor14: { fontSize: 11, color: '#5a6b62', marginTop: 2 },
  sFontWeight15: { fontWeight: '600' },
  sFontSizeColor16: { fontSize: 11, color: '#c0392b' },
  sFontSizeColor17: { fontSize: 11, color: '#b06a00', marginTop: 4 },
  sFontWeight18: { fontWeight: '700' },
  sFontSizeColor19: { fontSize: 11, color: '#5a6b62' },
  sFontSizeColor20: { fontSize: 11, color: '#c0392b', marginTop: 2 },
  sFontWeightColor21: { fontWeight: '700', color: '#4a6b1f' },
  sFontSizeColor22: { fontSize: 11, color: '#b06a00' },
  sMarginTopColor23: { marginTop: 6, color: '#1f7a44' },
  sFontWeightColor24: { fontWeight: '700', color: '#1f7a44' },
  sColorFontSize25: { color: '#8a9a92', fontSize: 11, marginTop: 10 },
  sColorMarginBottomMuted26: { color: '#5c7472', marginBottom: 8 },
  sColorMuted27: { color: '#5c7472' },
  sMarginTopColorMuted28: { marginTop: 6, color: '#5c7472' },
  sMarginBottom29: { marginBottom: 6 },
  sColorMarginTopMuted30: { color: '#5c7472', marginTop: 8 },
});

/** Цвет текста по слою алгоритма (динамический: зависит от строки). */
export function цветСлоя(цвет: string | undefined): { color: string } {
  return { color: цвет ?? '#5c7472' };
}

/** Левая полоса карточки по слою алгоритма. */
export function полосаСлоя(цвет: string | undefined): { borderLeftWidth: number; borderLeftColor: string } {
  return { borderLeftWidth: 4, borderLeftColor: цвет ?? '#b8ccc2' };
}

/** Цвет контрольной точки: «внимание» — красный, остальное — бирюзовый. */
export function цветТочки(статус: string | undefined): { color: string } {
  return { color: статус === 'внимание' ? '#c0392b' : '#0d6a6a' };
}
