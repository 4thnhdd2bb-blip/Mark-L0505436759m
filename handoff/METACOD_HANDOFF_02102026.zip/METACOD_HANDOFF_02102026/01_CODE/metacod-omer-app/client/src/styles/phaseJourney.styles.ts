import { StyleSheet } from 'react-native';
import { theme as t } from './theme';
export const phaseStyles = StyleSheet.create({
  step: { borderWidth: 1, borderColor: '#d5d5d5', borderRadius: t.radius, marginBottom: t.space(2), overflow: 'hidden' },
  head: { padding: t.space(2), backgroundColor: t.color.l1 },
  headText: { color: t.color.white, fontWeight: '700' },
  mem: { color: '#c9b6ff', fontSize: t.font.small },
  body: { padding: t.space(2) },
  gate: { backgroundColor: '#eef6ff', borderColor: '#6aa3e0', borderWidth: 1, borderStyle: 'dashed', borderRadius: 7, padding: t.space(2), marginTop: t.space(1) },
  change: { backgroundColor: '#fff0f0', borderLeftColor: t.color.red, borderLeftWidth: 4, borderRadius: 6, padding: t.space(2), marginTop: t.space(1) },
  changeText: { color: t.color.red, fontSize: t.font.small },
  arrow: { textAlign: 'center', color: t.color.green, fontSize: 18, fontWeight: '700' },
});
