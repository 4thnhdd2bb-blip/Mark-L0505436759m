import { StyleSheet } from 'react-native';
import { theme as t } from './theme';
export const intakeStyles = StyleSheet.create({
  section: { marginBottom: t.space(4) },
  chip: { backgroundColor: t.color.tealBg, borderColor: t.color.line, borderWidth: 1, borderRadius: 16, paddingHorizontal: 10, paddingVertical: 4, marginRight: 6, marginBottom: 6 },
  chipText: { color: t.color.teal, fontSize: t.font.small },
  row: { flexDirection: 'row', flexWrap: 'wrap' },
});
