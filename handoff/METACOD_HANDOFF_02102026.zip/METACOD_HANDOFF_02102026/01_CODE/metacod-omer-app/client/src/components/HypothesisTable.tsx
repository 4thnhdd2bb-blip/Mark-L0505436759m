// METACOD-Omer · client/src/components/HypothesisTable.tsx
import React from 'react';
import { View, Text } from 'react-native';
import type { Hypothesis } from '@shared/types';
import { reportStyles as s } from '../styles/report.styles';

export function HypothesisTable({ hypotheses }: { hypotheses: Hypothesis[] }) {
  return (
    <View>
      {hypotheses.map((h) => (
        <View key={h.rank} style={s.hyp}>
          <Text><Text style={s.hypRank}>{`${h.rank}. ${h.root}`}</Text></Text>
          <Text style={{ marginTop: 2 }}>{`Объясняет: ${h.explains}`}</Text>
          <Text style={{ marginTop: 2, color: '#0b3d5c' }}>{`Подтвердить: ${h.confirm.join(', ')}`}</Text>
        </View>
      ))}
    </View>
  );
}
