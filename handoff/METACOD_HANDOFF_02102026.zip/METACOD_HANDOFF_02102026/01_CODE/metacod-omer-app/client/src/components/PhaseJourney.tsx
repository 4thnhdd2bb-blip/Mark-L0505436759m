// METACOD-Omer · client/src/components/PhaseJourney.tsx
// Дорога по фазам: на каждой фазе своя мембрана → своё лечение (меняется на переходе).
import React from 'react';
import { View, Text } from 'react-native';
import type { PhaseStep } from '@shared/types';
import { phaseStyles as s } from '../styles/phaseJourney.styles';

export function PhaseJourney({ steps }: { steps: PhaseStep[] }) {
  return (
    <View>
      {steps.map((st, i) => (
        <View key={st.phase}>
          <View style={s.step}>
            <View style={s.head}>
              <Text style={s.headText}>{`Фаза ${st.phase}`}</Text>
              <Text style={s.mem}>{`мембрана: ${st.membrane}`}</Text>
            </View>
            <View style={s.body}>
              <Text>{`Вектор: ${st.vector}`}</Text>
              <Text style={{ marginTop: 4 }}>
                {`Препараты: ${st.drugs.map((d) => d.name).join(', ')}`}
              </Text>
              <View style={s.gate}><Text>{`🚪 Ворота: ${st.gate}`}</Text></View>
              {st.changesTo && st.changesTo !== '—' ? (
                <View style={s.change}>
                  <Text style={s.changeText}>{`⇄ При переходе меняется: ${st.changesTo}`}</Text>
                </View>
              ) : null}
              {st.prognosis ? <Text style={{ marginTop: 4, color: '#5b3ea6' }}>{`Срок: ${st.prognosis}`}</Text> : null}
            </View>
          </View>
          {i < steps.length - 1 ? <Text style={s.arrow}>↓</Text> : null}
        </View>
      ))}
    </View>
  );
}
