// METACOD-Omer · клиент · Babel. Алиас @shared обязателен: без него Metro не соберёт импорты из ../shared.
module.exports = function (api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: [
      ['module-resolver', {
        alias: { '@shared': '../shared' },
        extensions: ['.ts', '.tsx', '.js', '.jsx', '.json'],
      }],
    ],
  };
};
