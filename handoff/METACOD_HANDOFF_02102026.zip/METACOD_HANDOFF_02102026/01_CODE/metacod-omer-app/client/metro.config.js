// METACOD-Omer · клиент · Metro. Папка ../shared лежит ВНЕ client/ — Metro по умолчанию её не бандлит.
// watchFolders добавляет её в область сборки, иначе импорты @shared/* падают на бандле.
const { getDefaultConfig } = require('expo/metro-config');
const path = require('path');

const projectRoot = __dirname;
const sharedRoot = path.resolve(projectRoot, '..', 'shared');

const config = getDefaultConfig(projectRoot);
config.watchFolders = [sharedRoot];
config.resolver.nodeModulesPaths = [path.resolve(projectRoot, 'node_modules')];

module.exports = config;
