// METACOD-Omer · client/App.tsx — навигация по всем модулям кабинета
import React from 'react';
import { ActivityIndicator, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import { AnalysisProvider } from './src/state/analysis';
import { SessionProvider, useSession } from './src/state/session';
import { theme } from './src/styles/theme';
import { common as c } from './src/styles/common.styles';
import { LoginScreen } from './src/screens/LoginScreen';
import { MenuScreen } from './src/screens/MenuScreen';
import { IntakeScreen } from './src/screens/IntakeScreen';
import { ReportScreen } from './src/screens/ReportScreen';
import { QueueScreen } from './src/screens/QueueScreen';
import { ConsentScreen } from './src/screens/ConsentScreen';
import { SurveyScreen } from './src/screens/SurveyScreen';
import { PatientHomeScreen } from './src/screens/PatientHomeScreen';
import { ImageScreen } from './src/screens/ImageScreen';
import { DifferentialScreen } from './src/screens/DifferentialScreen';
import { PhaseTreatmentScreen } from './src/screens/PhaseTreatmentScreen';
import { MembraneScreen } from './src/screens/MembraneScreen';
import { AlgorithmScreen } from './src/screens/AlgorithmScreen';
import { ChronoScreen } from './src/screens/ChronoScreen';
import { ReferenceScreen } from './src/screens/ReferenceScreen';
import { L1Screen } from './src/screens/L1Screen';

const Stack = createNativeStackNavigator();
const шапка = { headerStyle: { backgroundColor: theme.color.teal }, headerTintColor: '#fff' };

/**
 * ⛔⛔ РЕМОНТ 01.10.2026. Роль бралась из globalThis.METACOD_ROLE, которого не ставил
 * никто, — и, хуже, все врачебные экраны (включая «Внутренний L1» и очередь подписи)
 * были зарегистрированы в навигаторе для ОБЕИХ ролей: от роли зависел только экран
 * меню. Комментарий выше утверждал обратное. Теперь роль приходит из claims токена,
 * и у каждой роли своё дерево: экрана, которого нет в дереве, открыть нельзя.
 */
function Деревья() {
  // ⛔ Роль не выбирается в приложении: выбор на клиенте подделывается одной правкой.
  // Она приходит из claims токена, которые ставит только сервер.
  const { состояние, роль: РОЛЬ } = useSession();

  if (состояние === 'проверяется') {
    // ⛔ Пока роль не прочитана — ни одного дерева: «на секунду врачебное меню» = утечка.
    return <View style={c.screen}><ActivityIndicator color={theme.color.teal} /></View>;
  }

  return (
    <Stack.Navigator screenOptions={шапка}>
      {состояние === 'не вошёл' ? (
        <Stack.Screen name="Login" component={LoginScreen} options={{ title: 'Вход' }} />
      ) : РОЛЬ === 'пациент' ? (
        <>
          {/* ⛔ ПАЦИЕНТ: согласие, анкета, «что готово» — и ничего больше (Р-САЙТ-3). */}
          <Stack.Screen name="Menu" component={PatientHomeScreen} options={{ title: 'METACOD' }} />
          <Stack.Screen name="Survey" component={SurveyScreen} options={{ title: 'Анкета' }} />
          <Stack.Screen name="Consent" component={ConsentScreen} options={{ title: 'Согласие' }} />
        </>
      ) : (
        <>
          <Stack.Screen name="Menu" component={MenuScreen} options={{ title: 'METACOD-Omer' }} />
          <Stack.Screen name="Intake" component={IntakeScreen} options={{ title: 'Приём' }} />
          <Stack.Screen name="Report" component={ReportScreen} options={{ title: 'Заключение' }} />
          <Stack.Screen name="Image" component={ImageScreen} options={{ title: 'Снимок' }} />
          <Stack.Screen name="Survey" component={SurveyScreen} options={{ title: 'Анкета' }} />
          <Stack.Screen name="Consent" component={ConsentScreen} options={{ title: 'Согласие' }} />
          <Stack.Screen name="Queue" component={QueueScreen} options={{ title: 'Очередь на подпись' }} />
          <Stack.Screen name="Differential" component={DifferentialScreen} options={{ title: 'Дифдиагноз' }} />
          <Stack.Screen name="Chrono" component={ChronoScreen} options={{ title: 'Хронотерапия' }} />
          <Stack.Screen name="Reference" component={ReferenceScreen} options={{ title: 'Справочник' }} />
          {/* ⛔ Внутренний слой — только подписывающему врачу (claim litvak). */}
          {РОЛЬ === 'litvak' ? (
            <>
              <Stack.Screen name="PhaseTreatment" component={PhaseTreatmentScreen} options={{ title: 'Фазовое лечение' }} />
              <Stack.Screen name="Membrane" component={MembraneScreen} options={{ title: 'Мембрана' }} />
              <Stack.Screen name="Algorithm" component={AlgorithmScreen} options={{ title: 'Алгоритм диагноза' }} />
              <Stack.Screen name="L1" component={L1Screen} options={{ title: 'Внутренний L1' }} />
            </>
          ) : null}
        </>
      )}
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <SessionProvider>
      <AnalysisProvider>
        <NavigationContainer>
          <StatusBar style="light" />
          <Деревья />
        </NavigationContainer>
      </AnalysisProvider>
    </SessionProvider>
  );
}
