// METACOD-Omer · server/scripts/copy-assets.js
// tsc переносит в lib/ только .ts и импортированные .json. SKILL.md читается через fs
// и в lib/ НЕ попадал: в облаке prompt.ts молча уходил в запасную строку
// «SKILL.md не найден», и модель работала без мастер-алгоритма. Это тот самый случай
// «формально есть, фактически молчит». Скрипт копирует файл и ПАДАЕТ, если источника нет.
'use strict';
const fs = require('fs');
const path = require('path');

const ASSETS = [
  ['../shared/knowledge/SKILL.md', 'lib/shared/knowledge/SKILL.md'],
];

const root = path.join(__dirname, '..');
for (const [from, to] of ASSETS) {
  const src = path.join(root, from);
  const dst = path.join(root, to);
  if (!fs.existsSync(src)) {
    console.error(`copy-assets: нет источника ${src}`);
    process.exit(1);
  }
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.copyFileSync(src, dst);
  console.log(`copy-assets: ${from} → ${to}`);
}
