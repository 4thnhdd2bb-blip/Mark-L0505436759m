// METACOD-Omer · server/scripts/verify-lib.js — проверка перед выкладкой.
// Выкладка идёт из server/ (firebase.json: source "."): всё, что функция читает в облаке,
// обязано лежать внутри server/lib. Проверяем входную точку, SKILL.md и данные движков.
'use strict';
const fs = require('fs');
const path = require('path');

const lib = path.join(__dirname, '..', 'lib');
const must = [
  'server/src/index.js',
  'shared/knowledge/SKILL.md',
  'shared/data/diagnosis_algorithm_canon.json',
  'shared/data/drugbase.json',
];
const missing = must.filter((p) => !fs.existsSync(path.join(lib, p)));
if (missing.length) {
  console.error('verify-lib: НЕ ВЫКЛАДЫВАТЬ — в lib/ нет:\n  ' + missing.join('\n  '));
  process.exit(1);
}
const skill = fs.readFileSync(path.join(lib, 'shared/knowledge/SKILL.md'), 'utf8');
if (skill.length < 1000) {
  console.error('verify-lib: SKILL.md подозрительно короткий (' + skill.length + ' знаков)');
  process.exit(1);
}
console.log('verify-lib: OK (' + must.length + ' файлов на месте)');
