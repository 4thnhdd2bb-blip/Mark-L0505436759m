// ДЫМОВАЯ ПРОВЕРКА ЛОКАЛЬНОГО АДАПТЕРА — по-настоящему, через сокет.
//
// ⚠ ЗАЧЕМ ОТДЕЛЬНО ОТ РЕГРЕССА. Тест §4L проверяет ПОЛИТИКУ (кто пускается,
// что уходит наружу) на чистой функции — он идёт всегда и ничего не требует.
// Этот файл проверяет ТРАНСПОРТ: реальный HTTP, разбор тела, заголовок
// Authorization, коды ответа. Для него нужны зависимости сервера, поэтому
// в общий run.sh он не входит: регресс не должен падать из-за npm install.
//
// Токен здесь подложный — Firebase не зовётся. Проверяется провод, не доступ.
//
// Запуск:  cd server && npm install && npx tsc && node smoke_adapter.js

const http = require('http');
const { createAdapterServer } = require('./lib/server/src/httpAdapter');

const ВРАЧ = { uid: 'litvak', litvak: true };
// ⚠ 01.10.2026: «чужой» — это ВРАЧ без права на внутренний слой (claim doctor).
// Раньше здесь стоял вошедший БЕЗ роли и проверка ждала у него врачебный разбор.
// Но вошедший без роли — пациент, и с 28.09 он получает другой документ: проверка
// устарела, а не код (16/17). Пациент проверяется ниже отдельно.
const ЧУЖОЙ = { uid: 'omer', litvak: false, doctor: true };
const ПАЦИЕНТ_ВХОД = { uid: 'patient-1', litvak: false };

let ok = 0, fail = 0;
const check = (n, c) => { if (c) { ok++; console.log('  OK  ', n); } else { fail++; console.log('  FAIL ', n); } };

const deps = {
  // ⚠ токены ЛАТИНИЦЕЙ: в заголовок HTTP кириллица не лезет (ERR_INVALID_CHAR).
  // Поймано этой же проверкой 19.09.2026 — ровно то, ради чего она и нужна.
  verifyToken: async (t) => (t === 'doctor' ? ВРАЧ : t === 'other' ? ЧУЖОЙ
    : t === 'patient' ? ПАЦИЕНТ_ВХОД : null),
  // analyze не задан → локальный режим: без сети и без ключа Anthropic
};

function позвать(server, { method, path, token, body }) {
  return new Promise((resolve, reject) => {
    const данные = body === undefined ? null : Buffer.from(JSON.stringify(body));
    const req = http.request({
      host: '127.0.0.1', port: server.address().port, method, path,
      headers: Object.assign(
        данные ? { 'content-type': 'application/json', 'content-length': данные.length } : {},
        token ? { authorization: `Bearer ${token}` } : {},
      ),
    }, (res) => {
      const куски = [];
      res.on('data', (c) => куски.push(c));
      res.on('end', () => {
        const текст = Buffer.concat(куски).toString('utf8');
        let тело = null;
        try { тело = JSON.parse(текст); } catch (e) { /* оставим null */ }
        resolve({ status: res.statusCode, headers: res.headers, body: тело, raw: текст });
      });
    });
    req.on('error', reject);
    if (данные) req.write(данные);
    req.end();
  });
}

const ПАЦИЕНТ = {
  complaints: ['отёки голеней к вечеру', 'одышка при подъёме на этаж'],
  labs: { альбумин: 31, креатинин: 1.4 },
  age: 61, sex: 'м',
};

(async () => {
  const server = createAdapterServer(deps);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  console.log(`\nАДАПТЕР ПОДНЯТ на 127.0.0.1:${server.address().port} — проверяю провод\n`);

  const h = await позвать(server, { method: 'GET', path: '/health' });
  check('GET /health → 200 без токена', h.status === 200 && h.body.status === 'ok');
  check('заголовок x-metacod-validated: false стоит', h.headers['x-metacod-validated'] === 'false');
  check('ответ помечен no-store — разбор нигде не кэшируется', /no-store/.test(String(h.headers['cache-control'])));
  check('режим — локальный (ключа Anthropic нет)', /локальный/.test(String(h.body['режим'])));

  const нет = await позвать(server, { method: 'POST', path: '/analyze', body: ПАЦИЕНТ });
  check('POST /analyze без заголовка Authorization → 401', нет.status === 401);
  check('и разбора в теле нет', !нет.body.conventional);

  const плохой = await позвать(server, { method: 'POST', path: '/analyze', token: 'guessed', body: ПАЦИЕНТ });
  check('токен не принят → 401', плохой.status === 401);

  const чужой = await позвать(server, { method: 'POST', path: '/analyze', token: 'other', body: ПАЦИЕНТ });
  check('чужой с годным токеном → 200 и разбор пришёл', чужой.status === 200 && !!чужой.body.conventional);
  check('⭐ внутреннего слоя у чужого НЕТ', чужой.body.internalL1 === undefined);
  const внутренние = ['золь', 'гель', 'мембран', 'затвор', 'PCL-A', 'Норматония', 'JCZ', 'меридиан'];
  const утекло = внутренние.filter((w) => new RegExp(w, 'i').test(чужой.raw));
  check(`⭐⭐ в сыром теле ответа чужому нет внутренних слов (${внутренние.length} проверено)`, утекло.length === 0);
  if (утекло.length) console.log('      ⚠ УТЕКЛО: ' + утекло.join(', '));

  // ⭐ ПАЦИЕНТ (01.10.2026): другой документ, без разбора, без служебного.
  const пац = await позвать(server, { method: 'POST', path: '/analyze', token: 'patient', body: ПАЦИЕНТ });
  check('пациент → 200, но врачебного разбора нет', пац.status === 200 && пац.body.conventional === undefined);
  check('⛔ служебное (вход для очереди и документа) по проводу НЕ уходит',
    !/служебное|пациентВход|остановленный_разбор|"предохранители"/.test(пац.raw));
  const док = await позвать(server, { method: 'POST', path: '/patient-document', token: 'patient', body: {} });
  check('документ пациента без хранилища → 501, а не выдуманный ответ', док.status === 501);

  const врач = await позвать(server, { method: 'POST', path: '/analyze', token: 'doctor', body: ПАЦИЕНТ });
  check('⭐ врач получает внутренний слой', врач.status === 200 && !!врач.body.internalL1);
  check('вердикт выпуска пришёл фактом и счётом', typeof врач.body['выпуск'].выпускать === 'boolean'
    && typeof врач.body['выпуск'].заполнено === 'number');
  check('validated:false в теле', врач.body.validated === false);

  const форма = await позвать(server, { method: 'POST', path: '/analyze', token: 'doctor', body: { patient: ПАЦИЕНТ } });
  check('форма {patient:{…}} как у callable тоже работает', форма.status === 200 && !!форма.body.conventional);

  const кривой = await позвать(server, { method: 'POST', path: '/analyze', token: 'doctor', body: { labs: {} } });
  check('вход без жалоб → 400 с причиной', кривой.status === 400 && /complaints/.test(String(кривой.body.error)));

  const мусор = await new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port: server.address().port, method: 'POST', path: '/analyze',
      headers: { 'content-type': 'application/json', authorization: 'Bearer doctor' } }, (res) => {
      const к = []; res.on('data', (c) => к.push(c));
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(Buffer.concat(к).toString()) }));
    });
    req.on('error', reject); req.write('{это не json'); req.end();
  });
  check('битый JSON → 400, а не падение процесса', мусор.status === 400);

  // путь тоже ЛАТИНИЦЕЙ: кириллица в path даёт ERR_UNESCAPED_CHARACTERS (поймано 19.09.2026)
  const нетМаршрута = await позвать(server, { method: 'GET', path: '/analyze/all', token: 'doctor' });
  check('несуществующий маршрут → 404', нетМаршрута.status === 404);

  await new Promise((r) => server.close(r));
  console.log(`\nДЫМОВАЯ ПРОВЕРКА ТРАНСПОРТА: ${ok}/${ok + fail}`);
  process.exit(fail ? 1 : 0);
})();
