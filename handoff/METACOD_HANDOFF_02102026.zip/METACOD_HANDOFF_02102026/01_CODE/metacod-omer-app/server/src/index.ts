// METACOD-Omer · server/src/index.ts — Firebase Cloud Functions entry.
//
// ⛔⛔⛔ РЕМОНТ 28.09.2026. ЗДЕСЬ БЫЛА ВТОРАЯ ДВЕРЬ.
//
// Было так: callable `analyzePatient` звал `analyze()` НАПРЯМУЮ. А вся политика
// кабинета — проверка входа, страж, предохранительный контур §4У, гейт выпуска §2S,
// пометка validated:false, отказ вместо разбора — живёт в `shared/engines/cabinetApi.ts`
// и применялась только на локальном HTTP-адаптере. То есть путь, которым ходит
// МОБИЛЬНОЕ ПРИЛОЖЕНИЕ, обходил защиту целиком: контур считался внутри llmAnalyze,
// его вердикт возвращался полем `safety` — и выбрасывался, потому что `analyze()`
// его не читал и наружу не отдавал.
//
// ⭐ Это ровно тот дефект, который сторож `lint.orphans` объявляет невозможным:
// «нет второй двери, через которую ответ выходит мимо защиты». Сторож смотрел на
// граф ВЫЗОВОВ движков и не смотрел на ТРАНСПОРТЫ. Теперь транспорт один: и callable,
// и локальный адаптер зовут `apiHandle`, и правило у них физически общее.
//
// ⛔ Что НЕ изменилось: имя функции (`analyzePatient`), форма ответа для клиента и
// разделение слоёв. Внутренний слой по-прежнему уходит только при claim litvak.

import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { defineSecret } from 'firebase-functions/params';
import { initializeApp } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { apiHandle, apiВрачЛи } from '../../shared/engines/cabinetApi';
import type { ApiViewer } from '../../shared/engines/cabinetApi';
import type { ЗаписьОчереди } from '../../shared/engines/signQueue';
import type { ЗаписьСогласия } from '../../shared/engines/consent';
import type { ЗаписьСнимка } from '../../shared/engines/imageIntake';
import type { ЗаписьРазбораПациента } from '../../shared/engines/cabinetApi';
import { analyze } from './analyze';

const ANTHROPIC_API_KEY = defineSecret('ANTHROPIC_API_KEY');

initializeApp();
const db = getFirestore();
// ⛔⛔ РЕМОНТ 01.10.2026. Firestore по умолчанию ОТВЕРГАЕТ значение undefined, а в
// выходе движков оно есть законно (необязательные поля: в одном внутреннем слое их
// больше пятидесяти — phaseJourney[].prognosis и др.). Без этой настройки запись
// разбора падала бы уже ПОСЛЕ расчёта, у постели больного, ошибкой «internal».
// undefined означает «поля нет» — так оно и пишется.
db.settings({ ignoreUndefinedProperties: true });

/**
 * ⭐ ХРАНИЛИЩЕ ОЧЕРЕДИ НА ПОДПИСЬ. Приносит и уносит запись — и ничего не решает:
 * все правила подписи живут в движке `signQueue` и покрыты 34 проверками без сети.
 */
function очередьХранилище() {
  return {
    очередьЧитать: async (reportId: string): Promise<ЗаписьОчереди | null> => {
      const d = await db.collection('signQueue').doc(reportId).get();
      return d.exists ? (d.data() as ЗаписьОчереди) : null;
    },
    очередьПисать: async (запись: ЗаписьОчереди): Promise<void> => {
      await db.collection('signQueue').doc(запись.reportId).set(запись);
    },
  };
}

/**
 * ⭐ ХРАНИЛИЩЕ СОГЛАСИЙ. Приносит запись — и ничего не решает: правило живёт
 * в движке `consent`. Версия текста берётся из окружения: текст согласия сменился —
 * согласие требуется заново, и это решает не код, а номер версии.
 */
function согласиеХранилище() {
  return {
    согласиеЧитать: async (uid: string): Promise<ЗаписьСогласия | null> => {
      const d = await db.collection('consent').doc(uid).get();
      return d.exists ? (d.data() as ЗаписьСогласия) : null;
    },
    версияСогласия: process.env.CONSENT_TEXT_VERSION || 'v1',
  };
}

/**
 * ⭐ ХРАНИЛИЩЕ СНИМКОВ. Приносит и уносит запись — и ничего не решает.
 * ⛔ Сам файл живёт в Storage; сюда попадает только путь и прочитанное.
 */
function снимокХранилище() {
  return {
    снимокЧитать: async (imageId: string): Promise<ЗаписьСнимка | null> => {
      const d = await db.collection('images').doc(imageId).get();
      return d.exists ? (d.data() as ЗаписьСнимка) : null;
    },
    снимокПисать: async (запись: ЗаписьСнимка): Promise<void> => {
      await db.collection('images').doc(запись.imageId).set(запись);
    },
  };
}

/**
 * ⭐ ХРАНИЛИЩЕ РАЗБОРОВ ДЛЯ ДОКУМЕНТА ПАЦИЕНТА. Приносит запись — и ничего не решает:
 * чей разбор и что показать, решают cabinetApi, signQueue и patientContour.
 * Без reportId — последний разбор этого uid (индекс authorUid + createdAt).
 */
function отчётХранилище() {
  return {
    отчётЧитать: async (reportId: string | null, uid: string): Promise<ЗаписьРазбораПациента | null> => {
      if (reportId) {
        const d = await db.collection('reports').doc(reportId).get();
        if (!d.exists) return null;
        const x = d.data() as Record<string, unknown>;
        return { reportId: d.id, авторUid: String(x['authorUid'] ?? ''),
          пациентВход: (x['пациентВход'] as ЗаписьРазбораПациента['пациентВход']) ?? null };
      }
      const q = await db.collection('reports')
        .where('authorUid', '==', uid).orderBy('createdAt', 'desc').limit(1).get();
      if (q.empty) return null;
      const d = q.docs[0];
      const x = d.data() as Record<string, unknown>;
      return { reportId: d.id, авторUid: String(x['authorUid'] ?? ''),
        пациентВход: (x['пациентВход'] as ЗаписьРазбораПациента['пациентВход']) ?? null };
    },
  };
}

/** Код HTTP → код callable. Один на все функции, чтобы отказ не превращался в «internal». */
function кодВызова(status: number): 'unauthenticated' | 'invalid-argument' | 'not-found'
  | 'failed-precondition' | 'permission-denied' | 'unimplemented' | 'internal' {
  return status === 401 ? 'unauthenticated'
    : status === 400 ? 'invalid-argument'
    : status === 404 ? 'not-found'
    : status === 409 ? 'failed-precondition'
    : status === 451 ? 'permission-denied'
    : status === 501 ? 'unimplemented' : 'internal';
}

/**
 * callable: patientDocument — документ пациента по его разбору (01.10.2026).
 *
 * ⛔⛔ ЗАЧЕМ. Пациентская выдача считалась ОДИН раз — в момент разбора, когда подписи
 * быть не могло, — и пациент видел «ждёт врача» навсегда. Шаг 5 «Первого дня»
 * («после подписи пациент видит действия») был невыполним. Теперь пациент
 * спрашивает документ, и движок пересчитывает выдачу с состоянием подписи из очереди.
 * ⛔ Второй двери нет: тот же apiHandle.
 */
export const patientDocument = onCall(
  { region: 'europe-west1', cors: true, timeoutSeconds: 30, memory: '256MiB' },
  async (req) => {
    if (!req.auth) throw new HttpsError('unauthenticated', 'Требуется вход');
    const viewer: ApiViewer = {
      uid: req.auth.uid,
      litvak: req.auth.token.litvak === true,
      doctor: req.auth.token.doctor === true,
    };
    const ответ = await apiHandle(
      { method: 'POST', path: '/patient-document', token: 'callable', body: req.data ?? {} },
      { verifyToken: async () => viewer, ...отчётХранилище(), ...очередьХранилище() },
    );
    await db.collection('accessLog').add({
      at: FieldValue.serverTimestamp(),
      uid: viewer.uid,
      роль: apiВрачЛи(viewer) ? (viewer.litvak ? 'подписывающий врач' : 'врач') : 'пациент',
      действие: 'документ пациента',
      reportId: String((ответ.body['reportId'] ?? req.data?.reportId) ?? ''),
      принято: ответ.status === 200,
    });
    if (ответ.status !== 200) {
      throw new HttpsError(кодВызова(ответ.status), String(ответ.body['ошибка'] ?? ответ.body['error'] ?? 'документ не выдан'));
    }
    return ответ.body;
  }
);

/**
 * callable: submitImage — завести прочитанное со снимка либо подтвердить значение.
 *
 * ⛔ Идёт через apiHandle, как и всё остальное: второй двери нет.
 */
export const submitImage = onCall(
  { region: 'europe-west1', cors: true, timeoutSeconds: 60, memory: '256MiB' },
  async (req) => {
    if (!req.auth) throw new HttpsError('unauthenticated', 'Требуется вход');
    const viewer: ApiViewer = {
      uid: req.auth.uid,
      litvak: req.auth.token.litvak === true,
      doctor: req.auth.token.doctor === true,
    };
    const ответ = await apiHandle(
      { method: 'POST', path: '/image', token: 'callable', body: req.data ?? {} },
      { verifyToken: async () => viewer, ...снимокХранилище() },
    );
    await db.collection('accessLog').add({
      at: FieldValue.serverTimestamp(),
      uid: viewer.uid,
      роль: apiВрачЛи(viewer) ? (viewer.litvak ? 'подписывающий врач' : 'врач') : 'пациент',
      действие: req.data?.подтвердить ? 'подтверждение значения со снимка' : 'снимок заведён',
      imageId: String(req.data?.imageId ?? ''),
      принято: ответ.status === 200,
    });
    if (ответ.status !== 200) {
      const код = ответ.status === 400 ? 'invalid-argument'
        : ответ.status === 404 ? 'not-found'
        : ответ.status === 409 ? 'failed-precondition'
        : ответ.status === 501 ? 'unimplemented' : 'internal';
      throw new HttpsError(код as 'internal', String(ответ.body['ошибка'] ?? 'снимок не принят'));
    }
    return ответ.body;
  }
);

/**
 * callable: signReport — подпись врача под разбором.
 *
 * ⛔ Отдельной политики здесь НЕТ и быть не может: транспорт зовёт тот же apiHandle,
 * что и разбор. Иначе это была бы вторая дверь — ровно то, что закрыто сегодня утром.
 */
export const signReport = onCall(
  { region: 'europe-west1', cors: true, timeoutSeconds: 60, memory: '256MiB' },
  async (req) => {
    if (!req.auth) throw new HttpsError('unauthenticated', 'Требуется вход');
    const viewer: ApiViewer = {
      uid: req.auth.uid,
      litvak: req.auth.token.litvak === true,
      doctor: req.auth.token.doctor === true,
    };
    const ответ = await apiHandle(
      { method: 'POST', path: '/sign', token: 'callable', body: req.data ?? {} },
      { verifyToken: async () => viewer, ...очередьХранилище() },
    );

    // ⛔⛔ Журнал пишется и на ОТКАЗ подписать: попытка подписать остановленный разбор —
    // событие, о котором комиссия спросит в первую очередь.
    await db.collection('accessLog').add({
      at: FieldValue.serverTimestamp(),
      uid: viewer.uid,
      роль: apiВрачЛи(viewer) ? (viewer.litvak ? 'подписывающий врач' : 'врач') : 'пациент',
      действие: req.data?.отозвать === true ? 'отзыв подписи' : 'подпись',
      reportId: String(req.data?.reportId ?? ''),
      принято: ответ.status === 200,
      почему: ответ.status === 200 ? null : String(ответ.body['ошибка'] ?? ''),
    });

    if (ответ.status !== 200) {
      const код = ответ.status === 401 ? 'unauthenticated'
        : ответ.status === 400 ? 'invalid-argument'
        : ответ.status === 404 ? 'not-found'
        : ответ.status === 409 ? 'failed-precondition' : 'internal';
      throw new HttpsError(код as 'internal', String(ответ.body['ошибка'] ?? 'подпись не принята'));
    }
    return ответ.body;
  }
);

/**
 * callable: saveConsent — запись согласия пациента.
 *
 * ⛔ Версию текста задаёт СЕРВЕР, а не клиент: иначе приложение могло бы записать
 * согласие на любой удобный ему текст. Предметы приходят от человека, версия — нет.
 */
export const saveConsent = onCall(
  { region: 'europe-west1', cors: true, timeoutSeconds: 30, memory: '256MiB' },
  async (req) => {
    if (!req.auth) throw new HttpsError('unauthenticated', 'Требуется вход');
    const предметы = Array.isArray(req.data?.предметы)
      ? (req.data.предметы as unknown[]).map(String).filter(Boolean) : [];
    if (предметы.length === 0) {
      throw new HttpsError('invalid-argument', 'не выбрано ни одного предмета согласия');
    }
    const версия = process.env.CONSENT_TEXT_VERSION || 'v1';
    const когда = Date.now();
    await db.collection('consent').doc(req.auth.uid).set({
      ктоUid: req.auth.uid, когда, версияТекста: версия, предметы,
    });
    await db.collection('accessLog').add({
      at: FieldValue.serverTimestamp(),
      uid: req.auth.uid, действие: 'согласие дано',
      предметов: предметы.length, версия,
    });
    return { ok: true, предметов: предметы.length, версия, когда };
  }
);

/**
 * callable: analyzePatient — полный разбор через ЕДИНСТВЕННУЮ точку входа кабинета.
 *
 * conventional — всем врачам; internalL1 — только подписывающему врачу (claim litvak).
 * Роль doctor (claim doctor=true) определяет ВРАЧЕБНЫЙ контур предохранителей: без неё
 * вошедший считается пациентом, и гейт назначения к нему строже.
 */
export const analyzePatient = onCall(
  { region: 'europe-west1', cors: true, secrets: [ANTHROPIC_API_KEY], timeoutSeconds: 120, memory: '1GiB' },
  async (req) => {
    if (!req.auth) throw new HttpsError('unauthenticated', 'Требуется вход');

    process.env.ANTHROPIC_API_KEY = ANTHROPIC_API_KEY.value();

    // ⭐ Токен уже проверен транспортом callable — Firebase сделал это до нас.
    // Поэтому verifyToken здесь не перепроверяет подпись, а ПЕРЕВОДИТ уже
    // проверенные claims в зрителя кабинета. Подделать его нельзя: req.auth
    // приходит от Firebase, а не из тела запроса.
    const viewer: ApiViewer = {
      uid: req.auth.uid,
      litvak: req.auth.token.litvak === true,
      doctor: req.auth.token.doctor === true,
    };

    const ответ = await apiHandle(
      // ⛔ РЕМОНТ 01.10.2026: язык экрана пациента не передавался, и триаж читал
      // только письменность. Объявленный язык главнее письменности (§4Ю).
      { method: 'POST', path: '/analyze', token: 'callable', body: {
        patient: req.data?.patient, анкета: req.data?.анкета, язык: req.data?.язык,
        снимки: req.data?.снимки,
      } },
      { verifyToken: async () => viewer, analyze, ...очередьХранилище(), ...согласиеХранилище() },
    );

    if (ответ.status !== 200) {
      // ⛔⛔ ОТКАЗ ПО СОГЛАСИЮ — ТОЖЕ СОБЫТИЕ ДОСТУПА, и он пишется в журнал.
      // Попытка получить разбор без согласия — ровно то, о чём спросит комиссия.
      await db.collection('accessLog').add({
        at: FieldValue.serverTimestamp(),
        uid: viewer.uid,
        роль: apiВрачЛи(viewer) ? (viewer.litvak ? 'подписывающий врач' : 'врач') : 'пациент',
        действие: 'разбор отклонён',
        код: ответ.status,
        почему: String(ответ.body['ошибка'] ?? ''),
        согласие: (ответ.body['согласие'] as { вердикт?: string } | undefined)?.вердикт ?? null,
      });
      // ⛔ Причина отказа передаётся как есть: отказ, которого не видно, равен молчанию.
      const код = ответ.status === 401 ? 'unauthenticated'
        : ответ.status === 400 ? 'invalid-argument'
        : ответ.status === 404 ? 'not-found'
        : ответ.status === 451 ? 'permission-denied' : 'internal';
      throw new HttpsError(код as 'internal', String(ответ.body['ошибка'] ?? 'запрос не принят'));
    }

    const тело = ответ.body;
    // ⛔⛔ СЛУЖЕБНОЕ — в базу, НИКОГДА клиенту (01.10.2026). Здесь вердикт контура
    // для очереди, разбор для врача и пациентский вход для документа после подписи.
    const сл = (ответ.служебное ?? {}) as Record<string, unknown>;

    // ⛔ Пишем то же, что отдали. Отчёт в базе и отчёт на экране обязаны совпадать,
    // иначе заблокированный разбор осядет в истории как выданный.
    const ref = await db.collection('reports').add({
      patientName: (req.data?.patient as { name?: string } | undefined)?.name ?? null,
      createdAt: Date.now(),
      authorUid: viewer.uid,
      // ⭐ Врачебный разбор хранится ВСЕГДА — и для пациентского запуска тоже:
      // иначе врачу в очереди нечего было бы читать перед подписью. Читают его только
      // врачи (firestore.rules), пациенту он не уходит ни телом, ни документом.
      conventional: сл['conventional'] ?? тело['conventional'] ?? null,
      'остановленный_разбор': сл['остановленный_разбор'] ?? null,
      guard: тело['guard'] ?? { clean: сл['стражЧист'] !== false },
      source: тело['source'] ?? тело['источник'] ?? null,
      предохранители: сл['предохранители'] ?? null,
      выпуск: тело['выпуск'] ?? null,
      пациентВход: сл['пациентВход'] ?? null,
      контур: apiВрачЛи(viewer) ? 'врач' : 'пациент',
      validated: false,
    });
    // ⛔ Внутренний слой пишется всегда, а читает его только подписывающий врач
    // (правило /reports/{rid}/l1). Раньше он писался лишь при claim litvak у автора.
    const l1 = сл['internalL1'];
    if (l1) {
      await db.collection('reports').doc(ref.id).collection('l1').doc('internal').set(
        JSON.parse(JSON.stringify(l1)) as object,
      );
    }

    // ⭐ ЗАПИСЬ В ОЧЕРЕДЬ НА ПОДПИСЬ. Заводится на КАЖДЫЙ разбор, включая остановленный:
    // движок сам скажет, что такую запись подписать нельзя, и врач увидит её в очереди
    // с этим состоянием, а не потеряет из виду.
    // ⛔⛔ РЕМОНТ 01.10.2026: вердикт берётся из СЛУЖЕБНОГО, а не из тела. У пациента
    // в теле его нет (и быть не должно) — раньше пациентский разбор ложился в очередь
    // с null, и очередь по fail-closed не подписывала его никогда.
    const п = сл['предохранители'] as { выпускать: boolean; блоков: number;
      вопросов: number; проверок: number; снимаетсяПодписью?: boolean } | undefined;
    await db.collection('signQueue').doc(ref.id).set({
      reportId: ref.id,
      создан: Date.now(),
      авторUid: viewer.uid,
      предохранители: п ?? null,
      стражЧист: сл['стражЧист'] !== false,
    });

    // ⛔⛔ ЖУРНАЛ ДОСТУПА. Заведён 28.09.2026: до него нельзя было ответить на вопрос
    // «кто и когда получил разбор по этому больному» — а это первый вопрос и комиссии
    // Хельсинки, и регулятора. Журнал пишется ВСЕГДА, в том числе когда разбор
    // заблокирован: отказ — тоже событие доступа.
    await db.collection('accessLog').add({
      at: FieldValue.serverTimestamp(),
      uid: viewer.uid,
      роль: apiВрачЛи(viewer) ? (viewer.litvak ? 'подписывающий врач' : 'врач') : 'пациент',
      действие: 'разбор',
      reportId: ref.id,
      выдан: (сл['предохранители'] as { выпускать?: boolean } | undefined)?.выпускать !== false,
      источник: тело['source'] ?? null,
      // ⛔ Согласие попадает в журнал ВСЕГДА, включая состояние «не проверялось»:
      // именно этот вопрос комиссия задаёт первым.
      согласие: (тело['согласие'] as { вердикт?: string } | undefined)?.вердикт ?? 'неизвестно',
    });

    return { reportId: ref.id, ...тело };
  }
);
