// METACOD-Omer · server/src/llmAnalyze.ts
// Вызов модели + ПРИНУДИТЕЛЬНЫЙ страж: наружу уходит только чистый conventional.

import Anthropic from '@anthropic-ai/sdk';
import { buildSystemPrompt, buildUserPrompt } from './prompt';
import { retrieveDiseases, retrieveDrugs } from './retrieve';
import { enforceConventional, guardConventional } from '../../shared/engines/guard';
import { runAnalysis } from '../../shared/engines/pipeline';
import { enforceRegulation } from '../../shared/engines/protocol';
import { sgПроверить, ВердиктКонтура } from '../../shared/engines/safetyGate';
import type { PatientInput, AnalysisResult, RegulationView } from '../../shared/types';

const MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5';

export interface LlmResult {
  result: AnalysisResult;
  guard: { clean: boolean; hits: string[]; redactedCount: number };
  /** §2S: вердикт гейта выпуска. Едет с КАЖДЫМ разбором, включая ответ модели. */
  release: RegulationView['выпуск'];
  /**
   * ⛔⛔ §4У: предохранительный контур. Едет с КАЖДЫМ разбором — и от модели,
   * и из запасного пайплайна. До 28.09.2026 запасной путь не был защищён вовсе,
   * а гейт назначения, подписанный врачом, не вызывался ни на одном из путей.
   */
  safety: ВердиктКонтура;
  source: 'llm' | 'fallback';
  model?: string;
}

export async function llmAnalyze(patient: PatientInput): Promise<LlmResult> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return finalize(patient, runAnalysis(patient), 'fallback');

  try {
    const diseases = retrieveDiseases(patient, 6);
    const drugs = retrieveDrugs(patient, diseases, 24);
    const client = new Anthropic({ apiKey });

    const msg = await client.messages.create({
      model: MODEL, max_tokens: 8000, system: buildSystemPrompt(),
      messages: [{ role: 'user', content: buildUserPrompt(patient, diseases, drugs) }],
    });
    const text = msg.content.map((c: any) => (c.type === 'text' ? c.text : '')).join('');
    const result = extractJson(text) as AnalysisResult;
    return finalize(patient, result, 'llm', MODEL);
  } catch (e) {
    const fb = runAnalysis(patient);
    (fb.conventional as any).logic = `[fallback: ${(e as Error).message}] ` + fb.conventional.logic;
    return finalize(patient, fb, 'fallback');
  }
}

/**
 * ГАРАНТИЯ 1: conventional прогоняется через enforceConventional (вырезать+перепроверить).
 * ГАРАНТИЯ 2 (§2S): любой разбор — хоть от модели, хоть из пайплайна — проходит регламент.
 * Модель может вернуть красивый JSON с пустой диетой и без прогноза: гейт скажет это вслух.
 * ⛔⛔ ГАРАНТИЯ 3 (§4У, 28.09.2026): любой разбор проходит ПРЕДОХРАНИТЕЛЬНЫЙ КОНТУР.
 *   Страж проверяет ЯЗЫК, регламент — ПОЛНОТУ, контур — СОДЕРЖАНИЕ: пуст ли разбор,
 *   сняты ли маски, открыт ли гейт назначения, не назван ли контролёр истощённому,
 *   названо ли окно чтения, спрошено ли «не выполнено ли уже», есть ли средство в базе.
 *   Контур стоит ПОСЛЕ разбора намеренно: модель не исполняет наш код, но её готовый
 *   ответ проверить можно — и тем же контуром, что и запасной разбор.
 */
function finalize(
  patient: PatientInput, result: AnalysisResult, source: 'llm' | 'fallback', model?: string,
): LlmResult {
  const enforced = enforceConventional(result.conventional);
  result.conventional = enforced.obj;
  // финальная перепроверка (должна быть чистой всегда)
  const verify = guardConventional(result.conventional);
  enforceRegulation(patient, result);
  const release = result.internalL1['регламент']!.выпуск;
  const safety = sgПроверить({
    контур: 'врач',
    подписьВрача: false,
    беременность: 'неизвестно',
    возраст: patient.age,
    пол: patient.sex,
    жалобы: patient.complaints,
    препараты: patient.currentDrugs,
    диагнозы: patient.complaints,
    полюс: String(result.internalL1.membrane || ''),
    разбор: result.conventional as unknown as Record<string, never>,
  });
  return {
    result,
    guard: { clean: verify.clean, hits: verify.hits, redactedCount: enforced.redactedCount },
    release,
    safety,
    source, model,
  };
}

function extractJson(text: string): unknown {
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const raw = fence ? fence[1] : text;
  const s = raw.indexOf('{'), e = raw.lastIndexOf('}');
  if (s === -1 || e === -1) throw new Error('модель не вернула JSON');
  return JSON.parse(raw.slice(s, e + 1));
}
