// METACOD-Omer · server/src/analyze.ts
import { llmAnalyze } from './llmAnalyze';
import type { PatientInput, AnalysisResult } from '../../shared/types';

export interface AnalyzeResponse {
  conventional: AnalysisResult['conventional']; // гарантированно чистый (страж enforce)
  /**
   * ⛔⛔ РЕМОНТ 01.10.2026. Внутренний слой отдаётся ВСЕГДА — серверу, а не зрителю.
   * Было: `viewer.isLitvak ? internalL1 : undefined`. Тогда у любого врача, кроме
   * подписывающего, apiHandle не получал внутреннего слоя и пропускал всё, что на
   * нём стоит: полюс и матрицу для контура §4У, дифряд, следующий шаг, шаг 0
   * почечного синдрома, блок отёка. Безопасность зависела от того, кто смотрит.
   * Кому слой уходит НАРУЖУ, решает только apiHandle (Правило 2: litvak === true).
   */
  internalL1?: AnalysisResult['internalL1'];
  guard: { clean: boolean; hits: string[]; redactedCount: number };
  source: 'llm' | 'fallback';
  model?: string;
}

export async function analyze(patient: PatientInput, _viewer: { isLitvak: boolean }): Promise<AnalyzeResponse> {
  const { result, guard, source, model } = await llmAnalyze(patient);
  // Двойная страховка: если по какой-то причине не чисто — отдаём безопасную заглушку.
  const conventional = guard.clean ? result.conventional : safeConventional(result.conventional);
  return {
    conventional,
    internalL1: result.internalL1,
    guard, source, model,
  };
}

/**
 * Крайняя мера: если verify не чист — вернуть скелет без потенциальных утечек.
 *
 * ⛔⛔ РЕМОНТ 28.09.2026. Здесь стоял тот же дефект, что и в `apiSafeConventional`:
 * текст «заключение формируется» при выброшенном содержании и `guardClean: true`
 * при заведомо НЕчистом разборе. Скелет обязан говорить, что случилось.
 * Правило одно на оба места: ЗАГЛУШКА В ФОРМЕ РАЗБОРА ЧИТАЕТСЯ КАК РАЗБОР.
 */
function safeConventional(c: AnalysisResult['conventional']): AnalysisResult['conventional'] {
  return {
    logic: '⛔ Разбор не выдан: проверка нашла в нём то, что наружу не выходит, '
      + 'и содержание убрано. Обратитесь к лечащему врачу.',
    hypotheses: [], cannotMiss: c.cannotMiss ?? [],
    workup: c.workup ?? { step1_history: [], step2_labs: [], step3_imaging: [], step4_referrals: [] },
    redFlags: c.redFlags ?? [],
    summary: '⛔ Заключения нет: разбор остановлен стражем. validated:false.',
    guardClean: false,
  };
}
