// METACOD-Omer · server/src/httpAdapter.ts
// ЛОКАЛЬНЫЙ HTTP-АДАПТЕР КАБИНЕТА. Заказан врачом 19.09.2026:
// «пиши локальный адаптер, Firebase Auth как сейчас».
//
// ⭐ ЗДЕСЬ НЕТ НИ ОДНОГО РЕШЕНИЯ. Вся политика — кто пускается, что уходит
// наружу, что остаётся внутри — живёт в shared/engines/cabinetApi.ts и
// покрыта тестом §4L. Этот файл только: принять сокет, прочитать тело,
// вырезать токен, позвать apiHandle, записать ответ.
// Если однажды понадобится изменить ПРАВИЛО — менять надо cabinetApi.ts,
// иначе правило разойдётся между транспортами и наружу уйдёт разное.
//
// ⛔ СЛУШАЕТ 127.0.0.1 — только эта машина. Чтобы открыть наружу, нужно
// явно задать HOST, и тогда ответственность за TLS и firewall на том,
// кто это сделал. По умолчанию адаптер в интернет НЕ смотрит.
//
// Запуск:
//   cd server && npm install && npx tsc
//   GOOGLE_APPLICATION_CREDENTIALS=… node lib/server/src/httpAdapter.js
// Переменные: PORT (8787), HOST (127.0.0.1), ANTHROPIC_API_KEY (необязателен).

import * as http from 'http';
import { initializeApp, applicationDefault, getApps } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { apiHandle, apiRoutes } from '../../shared/engines/cabinetApi';
import type { ApiDeps, ApiViewer } from '../../shared/engines/cabinetApi';
import { analyze } from './analyze';

const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '127.0.0.1';
const MAX_BODY = 25 * 1024 * 1024;   // 25 МБ: блок chrono с рядами бывает тяжёлым

/**
 * Проверка токена — та же, что у callable analyzePatient:
 * Firebase ID token, внутренний слой только при custom claim litvak=true.
 */
async function verifyToken(token: string): Promise<ApiViewer | null> {
  if (!getApps().length) initializeApp({ credential: applicationDefault() });
  try {
    const decoded = await getAuth().verifyIdToken(token);
    // ⛔ РЕМОНТ 01.10.2026: claim doctor не читался, и любой врач без litvak шёл
    // через этот адаптер ПАЦИЕНТСКИМ контуром — то же, что было закрыто 28.09 в callable.
    return { uid: decoded.uid, litvak: decoded.litvak === true, doctor: decoded.doctor === true };
  } catch {
    return null;   // причину наружу не отдаём: она подсказывает, как подбирать токен
  }
}

/** Ключ Anthropic есть → полный разбор с моделью. Нет → локальный пайплайн. */
function depsFor(): ApiDeps {
  const withModel = !!process.env.ANTHROPIC_API_KEY;
  return {
    verifyToken,
    analyze: withModel
      ? (p, viewer) => analyze(p, viewer) as any
      : undefined,
  };
}

function readBody(req: http.IncomingMessage): Promise<{ ok: true; value: unknown } | { ok: false; why: string }> {
  return new Promise((resolve) => {
    const куски: Buffer[] = [];
    let размер = 0;
    req.on('data', (c: Buffer) => {
      размер += c.length;
      if (размер > MAX_BODY) {
        resolve({ ok: false, why: `тело больше ${MAX_BODY / 1024 / 1024} МБ` });
        req.destroy();
        return;
      }
      куски.push(c);
    });
    req.on('end', () => {
      const текст = Buffer.concat(куски).toString('utf8');
      if (!текст) return resolve({ ok: true, value: undefined });
      try {
        resolve({ ok: true, value: JSON.parse(текст) });
      } catch (e) {
        resolve({ ok: false, why: `тело не разобралось как JSON: ${(e as Error).message}` });
      }
    });
    req.on('error', (e) => resolve({ ok: false, why: (e as Error).message }));
  });
}

export function createAdapterServer(deps: ApiDeps = depsFor()): http.Server {
  return http.createServer(async (req, res) => {
    const отдать = (status: number, body: unknown) => {
      const текст = JSON.stringify(body);
      res.writeHead(status, {
        'content-type': 'application/json; charset=utf-8',
        'content-length': Buffer.byteLength(текст),
        'cache-control': 'no-store',            // ⛔ разбор пациента не кэшируется нигде
        'x-metacod-validated': 'false',
      });
      res.end(текст);
      // ⛔ В журнал идёт ТОЛЬКО маршрут и код. Ни жалоб, ни анализов, ни имени.
      console.log(`${req.method} ${(req.url || '').split('?')[0]} → ${status}`);
    };

    const body = await readBody(req);
    if (!body.ok) return отдать(400, { error: body.why, validated: false });

    const auth = String(req.headers['authorization'] || '');
    const token = /^Bearer\s+(.+)$/i.exec(auth)?.[1];

    try {
      const ответ = await apiHandle(
        { method: req.method || 'GET', path: req.url || '/', token, body: body.value },
        deps,
      );
      отдать(ответ.status, ответ.body);
    } catch (e) {
      // Текст исключения наружу не отдаём — он может нести кусок данных пациента.
      console.error('адаптер: внутренняя ошибка', (e as Error).name);
      отдать(500, { error: 'внутренняя ошибка адаптера', validated: false });
    }
  });
}

if (require.main === module) {
  const server = createAdapterServer();
  server.listen(PORT, HOST, () => {
    console.log(`METACOD адаптер слушает http://${HOST}:${PORT}`);
    for (const r of apiRoutes()) {
      console.log(`  ${r.метод} ${r.путь}${r.токен ? ' (нужен Firebase ID token)' : ''} — ${r.что}`);
    }
    console.log(process.env.ANTHROPIC_API_KEY
      ? '  режим: с вызовом модели'
      : '  режим: локальный — ANTHROPIC_API_KEY не задан, считает свой пайплайн');
  });
}
