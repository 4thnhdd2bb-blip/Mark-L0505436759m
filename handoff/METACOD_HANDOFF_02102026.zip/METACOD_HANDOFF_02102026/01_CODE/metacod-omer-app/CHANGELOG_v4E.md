# METACOD-Omer · §Е СЛОЙ ПОДАЧИ (Мастер-Стандарт v4) — сборка PHYSMATRIX + §Е

Дата: 2026-08-31. Обратная совместимость: RU-вывод НЕ меняется (golden-тест байт-в-байт).

## Что добавлено
- `shared/engines/releaseLayer.ts` — §Е: LABELS (ru/en/he), рыночный футер, `releaseGate`, `scrubEnBody`, `applyMarket`.
- `shared/engines/report.ts` — `renderMarkdown(c, lang='ru')`: локализованные заголовки + рыночный футер; для EN — вычистка бренда METACOD/`validated:false` из тела. Язык по умолчанию `ru` → прежний вывод байт-в-байт.
- Знания (читает промпт): §Е добавлен в `shared/knowledge/СТАНДАРТ_ПОЛНОГО_КОНВЕНЦИОНАЛЬНОГО_ОТЧЁТА.md` и `shared/knowledge/SKILL.md`.
- Тест `shared/engines/__tests__/releaseLayer.test.js` (16/16) + встроен в `run.sh`.

## Правила §Е (наружный слой; L1 не затрагивается)
- Е1 Language guard: EN/HE = 0 кириллицы; служебные строки через LABELS; HE = RTL. Гейт: кириллица(EN/HE)=0 И стоп-слова стража=0.
- Е2 Атрибуция: без личного имени врача наружу; RU/HE = «Тель-Авив, Израиль», EN = без локации.
- Е3 Бренд/дисклеймер: RU/HE — бренд+бейдж+validated:false; EN (США) — без бренда METACOD/бейджа/токена validated:false, «не диагноз» словами в теле.
- Инвариант безопасности (все языки): не-диагностичность, приоритет сыворотки, онко→онкологу, red flags, hold/block/caution — всегда.

## Тесты
    bash shared/engines/__tests__/run.sh
Ожидается: «СТРАЖ: регресс пройден.» + «§Е release-layer: 16/16» + «§Е: слой подачи пройден.»

## Что проверить руками ПЕРЕД продом (end-to-end здесь не гонялся)
1. Прогнать один реальный разбор с `lang='en'` и `lang='he'` через сервер (llmAnalyze → renderMarkdown(conv, lang)).
2. Убедиться: EN без METACOD/validated:false/кириллицы; HE RTL + «תל אביב, ישראל»; RU — как раньше.
3. Точка вызова языка: там, где сейчас `renderMarkdown(result.conventional)`, передать язык пациента/запроса вторым аргументом.
