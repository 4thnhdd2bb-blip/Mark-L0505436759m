// Сквозной прогон «Первого дня» на эмуляторах Firebase: настоящие учётные записи,
// настоящие правила Firestore, функции из собранного server/lib.
const { createRequire } = require('module');
const path = require('path');
const { execFileSync } = require('child_process');
const APP = process.argv[2];
const req = createRequire(path.join(APP, 'package.json'));
const { initializeApp, deleteApp } = req('firebase/app');
const { getAuth, connectAuthEmulator, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } = req('firebase/auth');
const { getFunctions, connectFunctionsEmulator, httpsCallable } = req('firebase/functions');
const { getFirestore, connectFirestoreEmulator, collection, getDocs, getDoc, doc, setDoc, query, orderBy, limit } = req('firebase/firestore');

let ok = 0, fail = 0;
const check = (n, c, extra) => { if (c) { ok++; console.log('  OK  ', n); } else { fail++; console.log('  FAIL', n, extra !== undefined ? JSON.stringify(extra).slice(0, 400) : ''); } };

function клиент(имя) {
  const app = initializeApp({ apiKey: 'demo-key', projectId: 'demo-metacod', appId: '1:1:web:1' }, имя);
  const auth = getAuth(app); connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
  const fns = getFunctions(app, 'europe-west1'); connectFunctionsEmulator(fns, '127.0.0.1', 5001);
  const db = getFirestore(app); connectFirestoreEmulator(db, '127.0.0.1', 8085);
  const call = (n, d) => httpsCallable(fns, n, { timeout: 120000 })(d).then((r) => r.data);
  return { app, auth, db, call };
}
async function ошибка(p) { try { await p; return null; } catch (e) { return e; } }
function роль(email, r) {
  return execFileSync('node', [path.join(APP, 'tools', 'назначить_роль.js'), email, r], {
    env: { ...process.env, FIREBASE_AUTH_EMULATOR_HOST: '127.0.0.1:9099', GCLOUD_PROJECT: 'demo-metacod',
      GOOGLE_APPLICATION_CREDENTIALS: process.argv[3] }, encoding: 'utf8' });
}

(async () => {
  const П = 'patient@test.example', В = 'doctor@test.example', Л = 'litvak@test.example', ПАР = 'test-pass-123';

  // ── 1 · ВХОД И РОЛИ ──
  const пац = клиент('пациент');
  await createUserWithEmailAndPassword(пац.auth, П, ПАР);
  const t0 = await пац.auth.currentUser.getIdTokenResult();
  check('1 · новая учётная запись — без роли (пациент)', !t0.claims.doctor && !t0.claims.litvak);

  // ── 2 · СОГЛАСИЕ ──
  const безСогласия = await ошибка(пац.call('analyzePatient', { patient: { complaints: ['плохо сплю', 'устаю к вечеру'], labs: {} } }));
  check('2 · пациент без согласия → отказ (permission-denied)', !!безСогласия && /permission-denied/.test(String(безСогласия.code)), безСогласия && безСогласия.code);
  const { ПРЕДМЕТЫ_СОГЛАСИЯ } = require(path.join(APP, 'server/lib/shared/engines/consent'));
  const согл = await пац.call('saveConsent', { предметы: ПРЕДМЕТЫ_СОГЛАСИЯ.slice(0, 3) });
  check('2 · согласие записано, версия v1', согл.ok === true && согл.версия === 'v1');

  // ── 3 · РАЗБОР ПАЦИЕНТА ──
  const р = await пац.call('analyzePatient', { patient: { complaints: ['плохо сплю', 'устаю к вечеру'], labs: {} }, язык: 'ru' });
  check('3 · пациенту пришёл reportId', !!р.reportId);
  check('3 · ⛔ пациенту нет врачебного разбора, вердикта и служебного',
    !/"conventional"|"internalL1"|"предохранители"|"служебное"|"пациентВход"/.test(JSON.stringify(р)), Object.keys(р));
  const д0 = await пац.call('patientDocument', {});
  check('3 · документ пациента до подписи — «ждёт врача»', д0.подписан === false && д0.состояние === 'ждёт врача', д0);
  const чужоеЧтение = await ошибка(getDoc(doc(пац.db, 'reports', р.reportId)));
  check('3 · ⛔ правила: пациент не читает reports', !!чужоеЧтение && /permission/.test(String(чужоеЧтение.code)));
  const запись = await ошибка(setDoc(doc(пац.db, 'signQueue', р.reportId), { подпись: { uid: 'x' } }));
  check('3 · ⛔ правила: запись в очередь с телефона запрещена', !!запись && /permission/.test(String(запись.code)));
  const пацПодпись = await ошибка(пац.call('signReport', { reportId: р.reportId, вопросыПрочитаны: true }));
  check('3 · ⛔ пациент подписать не может', !!пацПодпись, пацПодпись && пацПодпись.message);

  // ── 1 · РОЛИ ЧЕРЕЗ СКРИПТ ──
  const врач = клиент('врач'); const литвак = клиент('литвак');
  await createUserWithEmailAndPassword(врач.auth, В, ПАР);
  await createUserWithEmailAndPassword(литвак.auth, Л, ПАР);
  const выводРоли = роль(В, 'doctor'); роль(Л, 'litvak');
  check('1 · назначить_роль.js отработал', /Роль выставлена/.test(выводРоли), выводРоли);
  await signOut(врач.auth); await signInWithEmailAndPassword(врач.auth, В, ПАР);
  await signOut(литвак.auth); await signInWithEmailAndPassword(литвак.auth, Л, ПАР);
  const tв = await врач.auth.currentUser.getIdTokenResult(true);
  const tл = await литвак.auth.currentUser.getIdTokenResult(true);
  check('1 · после выхода и входа врач несёт claim doctor', tв.claims.doctor === true && !tв.claims.litvak);
  check('1 · подписывающий врач несёт litvak и doctor', tл.claims.litvak === true && tл.claims.doctor === true);

  // ── 5 · ОЧЕРЕДЬ: пациентский разбор с вердиктом ──
  const оч = await getDocs(query(collection(врач.db, 'signQueue'), orderBy('создан', 'desc'), limit(20)));
  const зап = оч.docs.map((d) => d.data()).find((x) => x.reportId === р.reportId);
  check('5 · ⭐ пациентский разбор в очереди С ВЕРДИКТОМ контура (раньше null)',
    !!зап && !!зап.предохранители && typeof зап.предохранители.выпускать === 'boolean', зап);
  const рп = await getDoc(doc(врач.db, 'reports', р.reportId));
  check('5 · врач читает разбор пациента для проверки перед подписью',
    рп.exists() && !!(рп.data().conventional || рп.data()['остановленный_разбор']));
  const л1врач = await ошибка(getDoc(doc(врач.db, 'reports', р.reportId, 'l1', 'internal')));
  check('5 · ⛔ врач без litvak не читает внутренний слой', !!л1врач && /permission/.test(String(л1врач.code)));
  const л1 = await getDoc(doc(литвак.db, 'reports', р.reportId, 'l1', 'internal'));
  check('5 · ⭐ внутренний слой пациентского разбора записан (undefined больше не роняет запись)', л1.exists());

  const безГалки = await ошибка(врач.call('signReport', { reportId: р.reportId, вопросыПрочитаны: false }));
  check('5 · ⛔ без «вопросы видел» подпись не принята', !!безГалки, безГалки && безГалки.message);
  // ⚠ СТЕНД: без ключа модели запасной разбор пуст (гипотез 0), и §4У·1 его законно
  // блокирует. Чтобы пройти ветку «подписано → документ пациента» на настоящих
  // функциях и правилах, вердикт разбора с моделью имитируется служебной записью.
  check('5 · без ключа модели пустой разбор законно остановлен (§4У·1), подпись невозможна',
    зап.предохранители.выпускать === false && зап.предохранители.снимаетсяПодписью === false);
  const админ = req('firebase-admin');
  process.env.FIRESTORE_EMULATOR_HOST = '127.0.0.1:8085';
  if (!админ.apps.length) админ.initializeApp({ projectId: 'demo-metacod' });
  await админ.firestore().collection('signQueue').doc(р.reportId).update({
    предохранители: { выпускать: true, блоков: 0, вопросов: 2, проверок: 26, снимаетсяПодписью: false } });
  const можноЛи = true;
  const подп = await ошибка(врач.call('signReport', { reportId: р.reportId, вопросыПрочитаны: true }));
  check('5 · ⭐ подпись врача под пациентским разбором ' + (можноЛи ? 'принята' : 'отклонена (иной блок)'),
    можноЛи ? подп === null : подп !== null, подп && подп.message);
  if (можноЛи) {
    const д1 = await пац.call('patientDocument', {});
    check('5 · ⭐ после подписи пациент получает документ: подписан, validated:true', д1.подписан === true && д1.validated === true, д1);
    const отз = await врач.call('signReport', { reportId: р.reportId, отозвать: true, причина: 'проверка отзыва' });
    check('5 · отзыв подписи: validated снова false', отз.validated === false && отз.отзывов === 1);
    const д2 = await пац.call('patientDocument', {});
    check('5 · после отзыва пациент снова видит «ждёт врача»', д2.подписан === false, д2);
  }

  // ── 3 · РАЗБОР ВРАЧА И ПОДПИСЫВАЮЩЕГО ВРАЧА ──
  const ВХОД = { complaints: ['отёки голеней к вечеру', 'одышка при подъёме на этаж'], labs: { альбумин: 31, креатинин: 1.4 }, age: 61, sex: 'м', currentDrugs: ['фуросемид'] };
  const рв = await врач.call('analyzePatient', { patient: ВХОД });
  check('3 · врач получает conventional, validated:false, вердикт контура', !!рв.conventional && рв.validated === false && !!рв.предохранители);
  check('3 · ⛔ врачу без litvak внутренний слой не уходит', рв.internalL1 === undefined);
  const рл = await литвак.call('analyzePatient', { patient: { ...ВХОД, нейро: { MCI_или_SCD: true, CDR: 0.5 } } });
  check('3 · ⭐ подписывающий врач получает внутренний слой (запись L1 больше не падает)', !!рл.internalL1 && !!рл.reportId);
  check('3 · ⭐ §4Z на живом пути: раздел построен по признакам',
    /§4Z/.test(JSON.stringify(рл.internalL1['обогащение'] || {})) && !/признаки выдачи приказа не поданы/.test(JSON.stringify(рл.internalL1['обогащение'] || {})));

  // ── 4 · СНИМОК ──
  const сн = await врач.call('submitImage', { imageId: 'img-1', вид: 'анализ крови', прочитано: [{ имя: 'Hb', значение: '13.1', единица: 'г/дл' }] });
  check('4 · снимок заведён, значение ждёт подтверждения', сн.подтверждено === 0 && (сн['ждут_подтверждения'] || []).length === 1, сн);
  const пт = await врач.call('submitImage', { imageId: 'img-1', подтвердить: { имя: 'Hb', принять: true, значение: '13.4' } });
  check('4 · подтверждение с исправлением принято', пт.подтверждено === 1, пт);

  // ── 6 · ЖУРНАЛ ──
  const жл = await getDocs(collection(литвак.db, 'accessLog'));
  const действия = жл.docs.map((d) => d.data().действие);
  check('6 · журнал: согласие, разбор, отклонённый разбор, подпись, снимок, документ пациента',
    ['согласие дано', 'разбор', 'разбор отклонён', 'подпись', 'снимок заведён', 'документ пациента'].every((x) => действия.includes(x)), [...new Set(действия)]);
  const жлВрач = await ошибка(getDocs(collection(врач.db, 'accessLog')));
  check('6 · ⛔ журнал читает только подписывающий врач', !!жлВрач && /permission/.test(String(жлВрач.code)));

  console.log(`\nСКВОЗНОЙ ПРОГОН НА ЭМУЛЯТОРАХ: ${ok}/${ok + fail}`);
  for (const k of [пац, врач, литвак]) await deleteApp(k.app);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.log('  FAIL исключение:', e && (e.stack || e.message)); process.exit(1); });
