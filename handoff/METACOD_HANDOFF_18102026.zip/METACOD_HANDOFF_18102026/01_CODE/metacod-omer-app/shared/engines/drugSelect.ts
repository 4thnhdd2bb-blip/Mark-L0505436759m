// METACOD-Omer · shared/engines/drugSelect.ts
// Подбор препаратов ПО ЭНЕРГИИ и ВЕКТОРУ золь/гель из drugbase.json.
// Энергию несёт САМ ПРЕПАРАТ (поля en/sg). Без игл/точек.

import type { DrugPick } from '../types';
// ⭐ Р-ГЕЛЬЗОЛЬ-25 ПОДПИСАН 22.09.2026: «расширяй базу до 658».
// Читаем РАСШИРЕННУЮ базу: подписанные 404 + 263 из индекса, помеченные
// полем изИндекса. ⛔ drugbase.json при этом НЕ ИЗМЕНЁН ни на байт —
// расширение живёт слоем поверх (baseExtend.ts), как и подписанные
// поправки. Подписанное всегда идёт первым и добавленным не перебивается.
import { БАЗА_РАСШИРЕННАЯ as drugbase } from './baseExtend';
import { sgcНайти, внеПодбора as внеПодбораКласса, ПОЛОСА_ВНЕ_ПОДБОРА } from './gelSolClasses';

// ═══════════════════════════════════════════════════════════════════
// ⛔⛔⛔ ДЕФЕКТ, НАЙДЕННЫЙ 22.09.2026, И ОН БЫЛ САМЫМ ОПАСНЫМ ЗА ВСЮ РАБОТУ.
//
// В правилах классов с самого начала стояло: «⛔ ОНКОЛОГИЯ И СИСТЕМНАЯ
// ИММУНОСУПРЕССИЯ (полоса 4) НАПРАВЛЕНИЯ НЕ ПОЛУЧАЮТ ВОВСЕ... решение
// онколога и ревматолога». Правило было записано, объявлено врачу и
// проверено тестом.
//
// ⛔ НО ЭТОТ ФАЙЛ ЕГО НЕ ЧИТАЛ. Подбор идёт прямо по полю en из drugbase,
// а у противоопухолевых энергия ПОДПИСАНА ВРАЧОМ («Тепло, Ветер»).
// Значит byEnergy('Ветер') возвращал 163 позиции, и 30 из них — полоса 4:
// бортезомиб, анастрозол, алектиниб, амивантамаб в одном списке с тем,
// что можно предложить. Измерено, а не предположено.
//
// ⭐ Род ошибки тот же, что преследует проект весь день: ПРАВИЛО ЖИВЁТ В
// ОДНОМ МЕСТЕ, А ВТОРОЙ ПУТЬ ИДЁТ МИМО НЕГО. Только здесь цена другая:
// не перепутанный класс, а цитостатик в выдаче подбора.
// ⭐ 22.09.2026, вечер. Здесь стояла СВОЯ копия границы — и именно потому
// починка не дошла до двух других путей по индексу 658. Копию убрал:
// граница живёт одной функцией в gelSolClasses и зовётся отсюда.
function полосаСтроки(d: DrugRow): number | undefined {
  const п = sgcНайти(d.atc || '', d.cls || '', d.n || '');
  return п ? п.полоса : undefined;
}

/** ⛔ Позиция вне подбора: решение специалиста, а не движка. */
function внеПодбора(d: DrugRow): boolean {
  return внеПодбораКласса(d.atc, d.cls, d.n);
}

interface DrugRow {
  n: string; cls?: string; atc?: string; en?: string; sg?: string;
  gate?: string; trop?: string; brand?: string; ind?: string;
  dis?: { d: string; r: string[] }[];
}

const DB: DrugRow[] = drugbase as unknown as DrugRow[];

/**
 * Препараты, несущие данную энергию (ось).
 * ⛔ Полоса 4 (онкология, системная иммуносупрессия, орфанные) ИСКЛЮЧЕНА:
 * их назначение — решение онколога, ревматолога или центра, а не подбор.
 * Что именно исключено — видно через byEnergyЗаСпециалистом(), чтобы оно
 * не пропадало молча.
 */
export function byEnergy(energy: string): DrugPick[] {
  return DB.filter((d) => (d.en ?? '').includes(energy) && !внеПодбора(d)).map(toPick);
}

/** ⛔ Что подбор НЕ вернул по этой энергии и почему. Не для назначения. */
export function byEnergyЗаСпециалистом(energy: string): Array<DrugPick & { стоп: string }> {
  return DB.filter((d) => (d.en ?? '').includes(energy) && внеПодбора(d))
    .map((d) => ({
      ...toPick(d),
      стоп: '⛔ полоса 4: назначение за онкологом, ревматологом или центром. '
        + 'Ось описывает вещество и НЕ разрешает применение',
    }));
}

/** Препараты по вектору золь/гель (например '→M-A', '→M-0'). */
export function bySolGel(vector: string): DrugPick[] {
  return DB.filter((d) => (d.sg ?? '').includes(vector) && !внеПодбора(d)).map(toPick);
}

/** Препараты по болезни (карта JCZ-ролей). */
export function byDisease(disease: string): (DrugPick & { roles: string[] })[] {
  const out: (DrugPick & { roles: string[] })[] = [];
  for (const d of DB) {
    if (внеПодбора(d)) continue;   // ⛔ та же граница, что и по энергии
    const hit = d.dis?.find((x) => x.d.toLowerCase().includes(disease.toLowerCase()));
    if (hit) out.push({ ...toPick(d), roles: hit.r });
  }
  return out;
}

/** HARD-STOP гейт: не давать при глубоком катаболизме (M-D2/3). */
/**
 * ⛔⛔ ОДИН СПИСОК КАТАБОЛИКОВ ПОД HARD-STOP M-D2/M-D3 — ремонт 18.10.2026.
 *
 * Канон `hard_stop`: «M-D2/M-D3 (кахексия) → метформин/берберин/SGLT-2/GLP-1/NAC ЗАПРЕЩЕНЫ».
 * Найдено разбором 18.10: `respectGates` искал «SGLT2|метформин|DPP-4|инкретин» и НЕ узнавал
 * «Семаглутид», «Лираглутид», «Дулаглутид», «Тирзепатид» — при M-D2 они проходили в подбор.
 * В двух других сторожах (diagnosisAlgorithm, safetyGate) не было тирзепатида и брендов.
 * Правило жило в трёх копиях и разошлось. Теперь копия одна — здесь, и её зовут все три.
 */
export const КАТАБОЛИКИ_HARD_STOP_MD = new RegExp([
  'метформин', 'metformin', 'глюкофаж', 'glucophage', 'сиофор',
  'берберин', 'berberine',
  'sglt-?2', 'глифлозин', 'gliflozin', 'джардинс', 'jardiance', 'форсига', 'farxiga', 'forxiga', 'инвокана', 'invokana',
  'glp-?1', 'gip', 'инкретин', 'лираглутид', 'liraglutide', 'саксенда', 'saxenda', 'виктоза', 'victoza',
  'дулаглутид', 'dulaglutide', 'трулисити', 'trulicity', 'семаглутид', 'semaglutide', 'оземпик', 'ozempic',
  'вегови', 'wegovy', 'рибелсус', 'rybelsus', 'тирзепатид', 'tirzepatide', 'мунджаро', 'mounjaro',
  'зепбаунд', 'zepbound', 'эксенатид', 'exenatide', 'ретатрутид', 'орфорглипрон', 'мазудутид',
  'ацетилцистеин', 'acetylcysteine', '(?:^|[^a-zа-яё])nac(?![a-zа-яё])',
].join('|'), 'i');

/** Подпадает ли средство под HARD-STOP M-D2/M-D3. */
export function hsКатаболикЗапрещёнПриMD(текст: string): boolean {
  return КАТАБОЛИКИ_HARD_STOP_MD.test(String(текст || ''));
}

export function respectGates(picks: DrugPick[], deepCatabolism: boolean): DrugPick[] {
  if (!deepCatabolism) return picks;
  return picks.filter((p) => !hsКатаболикЗапрещёнПриMD(p.name + ' ' + (p.why ?? '')));
}

function toPick(d: DrugRow): DrugPick {
  return { name: d.n, energy: d.en || undefined, solGel: d.sg || undefined, brand: d.brand || undefined, why: d.trop || d.ind || undefined };
}

export const DRUGBASE_COUNT = DB.length;
