// МОСТ ОТ СЛОВ БОЛЬНОГО К 18 ГЕЙТАМ CAN'T-MISS — Р-ПРОГОН-1, слово врача 18.10.2026:
// «строй мост от слов больного к 18 гейтам тем же способом, что уже работает
// в триаже: синонимы, учёт отрицаний, русский, иврит и английский».
//
// ⭐ Фразы ниже написаны движком как ПРОВЕРКА СПОСОБА, а не взяты у больных:
// материалы больных в пакет не идут. Прогон на тех 12 живых фразах, где найден
// Р-ПРОГОН-1, — Р-ПРОГОН-3, на машине врача.

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const PT = require('./_buildA/engines/phaseTransition');
const canon = require('./_buildA/data/diagnosis_algorithm_canon.json');

let ok = 0, fail = 0;
function check(name, cond) { if (cond) { ok++; console.log('  OK ', name); } else { fail++; console.log('  FAIL', name); } }

const гейты = (p) => PT.cantMissGates(Object.assign({ complaints: [], labs: {} }, p)).map((h) => h.trigger);
const ТРИГ = canon['гейты_cant_miss'].map((g) => g['триггер']);
const есть = (p, n) => гейты(p).includes(ТРИГ[n]);

// ═══ ① ГЕЙТ 0: потеря веса + ночная потливость / лихорадка ═══
check('① ⭐ фраза Р-ПРОГОН-1 «похудел на 8 кг, ночью потею» → гейт онкопоиска',
  есть({ complaints: ['похудел на 8 кг, ночью потею'] }, 0));
check('① женский род: «похудела на 5 кг» + «потею по ночам»',
  есть({ complaints: ['похудела на 5 кг', 'потею по ночам'] }, 0));
check('① потеря веса + температура: «сбросил 6 кг», «температурю по вечерам»',
  есть({ complaints: ['сбросил 6 кг за два месяца', 'температурю по вечерам'] }, 0));
check('① английский: «I lost 10 pounds», «night sweats»',
  есть({ complaints: ['I lost 10 pounds without trying', 'night sweats'] }, 0));
check('① иврит: «ירדתי במשקל», «הזעות לילה»',
  есть({ complaints: ['ירדתי במשקל', 'הזעות לילה'] }, 0));
check('① ⛔ отрицание: «не худею», «ночью не потею» → гейта НЕТ',
  !есть({ complaints: ['не худею', 'ночью не потею'] }, 0));
check('① ⛔ английское отрицание: «no weight loss», «no night sweats» → гейта НЕТ',
  !есть({ complaints: ['no weight loss', 'no night sweats'] }, 0));
check('① ⭐ отрицание из СОСЕДНЕЙ жалобы не гасит: «не устаю» · «похудел» · «потею ночью»',
  есть({ complaints: ['не устаю', 'похудел', 'потею ночью'] }, 0));
check('① только похудение без потливости и лихорадки → гейта 0 нет',
  !есть({ complaints: ['похудел на 4 кг'] }, 0));

// ═══ ② ГЕЙТ 1: Hct/Hb↑ + боль в груди или одышка ═══
check('② Hb 17.5 + «pressure in my chest» → ОКС/ТЭЛА',
  есть({ labs: { Hb: 17.5 }, complaints: ['pressure in my chest'] }, 1));
check('② Hct 52 + «קוצר נשימה» → ОКС/ТЭЛА',
  есть({ labs: { Hct: 52 }, complaints: ['קוצר נשימה'] }, 1));
check('② без анализа слова в груди гейт 1 НЕ включают (лаборатория остаётся условием)',
  !есть({ complaints: ['pressure in my chest'] }, 1));

// ═══ ③ ГЕЙТ 3: дефицит железа старше 50 ═══
check('③ ⭐ «у меня дефицит железа», 62 года, без анализа → ФГДС + колоноскопия',
  есть({ age: 62, complaints: ['у меня дефицит железа'] }, 3));
check('③ «low ferritin», 58 лет → гейт', есть({ age: 58, complaints: ['low ferritin'] }, 3));
check('③ 40 лет — гейта нет (возраст из подписанного триггера)',
  !есть({ age: 40, complaints: ['у меня дефицит железа'] }, 3));
check('③ ферритин 60 в анализах, 55 лет — гейт по-прежнему', есть({ age: 55, labs: { ферритин: 60 } }, 3));

// ═══ ④ ГЕЙТ 4: потеря веса при хронической болезни ═══
check('④ ⭐ болезнь из поля диагнозов: «похудела» + diagnoses «сахарный диабет»',
  есть({ complaints: ['похудела'], diagnoses: ['сахарный диабет'] }, 4));
check('④ иврит: «ירידה במשקל» + «קרוהן»', есть({ complaints: ['ירידה במשקל', 'קרוהן'] }, 4));

// ═══ ⑤ ГЕЙТЫ СЛИЗИСТОЙ ═══
check('⑤ ⭐ «פצעים בפה שוב ושוב» + «אין חום» → ОАК в эпизод (гейт 5)',
  есть({ age: 30, complaints: ['פצעים בפה שוב ושוב', 'אין חום'] }, 5));
check('⑤ «mouth ulcers keep coming back», «no fever» → гейт 5',
  есть({ age: 30, complaints: ['mouth ulcers keep coming back', 'no fever'] }, 5));
check('⑤ ⛔ без отрицания лихорадки гейт 5 НЕ включается (он про «без лихорадки»)',
  !есть({ age: 30, complaints: ['mouth ulcers keep coming back'] }, 5));
check('⑥ «hashimoto» + «oral thrush» → АПС-1 (гейт 6)', есть({ complaints: ['hashimoto', 'oral thrush'] }, 6));
check('⑦ «молочница повторяется», 35 лет → ВИЧ/Ig (гейт 7)', есть({ age: 35, complaints: ['молочница повторяется'] }, 7));
check('⑧ «papilloma» без биопсии → биопсия (гейт 8)', есть({ complaints: ['papilloma on the cheek'] }, 8));
check('⑧ ⛔ «papilloma» + «biopsy done» → гейта 8 нет', !есть({ complaints: ['papilloma on the cheek', 'biopsy done'] }, 8));
check('⑨ «squamous cell carcinoma», 38 лет → анемия Фанкони (гейт 9)',
  есть({ age: 38, complaints: ['squamous cell carcinoma of the tongue'] }, 9));
check('⑪ «painless white patches» → вторичный сифилис (гейт 11)', есть({ complaints: ['painless white patches'] }, 11));

// ═══ ⑫ ГИПОМЕТАБОЛИЗМ И ЯТРОГЕНИЯ ═══
check('⑫ ⭐ «מחלת כליות» + препарат «אדוויל» → НПВС при ХБП (гейт 12)',
  есть({ complaints: ['מחלת כליות'], currentDrugs: ['אדוויל'] }, 12));
check('⑫ «kidney disease» + «Advil» → гейт 12', есть({ complaints: ['kidney disease'], currentDrugs: ['Advil'] }, 12));
check('⑬ «Lipitor» + «muscle cramps» + «always cold» + «thyroid» → статин-миопатия (гейт 13)',
  есть({ currentDrugs: ['Lipitor'], complaints: ['muscle cramps', 'always cold', 'thyroid problem'] }, 13));
check('⑮ «щитовидка» + «постоянно мерзну», без левотироксина → гейт 15',
  есть({ complaints: ['щитовидка', 'постоянно мерзну'] }, 15));
check('⑮ ⛔ ИСКЛЮЧЕНИЕ: «אלטרוקסין» в схеме — препарат ЕСТЬ, гейт «без препарата» молчит',
  !есть({ complaints: ['בלוטת התריס', 'קר לי כל הזמן'], currentDrugs: ['אלטרוקסין'] }, 15));
check('⑮ иврит без препарата → гейт 15 есть',
  есть({ complaints: ['בלוטת התריס', 'קר לי כל הזמן'] }, 15));

// ═══ ⑯ МЕТАБОЛИЧЕСКИЙ КУРС ═══
check('⑯ «Jardiance» + «intermittent fasting» → эугликемический кетоацидоз (гейт 16)',
  есть({ currentDrugs: ['Jardiance'], complaints: ['intermittent fasting'] }, 16));
check('⑯ «פורסיגה» + «צום לסירוגין» → гейт 16', есть({ currentDrugs: ['פורסיגה'], complaints: ['צום לסירוגין'] }, 16));
check('⑰ «Ozempic» + «weight loss», без плана мышц → гейт 17',
  есть({ currentDrugs: ['Ozempic'], complaints: ['weight loss'] }, 17));
check('⑰ «Ozempic» + «weight loss» + «фазовый угол» в плане → гейта 17 нет',
  !есть({ currentDrugs: ['Ozempic'], complaints: ['weight loss', 'контроль: фазовый угол'] }, 17));

// ═══ ⑱ ПРЕЖНИЕ ШАБЛОНЫ ЖИВЫ: мост только добавляет ═══
check('⑱ прежняя формулировка «потеря веса» + «лихорадка» по-прежнему даёт гейт 0',
  есть({ complaints: ['потеря веса', 'лихорадка'] }, 0));
const код = fs.readFileSync(path.join(__dirname, '..', 'phaseTransition.ts'), 'utf8');
check('⑱ в коде гейтов прежние шаблоны стоят рядом с мостом (ИЛИ, а не замена)',
  /hasSign\(text, \/потер\[а-яё\]\*\\s\*вес\|похудан\/\) \|\| м\('потеря_веса'\)/.test(код));
check('⑱ мост ищет тем же матчером триажа — второго матчера нет',
  /from '\.\/triage'/.test(код) && /trИскатьВсе/.test(код));

// ═══ ⑲ КАНОН ═══
const М = canon['первичный_фильтр_жалобы']['мост_гейтов'];
check('⑲ мост лежит в каноне', !!М && !!М['признаки'] && !!М['гейты']);
check('⑲ все 18 гейтов описаны в мосте', ТРИГ.every((_, i) => Array.isArray(М['гейты'][String(i)])));
check('⑲ у каждого признака есть слова на ru, en и he (своими списками или из триажа)',
  Object.values(М['признаки']).every((п) => (п['из_триажа'] || []).length > 0
    || ((п.ru || []).length > 0 && (п.en || []).length > 0 && (п.he || []).length > 0)));
check('⑲ слово врача записано дословно', /строй мост от слов больного к 18 гейтам/.test(М['источник']));
check('⑲ ⛔ слова НЕ ПОДПИСАНЫ и это сказано (Р-ПРОГОН-2), validated:false',
  /НЕ ПОДПИСАНЫ/.test(М['статус']) && М['validated'] === false
  && М['открытые_вопросы'].some((q) => /Р-ПРОГОН-2/.test(q)));
check('⑲ подписанный текст гейтов не тронут: 18 гейтов, первый — про онкопоиск',
  ТРИГ.length === 18 && /потеря веса \+ ночная потливость/.test(ТРИГ[0]));
const св = PT.gbСводка();
check('⑲ сводка моста считает признаки и слова', св.признаков >= 28 && св.слов > 600 && св.гейтов === 18);

// ═══ ⑳ НЕГАТИВНЫЙ ПРОГОН: без моста в каноне движок НЕ ЗАПУСКАЕТСЯ ═══
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'most-'));
try {
  fs.cpSync(path.join(__dirname, '_buildA'), tmp, { recursive: true });
  const cp = path.join(tmp, 'data', 'diagnosis_algorithm_canon.json');
  const c2 = JSON.parse(fs.readFileSync(cp, 'utf8'));
  delete c2['первичный_фильтр_жалобы']['мост_гейтов'];
  fs.writeFileSync(cp, JSON.stringify(c2));
  let упал = false;
  try {
    execFileSync(process.execPath, ['-e', `require(${JSON.stringify(path.join(tmp, 'engines', 'phaseTransition'))})`],
      { stdio: 'pipe' });
  } catch (e) { упал = /мост_гейтов/.test(String(e.stderr)); }
  check('⑳ ⛔ вынули мост из канона → движок гейтов отказывается запускаться и называет причину', упал);
} finally { fs.rmSync(tmp, { recursive: true, force: true }); }

console.log(`\nМОСТ ГЕЙТОВ (Р-ПРОГОН-1): ${ok}/${ok + fail}`);
process.exit(fail === 0 ? 0 : 1);
