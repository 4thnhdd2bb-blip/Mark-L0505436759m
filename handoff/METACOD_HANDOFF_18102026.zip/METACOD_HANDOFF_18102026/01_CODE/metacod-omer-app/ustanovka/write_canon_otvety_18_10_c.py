# -*- coding: utf-8 -*-
"""Поправка счёта 18.10.2026: галоперидол остался в off-label базы 415 у 41 болезни, а не у 45.
Первый счёт включил строки, отобранные по имени болезни (БА, MCI, вторая строка БП), где галоперидола нет.
Ошибка движка, найдена пересчётом по самой базе."""
import json, collections, os, shutil
HERE = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(HERE, '..', 'shared', 'data', 'diagnosis_algorithm_canon.json')
B = os.path.join(HERE, '..', 'shared', 'data', 'metacod_base_415.json')
c = json.load(open(P, encoding='utf-8'), object_pairs_hook=collections.OrderedDict)
n = sum('Галоперидол' in r['offlabel'] for r in json.load(open(B, encoding='utf-8'))['болезни'])
assert n == 41, n
r = c['принцип_нейродегенерации']['решения_врача_18_10_2026']['галоперидол_БП_ДТЛ']
assert 'ещё у 45 болезней' in r['что_сделано']
shutil.copy(P, P + '.bak_v140')
r['что_сделано'] = r['что_сделано'].replace('ещё у 45 болезней', f'ещё у {n} болезней (пересчитано по базе)')
json.dump(c, open(P, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('исправлено: 45 →', n)
